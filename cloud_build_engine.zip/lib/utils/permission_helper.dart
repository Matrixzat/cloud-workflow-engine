import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PermissionHelper {
  PermissionHelper._();

  static const _channel = MethodChannel('com.cloud.build.engine/storage');

  // ── Startup check ──────────────────────────────────────────────────────────
  /// Call once from HomeScreen.initState — shows permission dialog if not yet granted.
  static Future<void> checkStartup(BuildContext context) async {
    final hasAccess = await hasFullStorageAccess();
    if (hasAccess || !context.mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _StartupPermissionDialog(),
    );
  }

  // ── Per-action check ───────────────────────────────────────────────────────
  /// Call before any file-save operation.
  /// Returns true if permission is granted (either already or just granted).
  static Future<bool> ensureStorage(
    BuildContext context, {
    Color accent = const Color(0xFF00b4d8),
  }) async {
    final hasAccess = await hasFullStorageAccess();
    if (hasAccess) return true;
    if (!context.mounted) return false;

    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ToolPermissionDialog(accent: accent),
    );

    if (confirmed == true) {
      await _requestFullStorageAccess();
      await Future.delayed(const Duration(milliseconds: 800));
      return await hasFullStorageAccess();
    }
    return false;
  }

  // ── Internals ──────────────────────────────────────────────────────────────
  static Future<bool> hasFullStorageAccess() async {
    if (!Platform.isAndroid) return true;
    try {
      final sdkInt = await _channel.invokeMethod<int>('getSdkInt') ?? 30;
      if (sdkInt >= 30) {
        return await _channel.invokeMethod<bool>('hasManagePermission') ?? false;
      }
      // Android < 11 — storage permission always granted at install time
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> _requestFullStorageAccess() async {
    try {
      await _channel.invokeMethod('openManagePermissionSettings');
    } catch (_) {}
  }
}

// ── Startup dialog ─────────────────────────────────────────────────────────────

class _StartupPermissionDialog extends StatelessWidget {
  const _StartupPermissionDialog();

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00b4d8);
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0d1b2e),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: accent.withOpacity(0.6), width: 1.5),
          boxShadow: [BoxShadow(color: accent.withOpacity(0.12), blurRadius: 32, spreadRadius: 2)],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Top accent bar
            Container(
              height: 4,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                gradient: LinearGradient(colors: [Color(0xFF00b4d8), Color(0xFF0077ff), Color(0xFFffd60a)]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: accent.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: accent.withOpacity(0.3)),
                      ),
                      child: const Icon(Icons.folder_open_rounded, color: accent, size: 28),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Storage Access Required',
                          style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                        SizedBox(height: 4),
                        Text('Cloud Build Engine needs this to save APKs',
                          style: TextStyle(color: Color(0xFF8899aa), fontSize: 12)),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 18),
                  const Text(
                    'To automatically save your built APKs to\n/Cloud_Build_Engine/ on your device, please grant '
                    'All Files Access on the next screen.',
                    style: TextStyle(color: Color(0xFFa0b4c8), fontSize: 13, height: 1.6),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        Navigator.pop(context);
                        await PermissionHelper._requestFullStorageAccess();
                      },
                      icon: const Icon(Icons.security_rounded, size: 20),
                      label: const Text('Grant All Files Access',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accent,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    height: 42,
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF8899aa),
                        side: const BorderSide(color: Color(0xFF1e3050)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Skip for Now', style: TextStyle(fontSize: 14)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Per-action dialog ──────────────────────────────────────────────────────────

class _ToolPermissionDialog extends StatelessWidget {
  final Color accent;
  const _ToolPermissionDialog({required this.accent});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF0d1b2e),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: accent, width: 1),
      ),
      title: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: accent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(Icons.folder_open_rounded, color: accent, size: 22),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Text('Storage Access Required',
            style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
        ),
      ]),
      content: const Text(
        'Cloud Build Engine needs All Files Access to save your APK to the '
        'Cloud_Build_Engine folder.\n\nPlease grant this on the next screen.',
        style: TextStyle(color: Color(0xFFa0b4c8), fontSize: 13, height: 1.6),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancel', style: TextStyle(color: Color(0xFF6b7280))),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            elevation: 0,
          ),
          onPressed: () => Navigator.pop(context, true),
          child: const Text('Grant Access', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}
