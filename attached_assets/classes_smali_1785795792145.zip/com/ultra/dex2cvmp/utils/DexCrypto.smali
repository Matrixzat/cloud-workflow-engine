.class public Lcom/ultra/dex2cvmp/utils/DexCrypto;
.super Ljava/lang/Object;
.source "DexCrypto.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static FxIjsF([I)[I
    .registers 8
    .param p0, "iArr"  # [I

    .line 205
    const/16 v0, 0x1b

    new-array v0, v0, [I

    .line 206
    .local v0, "r":[I
    const/4 v1, 0x0

    aget v2, p0, v1

    .line 207
    .local v2, "i":I
    aput v2, v0, v1

    .line 208
    const/4 v1, 0x1

    aget v1, p0, v1

    const/4 v3, 0x2

    aget v3, p0, v3

    const/4 v4, 0x3

    aget v4, p0, v4

    filled-new-array {v1, v3, v4}, [I

    move-result-object v1

    .line 209
    .local v1, "t":[I
    const/4 v3, 0x0

    .local v3, "i2":I
    :goto_17
    const/16 v4, 0x1a

    if-ge v3, v4, :cond_40

    .line 210
    rem-int/lit8 v4, v3, 0x3

    rem-int/lit8 v5, v3, 0x3

    aget v5, v1, v5

    ushr-int/lit8 v5, v5, 0x8

    rem-int/lit8 v6, v3, 0x3

    aget v6, v1, v6

    shl-int/lit8 v6, v6, 0x18

    or-int/2addr v5, v6

    add-int/2addr v5, v2

    xor-int/2addr v5, v3

    aput v5, v1, v4

    .line 211
    shl-int/lit8 v4, v2, 0x3

    ushr-int/lit8 v5, v2, 0x1d

    or-int/2addr v4, v5

    rem-int/lit8 v5, v3, 0x3

    aget v5, v1, v5

    xor-int v2, v4, v5

    .line 212
    add-int/lit8 v4, v3, 0x1

    aput v2, v0, v4

    .line 209
    add-int/lit8 v3, v3, 0x1

    goto :goto_17

    .line 214
    .end local v3  # "i2":I
    :cond_40
    return-object v0
.end method

.method private static blobKey()[B
    .registers 4

    .line 78
    const/16 v0, 0x10

    new-array v0, v0, [C

    fill-array-data v0, :array_18

    .line 81
    .local v0, "c":[C
    array-length v1, v0

    new-array v1, v1, [B

    .line 82
    .local v1, "k":[B
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_b
    array-length v3, v0

    if-ge v2, v3, :cond_16

    aget-char v3, v0, v2

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    .line 83
    .end local v2  # "i":I
    :cond_16
    return-object v1

    nop

    :array_18
    .array-data 2
        0x50s
        0x68s
        0x34s
        0x6es
        0x74s
        0x30s
        0x6ds
        0x42s
        0x6cs
        0x30s
        0x62s
        0x4bs
        0x33s
        0x79s
        0x21s
        0x21s
    .end array-data
.end method

.method private static closeQuiet(Ljava/io/Closeable;)V
    .registers 2
    .param p0, "c"  # Ljava/io/Closeable;

    .line 260
    if-nez p0, :cond_3

    return-void

    .line 261
    :cond_3
    :try_start_3
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_6} :catch_7

    goto :goto_8

    :catch_7
    move-exception v0

    .line 262
    :goto_8
    return-void
.end method

.method public static decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 5
    .param p0, "key"  # [B
    .param p1, "input"  # Ljava/io/InputStream;
    .param p2, "output"  # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 144
    new-instance v0, Ljava/util/zip/InflaterInputStream;

    invoke-direct {v0, p1}, Ljava/util/zip/InflaterInputStream;-><init>(Ljava/io/InputStream;)V

    .line 145
    .local v0, "is":Ljava/util/zip/InflaterInputStream;
    new-instance v1, Ljava/util/zip/InflaterOutputStream;

    invoke-direct {v1, p2}, Ljava/util/zip/InflaterOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 146
    .local v1, "os":Ljava/util/zip/InflaterOutputStream;
    invoke-static {p0, v0, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->exfr([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 147
    invoke-virtual {v1}, Ljava/util/zip/InflaterOutputStream;->close()V

    .line 148
    invoke-virtual {v0}, Ljava/util/zip/InflaterInputStream;->close()V

    .line 149
    return-void
.end method

.method private static decryptBlob([B)[B
    .registers 4
    .param p0, "blob"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 155
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    array-length v1, p0

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 156
    .local v0, "out":Ljava/io/ByteArrayOutputStream;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->blobKey()[B

    move-result-object v1

    new-instance v2, Ljava/io/ByteArrayInputStream;

    invoke-direct {v2, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {v1, v2, v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 157
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    return-object v1
.end method

.method public static decryptToBytes([B[B)[B
    .registers 4
    .param p0, "key"  # [B
    .param p1, "encrypted"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 135
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    array-length v1, p1

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 136
    .local v0, "baos":Ljava/io/ByteArrayOutputStream;
    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {p0, v1, v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 139
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    return-object v1
.end method

.method private static exfr([BLjava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 14
    .param p0, "key"  # [B
    .param p1, "in"  # Ljava/io/InputStream;
    .param p2, "out"  # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 173
    if-eqz p0, :cond_7a

    array-length v0, p0

    const/16 v1, 0x10

    if-lt v0, v1, :cond_7a

    .line 175
    const/4 v0, 0x4

    new-array v2, v0, [I

    .line 176
    .local v2, "iArr":[I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_b
    if-ge v3, v0, :cond_32

    .line 177
    mul-int/lit8 v4, v3, 0x4

    .line 178
    .local v4, "b":I
    aget-byte v5, p0, v4

    and-int/lit16 v5, v5, 0xff

    add-int/lit8 v6, v4, 0x1

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    or-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x2

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/2addr v6, v1

    or-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x3

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x18

    or-int/2addr v5, v6

    aput v5, v2, v3

    .line 176
    .end local v4  # "b":I
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    .line 183
    .end local v3  # "i":I
    :cond_32
    const/4 v0, 0x0

    aget v1, v2, v0

    const/4 v3, 0x2

    aget v3, v2, v3

    xor-int/2addr v1, v3

    const/4 v3, 0x1

    aget v3, v2, v3

    const/4 v4, 0x3

    aget v4, v2, v4

    xor-int/2addr v3, v4

    filled-new-array {v1, v3}, [I

    move-result-object v1

    .line 184
    .local v1, "iArr2":[I
    invoke-static {v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->FxIjsF([I)[I

    move-result-object v2

    .line 186
    const/16 v3, 0x2000

    new-array v3, v3, [B

    .line 187
    .local v3, "buf":[B
    const/4 v4, 0x0

    .line 189
    .local v4, "pos":I
    :goto_4d
    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v5

    .line 190
    .local v5, "read":I
    if-gez v5, :cond_54

    return-void

    .line 191
    :cond_54
    add-int v6, v4, v5

    .line 192
    .local v6, "end":I
    const/4 v7, 0x0

    .line 193
    .local v7, "i5":I
    :goto_57
    if-ge v4, v6, :cond_76

    .line 194
    rem-int/lit8 v8, v4, 0x8

    .line 195
    .local v8, "i6":I
    if-nez v8, :cond_60

    invoke-static {v2, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nDnv([I[I)V

    .line 196
    :cond_60
    div-int/lit8 v9, v8, 0x4

    aget v9, v1, v9

    rem-int/lit8 v10, v4, 0x4

    mul-int/lit8 v10, v10, 0x8

    shr-int/2addr v9, v10

    int-to-byte v9, v9

    aget-byte v10, v3, v7

    xor-int/2addr v9, v10

    int-to-byte v9, v9

    aput-byte v9, v3, v7

    .line 197
    add-int/lit8 v4, v4, 0x1

    .line 198
    nop

    .end local v8  # "i6":I
    add-int/lit8 v7, v7, 0x1

    .line 199
    goto :goto_57

    .line 200
    :cond_76
    invoke-virtual {p2, v3, v0, v5}, Ljava/io/OutputStream;->write([BII)V

    .line 201
    .end local v5  # "read":I
    .end local v6  # "end":I
    .end local v7  # "i5":I
    goto :goto_4d

    .line 173
    .end local v1  # "iArr2":[I
    .end local v2  # "iArr":[I
    .end local v3  # "buf":[B
    .end local v4  # "pos":I
    :cond_7a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "key must be 16 bytes"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static loadPhantomLib(Landroid/content/Context;)V
    .registers 10
    .param p0, "ctx"  # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 96
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "libphantom.so"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 98
    .local v0, "soFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_60

    .line 99
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->pickBlobName()Ljava/lang/String;

    move-result-object v1

    .line 100
    .local v1, "blobName":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "phantom/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 102
    .local v2, "assetPath":Ljava/lang/String;
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v3

    .line 103
    .local v3, "bis":Ljava/io/InputStream;
    invoke-static {v3}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v4

    .line 104
    .local v4, "blob":[B
    invoke-static {v3}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 106
    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptBlob([B)[B

    move-result-object v5

    .line 108
    .local v5, "soBytes":[B
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v6

    .line 109
    .local v6, "parent":Ljava/io/File;
    if-eqz v6, :cond_4a

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v7

    if-nez v7, :cond_4a

    invoke-virtual {v6}, Ljava/io/File;->mkdirs()Z

    .line 111
    :cond_4a
    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 113
    .local v7, "fos":Ljava/io/FileOutputStream;
    :try_start_4f
    invoke-virtual {v7, v5}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_52
    .catchall {:try_start_4f .. :try_end_52} :catchall_5b

    .line 115
    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 116
    nop

    .line 119
    const/4 v8, 0x0

    invoke-virtual {v0, v8, v8}, Ljava/io/File;->setWritable(ZZ)Z

    goto :goto_60

    .line 115
    :catchall_5b
    move-exception v8

    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 116
    throw v8

    .line 122
    .end local v1  # "blobName":Ljava/lang/String;
    .end local v2  # "assetPath":Ljava/lang/String;
    .end local v3  # "bis":Ljava/io/InputStream;
    .end local v4  # "blob":[B
    .end local v5  # "soBytes":[B
    .end local v6  # "parent":Ljava/io/File;
    .end local v7  # "fos":Ljava/io/FileOutputStream;
    :cond_60
    :goto_60
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/System;->load(Ljava/lang/String;)V

    .line 123
    return-void
.end method

.method private static nDnv([I[I)V
    .registers 8
    .param p0, "iArr"  # [I
    .param p1, "iArr2"  # [I

    .line 218
    const/4 v0, 0x0

    aget v1, p1, v0

    .local v1, "i":I
    const/4 v2, 0x1

    aget v3, p1, v2

    .line 219
    .local v3, "i2":I
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    aget v5, p0, v0

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 220
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    aget v5, p0, v2

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 221
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x2

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 222
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x3

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 223
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x4

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 224
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x5

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 225
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x6

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 226
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x7

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 227
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x8

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 228
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x9

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 229
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xa

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 230
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xb

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 231
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xc

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 232
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xd

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 233
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xe

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 234
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xf

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 235
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x10

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 236
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x11

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 237
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x12

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 238
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x13

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 239
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x14

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 240
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x15

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 241
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x16

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 242
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x17

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 243
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x18

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 244
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x19

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 245
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x1a

    aget v5, p0, v5

    xor-int v3, v4, v5

    .line 246
    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int/2addr v4, v3

    aput v4, p1, v0

    .line 247
    aput v3, p1, v2

    .line 248
    return-void
.end method

.method public static native nativeGetKey([B[B[B)[B
.end method

.method private static pickBlobName()Ljava/lang/String;
    .registers 5

    .line 162
    nop

    .line 163
    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    .line 164
    nop

    .line 165
    .local v0, "abis":[Ljava/lang/String;
    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_1a

    aget-object v3, v0, v2

    .line 166
    .local v3, "abi":Ljava/lang/String;
    if-eqz v3, :cond_17

    const-string v4, "arm64"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_17

    const-string v1, "libphantom_arm64.blob"

    return-object v1

    .line 165
    .end local v3  # "abi":Ljava/lang/String;
    :cond_17
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    .line 168
    :cond_1a
    const-string v1, "libphantom_arm.blob"

    return-object v1
.end method

.method static readFully(Ljava/io/InputStream;)[B
    .registers 5
    .param p0, "is"  # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 253
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 254
    .local v0, "out":Ljava/io/ByteArrayOutputStream;
    const/16 v1, 0x2000

    new-array v1, v1, [B

    .line 255
    .local v1, "buf":[B
    :goto_9
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    move v3, v2

    .local v3, "n":I
    if-lez v2, :cond_15

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_9

    .line 256
    :cond_15
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    return-object v2
.end method
