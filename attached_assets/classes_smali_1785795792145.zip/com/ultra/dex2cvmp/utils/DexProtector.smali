.class public Lcom/ultra/dex2cvmp/utils/DexProtector;
.super Ljava/lang/Object;
.source "DexProtector.java"


# static fields
.field private static final dexFiles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field

.field public static mContext:Landroid/content/Context;


# instance fields
.field dexDir:Ljava/io/File;

.field optDir:Ljava/io/File;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 51
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexFiles:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;

    .line 67
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 68
    sput-object p1, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    .line 69
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexFiles:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 70
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strAppDex()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    iput-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    .line 71
    new-instance v0, Ljava/io/File;

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strOpt()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->optDir:Ljava/io/File;

    .line 72
    iget-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->deleteFloor(Ljava/lang/String;)V

    .line 73
    iget-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->mkdir(Ljava/lang/String;)V

    .line 74
    iget-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->optDir:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->mkdir(Ljava/lang/String;)V

    .line 75
    return-void
.end method

.method public static getRealAppClass()Ljava/lang/String;
    .registers 1

    .line 323
    sget-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    return-object v0
.end method

.method private static getRuntimeCertHash(Landroid/content/Context;)[B
    .registers 7
    .param p0, "ctx"  # Landroid/content/Context;

    .line 303
    :try_start_0
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    .line 304
    .local v0, "sha256":Ljava/security/MessageDigest;
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    .line 305
    .local v1, "pm":Landroid/content/pm/PackageManager;
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    .line 307
    .local v2, "pkg":Ljava/lang/String;
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1c

    const/4 v5, 0x0

    if-lt v3, v4, :cond_28

    .line 308
    const/high16 v3, 0x8000000

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v3

    .line 309
    .local v3, "pi":Landroid/content/pm/PackageInfo;
    iget-object v4, v3, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    invoke-virtual {v4}, Landroid/content/pm/SigningInfo;->getApkContentsSigners()[Landroid/content/pm/Signature;

    move-result-object v4

    aget-object v4, v4, v5

    invoke-virtual {v4}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v4

    .line 310
    .end local v3  # "pi":Landroid/content/pm/PackageInfo;
    .local v4, "certDer":[B
    goto :goto_36

    .line 312
    .end local v4  # "certDer":[B
    :cond_28
    const/16 v3, 0x40

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v3

    .line 313
    .restart local v3  # "pi":Landroid/content/pm/PackageInfo;
    iget-object v4, v3, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    aget-object v4, v4, v5

    invoke-virtual {v4}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v4

    .line 315
    .end local v3  # "pi":Landroid/content/pm/PackageInfo;
    .restart local v4  # "certDer":[B
    :goto_36
    invoke-virtual {v0, v4}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v3
    :try_end_3a
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_3a} :catch_3b

    return-object v3

    .line 316
    .end local v0  # "sha256":Ljava/security/MessageDigest;
    .end local v1  # "pm":Landroid/content/pm/PackageManager;
    .end local v2  # "pkg":Ljava/lang/String;
    .end local v4  # "certDer":[B
    :catch_3b
    move-exception v0

    .line 317
    .local v0, "e":Ljava/lang/Exception;
    const/16 v1, 0x20

    new-array v1, v1, [B

    return-object v1
.end method

.method private injectDexElements(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V
    .registers 15
    .param p1, "src"  # Ljava/lang/ClassLoader;
    .param p2, "dst"  # Ljava/lang/ClassLoader;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 214
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    .line 215
    .local v0, "pathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 216
    .local v1, "srcPathList":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDexElements()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    .line 217
    .local v2, "dexElementsField":Ljava/lang/reflect/Field;
    invoke-virtual {v2, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/Object;

    .line 219
    .local v3, "added":[Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v4

    invoke-static {p2, v4}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    .line 220
    .local v4, "dstPathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v4, p2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .line 221
    .local v5, "dstPathList":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDexElements()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v6

    .line 222
    .local v6, "dstDexElemField":Ljava/lang/reflect/Field;
    invoke-virtual {v6, v5}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/Object;

    .line 224
    .local v7, "existing":[Ljava/lang/Object;
    nop

    .line 225
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v8

    array-length v9, v7

    array-length v10, v3

    add-int/2addr v9, v10

    .line 224
    invoke-static {v8, v9}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, [Ljava/lang/Object;

    .line 227
    .local v8, "merged":[Ljava/lang/Object;
    array-length v9, v7

    const/4 v10, 0x0

    invoke-static {v7, v10, v8, v10, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 228
    array-length v9, v7

    array-length v11, v3

    invoke-static {v3, v10, v8, v9, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 229
    invoke-virtual {v6, v5, v8}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 230
    return-void
.end method

.method private invokeMakeElements(Ljava/lang/Object;Ljava/util/List;Ljava/io/File;Ljava/lang/ClassLoader;)[Ljava/lang/Object;
    .registers 22
    .param p1, "pathList"  # Ljava/lang/Object;
    .param p3, "optDir"  # Ljava/io/File;
    .param p4, "loader"  # Ljava/lang/ClassLoader;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;",
            "Ljava/io/File;",
            "Ljava/lang/ClassLoader;",
            ")[",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 251
    .local p2, "files":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 252
    .local v2, "suppressed":Ljava/util/List;, "Ljava/util/List<Ljava/io/IOException;>;"
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMakeDexElements()Ljava/lang/String;

    move-result-object v3

    .line 253
    .local v3, "mde":Ljava/lang/String;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMakePathElements()Ljava/lang/String;

    move-result-object v4

    .line 254
    .local v4, "mpe":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    .line 255
    .local v5, "clazz":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :goto_15
    if-eqz v5, :cond_a9

    const-class v6, Ljava/lang/Object;

    if-eq v5, v6, :cond_a9

    .line 256
    invoke-virtual {v5}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v6

    array-length v7, v6

    const/4 v9, 0x0

    :goto_21
    if-ge v9, v7, :cond_a3

    aget-object v10, v6, v9

    .line 257
    .local v10, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    .line 258
    .local v11, "nm":Ljava/lang/String;
    invoke-virtual {v11, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_38

    invoke-virtual {v11, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_38

    const/16 v16, 0x0

    goto :goto_9f

    .line 259
    :cond_38
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v12

    .line 260
    .local v12, "pt":[Ljava/lang/Class;, "[Ljava/lang/Class<*>;"
    const/4 v13, 0x1

    invoke-virtual {v10, v13}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 261
    array-length v14, v12

    const/4 v15, 0x3

    const/16 v16, 0x0

    const/4 v8, 0x2

    packed-switch v14, :pswitch_data_ba

    goto :goto_9f

    .line 262
    :pswitch_49  #0x4
    const/4 v6, 0x4

    new-array v6, v6, [Ljava/lang/Object;

    aput-object v1, v6, v16

    aput-object p3, v6, v13

    aput-object v2, v6, v8

    aput-object p4, v6, v15

    invoke-virtual {v10, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 264
    :pswitch_5b  #0x3
    const-class v6, Ljava/util/ArrayList;

    aget-object v7, v12, v16

    invoke-virtual {v6, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7e

    .line 265
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-array v9, v15, [Ljava/lang/Object;

    aput-object v6, v9, v16

    aput-object p3, v9, v13

    aput-object v7, v9, v8

    invoke-virtual {v10, v0, v9}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 267
    :cond_7e
    new-array v6, v15, [Ljava/lang/Object;

    aput-object v1, v6, v16

    aput-object p3, v6, v13

    aput-object v2, v6, v8

    invoke-virtual {v10, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 268
    :pswitch_8d  #0x2
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-array v7, v8, [Ljava/lang/Object;

    aput-object v6, v7, v16

    aput-object p3, v7, v13

    invoke-virtual {v10, v0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 256
    .end local v10  # "m":Ljava/lang/reflect/Method;
    .end local v11  # "nm":Ljava/lang/String;
    .end local v12  # "pt":[Ljava/lang/Class;, "[Ljava/lang/Class<*>;"
    :goto_9f
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_21

    .line 271
    :cond_a3
    invoke-virtual {v5}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v5

    goto/16 :goto_15

    .line 273
    :cond_a9
    new-instance v6, Ljava/lang/RuntimeException;

    const/16 v7, 0x11

    new-array v7, v7, [C

    fill-array-data v7, :array_c4

    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v6

    :pswitch_data_ba
    .packed-switch 0x2
        :pswitch_8d  #00000002
        :pswitch_5b  #00000003
        :pswitch_49  #00000004
    .end packed-switch

    :array_c4
    .array-data 2
        0x6es
        0x6fs
        0x20s
        0x6ds
        0x61s
        0x6bs
        0x65s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x20s
        0x66s
        0x6fs
        0x75s
        0x6es
        0x64s
    .end array-data
.end method

.method private static isAllZeros([B)Z
    .registers 5
    .param p0, "b"  # [B

    .line 291
    array-length v0, p0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_3
    if-ge v2, v0, :cond_d

    aget-byte v3, p0, v2

    .local v3, "v":B
    if-eqz v3, :cond_a

    return v1

    .end local v3  # "v":B
    :cond_a
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    .line 292
    :cond_d
    const/4 v0, 0x1

    return v0
.end method

.method private static varargs k([C)Ljava/lang/String;
    .registers 2
    .param p0, "c"  # [C

    .line 56
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method private loadDex(Landroid/content/Context;Ljava/util/List;Ljava/io/File;)V
    .registers 14
    .param p1, "context"  # Landroid/content/Context;
    .param p3, "optDir"  # Ljava/io/File;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 234
    .local p2, "files":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    .line 235
    :cond_7
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    .line 236
    .local v0, "classLoader":Ljava/lang/ClassLoader;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 237
    .local v1, "pathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 238
    .local v2, "pathList":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDexElements()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    .line 239
    .local v3, "dexElementsField":Ljava/lang/reflect/Field;
    invoke-virtual {v3, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Ljava/lang/Object;

    .line 240
    .local v4, "existing":[Ljava/lang/Object;
    invoke-direct {p0, v2, p2, p3, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->invokeMakeElements(Ljava/lang/Object;Ljava/util/List;Ljava/io/File;Ljava/lang/ClassLoader;)[Ljava/lang/Object;

    move-result-object v5

    .line 241
    .local v5, "added":[Ljava/lang/Object;
    nop

    .line 242
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v6

    array-length v7, v4

    array-length v8, v5

    add-int/2addr v7, v8

    .line 241
    invoke-static {v6, v7}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    .line 244
    .local v6, "merged":[Ljava/lang/Object;
    array-length v7, v4

    const/4 v8, 0x0

    invoke-static {v4, v8, v6, v8, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 245
    array-length v7, v4

    array-length v9, v5

    invoke-static {v5, v8, v6, v7, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 246
    invoke-virtual {v3, v2, v6}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 247
    return-void
.end method

.method private loadInMemory(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V
    .registers 11
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "dis"  # Ljava/io/DataInputStream;
    .param p3, "shardCount"  # I
    .param p4, "sizes"  # [I
    .param p5, "key"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 170
    new-array v0, p3, [Ljava/nio/ByteBuffer;

    .line 171
    .local v0, "buffers":[Ljava/nio/ByteBuffer;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_3
    if-ge v1, p3, :cond_19

    .line 172
    aget v2, p4, v1

    new-array v2, v2, [B

    .line 173
    .local v2, "encrypted":[B
    invoke-virtual {p2, v2}, Ljava/io/DataInputStream;->readFully([B)V

    .line 174
    invoke-static {p5, v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptToBytes([B[B)[B

    move-result-object v3

    .line 175
    .local v3, "dexBytes":[B
    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v4

    aput-object v4, v0, v1

    .line 171
    .end local v2  # "encrypted":[B
    .end local v3  # "dexBytes":[B
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    .line 180
    .end local v1  # "i":I
    :cond_19
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    .line 181
    .local v1, "parent":Ljava/lang/ClassLoader;
    new-instance v2, Ldalvik/system/InMemoryDexClassLoader;

    invoke-direct {v2, v0, v1}, Ldalvik/system/InMemoryDexClassLoader;-><init>([Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V

    .line 184
    .local v2, "inMemory":Ljava/lang/ClassLoader;
    invoke-direct {p0, v2, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->injectDexElements(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V

    .line 185
    return-void
.end method

.method private loadViaFiles(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V
    .registers 15
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "dis"  # Ljava/io/DataInputStream;
    .param p3, "shardCount"  # I
    .param p4, "sizes"  # [I
    .param p5, "key"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 191
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strAppDex()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    .line 192
    .local v0, "dir":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_12

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 193
    :cond_12
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 195
    .local v2, "files":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_18
    if-ge v3, p3, :cond_62

    .line 196
    aget v4, p4, v3

    new-array v4, v4, [B

    .line 197
    .local v4, "encrypted":[B
    invoke-virtual {p2, v4}, Ljava/io/DataInputStream;->readFully([B)V

    .line 198
    invoke-static {p5, v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptToBytes([B[B)[B

    move-result-object v5

    .line 200
    .local v5, "dexBytes":[B
    new-instance v6, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strShard()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    add-int/lit8 v8, v3, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDotDex()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v0, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 201
    .local v6, "outFile":Ljava/io/File;
    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 202
    .local v7, "fos":Ljava/io/FileOutputStream;
    :try_start_4e
    invoke-virtual {v7, v5}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_51
    .catchall {:try_start_4e .. :try_end_51} :catchall_5d

    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V

    .line 203
    invoke-virtual {v6, v1, v1}, Ljava/io/File;->setWritable(ZZ)Z

    .line 204
    invoke-interface {v2, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 195
    .end local v4  # "encrypted":[B
    .end local v5  # "dexBytes":[B
    .end local v6  # "outFile":Ljava/io/File;
    .end local v7  # "fos":Ljava/io/FileOutputStream;
    add-int/lit8 v3, v3, 0x1

    goto :goto_18

    .line 202
    .restart local v4  # "encrypted":[B
    .restart local v5  # "dexBytes":[B
    .restart local v6  # "outFile":Ljava/io/File;
    .restart local v7  # "fos":Ljava/io/FileOutputStream;
    :catchall_5d
    move-exception v1

    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V

    throw v1

    .line 207
    .end local v3  # "i":I
    .end local v4  # "encrypted":[B
    .end local v5  # "dexBytes":[B
    .end local v6  # "outFile":Ljava/io/File;
    .end local v7  # "fos":Ljava/io/FileOutputStream;
    :cond_62
    iget-object v1, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    invoke-direct {p0, p1, v2, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadDex(Landroid/content/Context;Ljava/util/List;Ljava/io/File;)V

    .line 208
    return-void
.end method

.method private static readAsset(Landroid/content/Context;Ljava/lang/String;)[B
    .registers 4
    .param p0, "ctx"  # Landroid/content/Context;
    .param p1, "path"  # Ljava/lang/String;

    .line 280
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 281
    .local v0, "is":Ljava/io/InputStream;
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v1

    .line 282
    .local v1, "data":[B
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_f} :catch_10

    .line 283
    return-object v1

    .line 284
    .end local v0  # "is":Ljava/io/InputStream;
    .end local v1  # "data":[B
    :catch_10
    move-exception v0

    .line 285
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method

.method private static strAppDex()Ljava/lang/String;
    .registers 1

    .line 57
    const/4 v0, 0x7

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x61s
        0x70s
        0x70s
        0x5fs
        0x64s
        0x65s
        0x78s
    .end array-data
.end method

.method private static strDexElements()Ljava/lang/String;
    .registers 1

    .line 62
    const/16 v0, 0xb

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x64s
        0x65s
        0x78s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x65s
        0x6es
        0x74s
        0x73s
    .end array-data
.end method

.method private static strDotDex()Ljava/lang/String;
    .registers 1

    .line 60
    const/4 v0, 0x4

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x2es
        0x64s
        0x65s
        0x78s
    .end array-data
.end method

.method private static strMakeDexElements()Ljava/lang/String;
    .registers 1

    .line 63
    const/16 v0, 0xf

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x6ds
        0x61s
        0x6bs
        0x65s
        0x44s
        0x65s
        0x78s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x65s
        0x6es
        0x74s
        0x73s
    .end array-data
.end method

.method private static strMakePathElements()Ljava/lang/String;
    .registers 1

    .line 64
    const/16 v0, 0x10

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x6ds
        0x61s
        0x6bs
        0x65s
        0x50s
        0x61s
        0x74s
        0x68s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x65s
        0x6es
        0x74s
        0x73s
    .end array-data
.end method

.method private static strOpt()Ljava/lang/String;
    .registers 1

    .line 58
    const/4 v0, 0x3

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x6fs
        0x70s
        0x74s
    .end array-data
.end method

.method private static strPathList()Ljava/lang/String;
    .registers 1

    .line 61
    const/16 v0, 0x8

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x70s
        0x61s
        0x74s
        0x68s
        0x4cs
        0x69s
        0x73s
        0x74s
    .end array-data
.end method

.method private static strShard()Ljava/lang/String;
    .registers 1

    .line 59
    const/4 v0, 0x6

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x73s
        0x68s
        0x61s
        0x72s
        0x64s
        0x2ds
    .end array-data
.end method


# virtual methods
.method public install(Landroid/content/Context;)V
    .registers 14
    .param p1, "context"  # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 79
    invoke-static {p1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->loadPhantomLib(Landroid/content/Context;)V

    .line 83
    const/4 v1, 0x0

    :try_start_4
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v2, "phantom/app.cfg"

    invoke-virtual {v0, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 84
    .local v0, "ris":Ljava/io/InputStream;
    const/16 v2, 0x200

    new-array v2, v2, [B

    .line 85
    .local v2, "buf":[B
    invoke-virtual {v0, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    .line 86
    .local v3, "n":I
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 87
    if-lez v3, :cond_32

    .line 88
    new-instance v4, Ljava/lang/String;

    const-string v5, "UTF-8"

    invoke-direct {v4, v2, v1, v3, v5}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    .line 89
    .local v4, "realApp":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_32

    sput-object v4, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_30} :catch_31

    goto :goto_32

    .line 91
    .end local v0  # "ris":Ljava/io/InputStream;
    .end local v2  # "buf":[B
    .end local v3  # "n":I
    .end local v4  # "realApp":Ljava/lang/String;
    :catch_31
    move-exception v0

    :cond_32
    :goto_32
    nop

    .line 94
    const-string v0, "phantom/ph_salt"

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->readAsset(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object v2

    .line 95
    .local v2, "salt":[B
    if-eqz v2, :cond_dd

    array-length v0, v2

    const/16 v3, 0x10

    if-ne v0, v3, :cond_dd

    .line 113
    const-string v0, "phantom/ph_cert"

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->readAsset(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object v0

    .line 114
    .local v0, "storedCertHash":[B
    const/16 v3, 0x20

    if-eqz v0, :cond_50

    array-length v4, v0

    if-eq v4, v3, :cond_4e

    goto :goto_50

    :cond_4e
    move-object v3, v0

    goto :goto_53

    .line 115
    :cond_50
    :goto_50
    new-array v0, v3, [B

    move-object v3, v0

    .line 118
    .end local v0  # "storedCertHash":[B
    .local v3, "storedCertHash":[B
    :goto_53
    invoke-static {v3}, Lcom/ultra/dex2cvmp/utils/DexProtector;->isAllZeros([B)Z

    move-result v0

    if-nez v0, :cond_7e

    .line 121
    invoke-static {p1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->getRuntimeCertHash(Landroid/content/Context;)[B

    move-result-object v0

    .line 122
    .local v0, "runtimeCertHash":[B
    invoke-static {v3, v0}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v4

    if-eqz v4, :cond_67

    .line 128
    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([BB)V

    goto :goto_7e

    .line 124
    :cond_67
    invoke-static {v3, v1}, Ljava/util/Arrays;->fill([BB)V

    .line 125
    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([BB)V

    .line 126
    new-instance v1, Ljava/lang/SecurityException;

    const/16 v4, 0xd

    new-array v4, v4, [C

    fill-array-data v4, :array_f0

    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 136
    .end local v0  # "runtimeCertHash":[B
    :cond_7e
    :goto_7e
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 137
    invoke-virtual {v0, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v4

    .line 138
    .local v4, "pkgNameUtf8":[B
    invoke-static {v2, v3, v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nativeGetKey([B[B[B)[B

    move-result-object v10

    .line 142
    .local v10, "key":[B
    :try_start_8c
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v5, "phantom/phantom.vmp"

    invoke-virtual {v0, v5}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 143
    .local v0, "bundleStream":Ljava/io/InputStream;
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v5

    move-object v11, v5

    .line 144
    .local v11, "bundleBytes":[B
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 146
    new-instance v7, Ljava/io/DataInputStream;

    new-instance v5, Ljava/io/ByteArrayInputStream;

    invoke-direct {v5, v11}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v7, v5}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 147
    .local v7, "dis":Ljava/io/DataInputStream;
    invoke-virtual {v7}, Ljava/io/DataInputStream;->readInt()I

    move-result v8

    .line 148
    .local v8, "shardCount":I
    new-array v9, v8, [I
    :try_end_b0
    .catchall {:try_start_8c .. :try_end_b0} :catchall_d7

    .line 149
    .local v9, "sizes":[I
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_b1
    if-ge v5, v8, :cond_bf

    :try_start_b3
    invoke-virtual {v7}, Ljava/io/DataInputStream;->readInt()I

    move-result v6

    aput v6, v9, v5
    :try_end_b9
    .catchall {:try_start_b3 .. :try_end_b9} :catchall_bc

    add-int/lit8 v5, v5, 0x1

    goto :goto_b1

    .line 160
    .end local v0  # "bundleStream":Ljava/io/InputStream;
    .end local v5  # "i":I
    .end local v7  # "dis":Ljava/io/DataInputStream;
    .end local v8  # "shardCount":I
    .end local v9  # "sizes":[I
    .end local v11  # "bundleBytes":[B
    :catchall_bc
    move-exception v0

    move-object v6, p1

    goto :goto_d9

    .line 151
    .restart local v0  # "bundleStream":Ljava/io/InputStream;
    .restart local v7  # "dis":Ljava/io/DataInputStream;
    .restart local v8  # "shardCount":I
    .restart local v9  # "sizes":[I
    .restart local v11  # "bundleBytes":[B
    :cond_bf
    :try_start_bf
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_c1
    .catchall {:try_start_bf .. :try_end_c1} :catchall_d7

    const/16 v6, 0x1b

    if-lt v5, v6, :cond_cb

    .line 153
    move-object v5, p0

    move-object v6, p1

    .end local p1  # "context":Landroid/content/Context;
    .local v6, "context":Landroid/content/Context;
    :try_start_c7
    invoke-direct/range {v5 .. v10}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadInMemory(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V

    goto :goto_d0

    .line 156
    .end local v6  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    :cond_cb
    move-object v6, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v6  # "context":Landroid/content/Context;
    move-object v5, p0

    invoke-direct/range {v5 .. v10}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadViaFiles(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V
    :try_end_d0
    .catchall {:try_start_c7 .. :try_end_d0} :catchall_d5

    .line 160
    .end local v0  # "bundleStream":Ljava/io/InputStream;
    .end local v7  # "dis":Ljava/io/DataInputStream;
    .end local v8  # "shardCount":I
    .end local v9  # "sizes":[I
    .end local v11  # "bundleBytes":[B
    :goto_d0
    invoke-static {v10, v1}, Ljava/util/Arrays;->fill([BB)V

    .line 161
    nop

    .line 162
    return-void

    .line 160
    :catchall_d5
    move-exception v0

    goto :goto_d9

    .end local v6  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    :catchall_d7
    move-exception v0

    move-object v6, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v6  # "context":Landroid/content/Context;
    :goto_d9
    invoke-static {v10, v1}, Ljava/util/Arrays;->fill([BB)V

    .line 161
    throw v0

    .line 95
    .end local v3  # "storedCertHash":[B
    .end local v4  # "pkgNameUtf8":[B
    .end local v6  # "context":Landroid/content/Context;
    .end local v10  # "key":[B
    .restart local p1  # "context":Landroid/content/Context;
    :cond_dd
    move-object v6, p1

    .line 96
    .end local p1  # "context":Landroid/content/Context;
    .restart local v6  # "context":Landroid/content/Context;
    new-instance p1, Ljava/lang/RuntimeException;

    const/16 v0, 0x8

    new-array v0, v0, [C

    fill-array-data v0, :array_102

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :array_f0
    .array-data 2
        0x63s
        0x65s
        0x72s
        0x74s
        0x20s
        0x6ds
        0x69s
        0x73s
        0x6ds
        0x61s
        0x74s
        0x63s
        0x68s
    .end array-data

    nop

    :array_102
    .array-data 2
        0x62s
        0x61s
        0x64s
        0x20s
        0x73s
        0x61s
        0x6cs
        0x74s
    .end array-data
.end method
