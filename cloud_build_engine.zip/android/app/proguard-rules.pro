# ── App package — keep everything, prevent ALL obfuscation ──────────────────
-keep class com.cloud.build.engine.** { *; }
-keepclassmembers class com.cloud.build.engine.** { *; }
-keepnames class com.cloud.build.engine.** { *; }

# ── Flutter engine ────────────────────────────────────────────────────────────
-keep class io.flutter.** { *; }
-keep class io.flutter.embedding.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**    { *; }
-keep class io.flutter.view.**    { *; }
-keep class io.flutter.app.**     { *; }
-dontwarn io.flutter.**

# ── Dart VM / JNI entry points ─────────────────────────────────────────────────
-keep class * extends io.flutter.embedding.engine.FlutterEngine { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ── Native / JNI ───────────────────────────────────────────────────────────────
# NativeSecrets is called from C via JNI — class name must be exact
-keep class com.cloud.build.engine.NativeSecrets { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# ── Flutter plugins ───────────────────────────────────────────────────────────
-keep class com.baseflow.** { *; }
-keep class io.github.** { *; }
-keep class com.ryanheise.** { *; }
-dontwarn com.ryanheise.**

# flutter_secure_storage
-keep class com.it_nomads.fluttersecurestorage.** { *; }

# workmanager
-keep class be.tramckrijte.workmanager.** { *; }
-keep class androidx.work.** { *; }
-keep interface androidx.work.** { *; }
-keepclassmembers class * extends androidx.work.Worker { *; }
-keepclassmembers class * extends androidx.work.ListenableWorker { *; }

# flutter_local_notifications
-keep class com.dexterous.flutterlocalnotifications.** { *; }

# permission_handler
-keep class com.baseflow.permissionhandler.** { *; }

# file_picker
-keep class com.mr.flutter.plugin.filepicker.** { *; }

# open_file
-keep class com.crazecoder.openfile.** { *; }

# url_launcher
-keep class io.flutter.plugins.urllauncher.** { *; }

# path_provider
-keep class io.flutter.plugins.pathprovider.** { *; }

# shared_preferences
-keep class io.flutter.plugins.sharedpreferences.** { *; }

# ── AndroidX / Jetpack ────────────────────────────────────────────────────────
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# ── Kotlin ────────────────────────────────────────────────────────────────────
-keep class kotlin.** { *; }
-keep class kotlinx.** { *; }
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ── OkHttp / Conscrypt (used by Flutter's HTTP stack) ─────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn org.conscrypt.**

# ── Serialization / reflection guards ─────────────────────────────────────────
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes EnclosingMethod
-keepattributes InnerClasses
-keepattributes SourceFile,LineNumberTable

# ── R8 full-mode compatibility ─────────────────────────────────────────────────
-allowaccessmodification
-repackageclasses 'x'
