class BuildJob {
  final String id;
  final String appName;
  final String packageName;
  final String sourceUrl;
  final String flutterVersion;
  final String buildMode;
  final int    runId;
  String       status;
  String?      conclusion;
  String?      downloadUrl;
  String?      artifactName;
  int?         sourceAssetId;   // GitHub Release asset ID — deleted on cancel or failure
  String?      workerJobId;     // Cloudflare Worker job_id (timestamp string) for /artifact
  String?      apkPath;         // Local path where the APK ZIP was saved after auto-download
  bool         armorEnabled;    // Whether App Armor 9-layer protection was requested
  final DateTime createdAt;
  DateTime?    updatedAt;

  BuildJob({
    required this.id,
    required this.appName,
    required this.packageName,
    required this.sourceUrl,
    required this.flutterVersion,
    this.buildMode = 'release',
    required this.runId,
    required this.status,
    this.conclusion,
    this.downloadUrl,
    this.artifactName,
    this.sourceAssetId,
    this.workerJobId,
    this.apkPath,
    this.armorEnabled = false,
    required this.createdAt,
    this.updatedAt,
  });

  factory BuildJob.fromJson(Map<String, dynamic> j) => BuildJob(
    id:             j['id'],
    appName:        j['appName'],
    packageName:    j['packageName'],
    sourceUrl:      j['sourceUrl'] ?? '',
    flutterVersion: j['flutterVersion'] ?? '3.29.1',
    buildMode:      j['buildMode'] ?? 'release',
    runId:          j['runId'],
    status:         j['status'],
    conclusion:     j['conclusion'],
    downloadUrl:    j['downloadUrl'],
    artifactName:   j['artifactName'],
    sourceAssetId:  j['sourceAssetId'] as int?,
    workerJobId:    j['workerJobId']   as String?,
    apkPath:        j['apkPath']       as String?,
    armorEnabled:   j['armorEnabled']  as bool? ?? false,
    createdAt:      DateTime.parse(j['createdAt']),
    updatedAt:      j['updatedAt'] != null ? DateTime.parse(j['updatedAt']) : null,
  );

  Map<String, dynamic> toJson() => {
    'id':             id,
    'appName':        appName,
    'packageName':    packageName,
    'sourceUrl':      sourceUrl,
    'flutterVersion': flutterVersion,
    'buildMode':      buildMode,
    'runId':          runId,
    'status':         status,
    'conclusion':     conclusion,
    'downloadUrl':    downloadUrl,
    'artifactName':   artifactName,
    'sourceAssetId':  sourceAssetId,
    'workerJobId':    workerJobId,
    'apkPath':        apkPath,
    'armorEnabled':   armorEnabled,
    'createdAt':      createdAt.toIso8601String(),
    'updatedAt':      updatedAt?.toIso8601String(),
  };

  bool get isRunning  => status == 'in_progress' || status == 'queued' || status == 'waiting';
  bool get isSuccess  => status == 'completed' && conclusion == 'success';
  bool get isFailed   => status == 'completed' && conclusion != 'success';
  bool get hasOutput  => downloadUrl != null || (isSuccess && workerJobId != null);

  String get statusLabel {
    if (status == 'queued')       return 'Queued';
    if (status == 'in_progress')  return 'Building';
    if (status == 'waiting')      return 'Waiting';
    if (isSuccess)                return 'Success';
    if (isFailed)                 return conclusion == 'cancelled' ? 'Cancelled' : 'Failed';
    return status;
  }
}
