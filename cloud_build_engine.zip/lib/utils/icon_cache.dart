import 'dart:typed_data';

class IconCache {
  IconCache._();

  static final Map<String, Uint8List> _store = {};

  static void set(String jobId, Uint8List bytes) => _store[jobId] = bytes;

  static Uint8List? get(String jobId) => _store[jobId];

  static void remove(String jobId) => _store.remove(jobId);
}
