.class public Lcom/ultra/dex2cvmp/utils/FileUtils;
.super Ljava/lang/Object;
.source "FileUtils.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static delAllFile(Ljava/lang/String;)Z
    .registers 10
    .param p0, "path"  # Ljava/lang/String;

    .line 22
    const/4 v0, 0x0

    .line 23
    .local v0, "flag":Z
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 24
    .local v1, "file":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_d

    .line 25
    return v0

    .line 27
    :cond_d
    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v2

    if-nez v2, :cond_14

    .line 28
    return v0

    .line 30
    :cond_14
    invoke-virtual {v1}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v2

    .line 31
    .local v2, "tempList":[Ljava/lang/String;
    if-nez v2, :cond_1b

    return v0

    .line 33
    :cond_1b
    array-length v3, v2

    const/4 v4, 0x0

    :goto_1d
    if-ge v4, v3, :cond_a2

    aget-object v5, v2, v4

    .line 34
    .local v5, "s":Ljava/lang/String;
    sget-object v6, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {p0, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_40

    .line 35
    new-instance v6, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .local v6, "temp":Ljava/io/File;
    goto :goto_5c

    .line 37
    .end local v6  # "temp":Ljava/io/File;
    :cond_40
    new-instance v6, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    sget-object v8, Ljava/io/File;->separator:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 39
    .restart local v6  # "temp":Ljava/io/File;
    :goto_5c
    invoke-virtual {v6}, Ljava/io/File;->isFile()Z

    move-result v7

    if-eqz v7, :cond_65

    .line 40
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    .line 42
    :cond_65
    invoke-virtual {v6}, Ljava/io/File;->isDirectory()Z

    move-result v7

    if-eqz v7, :cond_9e

    .line 43
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "/"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/FileUtils;->delAllFile(Ljava/lang/String;)Z

    .line 44
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/FileUtils;->delFolder(Ljava/lang/String;)V

    .line 45
    const/4 v0, 0x1

    .line 33
    .end local v5  # "s":Ljava/lang/String;
    :cond_9e
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_1d

    .line 48
    .end local v6  # "temp":Ljava/io/File;
    :cond_a2
    return v0
.end method

.method public static delFolder(Ljava/lang/String;)V
    .registers 3
    .param p0, "folderPath"  # Ljava/lang/String;

    .line 11
    :try_start_0
    invoke-static {p0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->delAllFile(Ljava/lang/String;)Z

    .line 12
    move-object v0, p0

    .line 13
    .local v0, "filePath":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v1

    .line 14
    .end local v0  # "filePath":Ljava/lang/String;
    .local v1, "filePath":Ljava/lang/String;
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 15
    .local v0, "myFilePath":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->delete()Z
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_10} :catch_12

    .line 18
    nop

    .end local v0  # "myFilePath":Ljava/io/File;
    .end local v1  # "filePath":Ljava/lang/String;
    goto :goto_16

    .line 16
    :catch_12
    move-exception v0

    .line 17
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 19
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_16
    return-void
.end method

.method public static delete()V
    .registers 6

    .line 105
    :try_start_0
    const-string v0, "java.io.File"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 106
    .local v0, "main":Ljava/lang/Class;
    const-string v1, "delete"

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 107
    .local v1, "method":Ljava/lang/reflect/Method;
    invoke-virtual {v1, v2}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 108
    new-instance v3, Ljava/lang/Object;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4
    :try_end_20
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_20} :catch_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_20} :catch_2f
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_20} :catch_2f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_20} :catch_2f

    :try_start_20
    new-array v2, v2, [Ljava/lang/Object;

    aput-object v4, v2, v5
    :try_end_24
    .catch Ljava/lang/ClassNotFoundException; {:try_start_20 .. :try_end_24} :catch_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_20 .. :try_end_24} :catch_2d
    .catch Ljava/lang/IllegalAccessException; {:try_start_20 .. :try_end_24} :catch_2b
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_20 .. :try_end_24} :catch_29

    :try_start_24
    invoke-virtual {v1, v3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_27
    .catch Ljava/lang/ClassNotFoundException; {:try_start_24 .. :try_end_27} :catch_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_24 .. :try_end_27} :catch_2f
    .catch Ljava/lang/IllegalAccessException; {:try_start_24 .. :try_end_27} :catch_2f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_24 .. :try_end_27} :catch_2f

    .line 111
    nop

    .end local v0  # "main":Ljava/lang/Class;
    .end local v1  # "method":Ljava/lang/reflect/Method;
    goto :goto_33

    .line 109
    :catch_29
    move-exception v0

    goto :goto_30

    :catch_2b
    move-exception v0

    goto :goto_30

    :catch_2d
    move-exception v0

    goto :goto_30

    :catch_2f
    move-exception v0

    .line 110
    .local v0, "a":Ljava/lang/ReflectiveOperationException;
    :goto_30
    invoke-virtual {v0}, Ljava/lang/ReflectiveOperationException;->printStackTrace()V

    .line 112
    .end local v0  # "a":Ljava/lang/ReflectiveOperationException;
    :goto_33
    return-void
.end method

.method public static deleteFiles(Ljava/io/File;)V
    .registers 15
    .param p0, "path"  # Ljava/io/File;

    .line 81
    :try_start_0
    const-string v0, "java.io.File"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 82
    .local v0, "main":Ljava/lang/Class;
    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/Class;

    const-class v3, Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    .line 83
    .local v2, "contructor":Ljava/lang/reflect/Constructor;
    const/4 v3, 0x2

    new-array v5, v3, [Ljava/lang/Class;

    const-class v6, Ljava/lang/String;

    aput-object v6, v5, v4

    const-class v6, Ljava/lang/String;

    aput-object v6, v5, v1

    invoke-virtual {v0, v5}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v5

    .line 84
    .local v5, "contructor2":Ljava/lang/reflect/Constructor;
    invoke-virtual {p0}, Ljava/io/File;->toString()Ljava/lang/String;

    move-result-object v6

    new-array v7, v1, [Ljava/lang/Object;

    aput-object v6, v7, v4

    invoke-virtual {v2, v7}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    .line 85
    .local v6, "obj":Ljava/lang/Object;
    const-string v7, "delete"

    new-array v8, v4, [Ljava/lang/Class;

    invoke-virtual {v0, v7, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v7

    .line 86
    .local v7, "method":Ljava/lang/reflect/Method;
    invoke-virtual {v7, v1}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 87
    move-object v8, v6

    check-cast v8, Ljava/io/File;

    invoke-virtual {v8}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v8

    .line 88
    .local v8, "entries":[Ljava/lang/String;
    if-nez v8, :cond_44

    new-array v9, v4, [Ljava/lang/String;

    move-object v8, v9

    .line 89
    :cond_44
    array-length v9, v8

    const/4 v10, 0x0

    :goto_46
    if-ge v10, v9, :cond_64

    aget-object v11, v8, v10

    .line 90
    .local v11, "s":Ljava/lang/String;
    move-object v12, v6

    check-cast v12, Ljava/io/File;

    invoke-virtual {v12}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v12

    new-array v13, v3, [Ljava/lang/Object;

    aput-object v12, v13, v4

    aput-object v11, v13, v1

    invoke-virtual {v5, v13}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    .line 91
    .local v12, "obj2":Ljava/lang/Object;
    new-array v13, v4, [Ljava/lang/Object;

    invoke-virtual {v7, v12, v13}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    nop

    .end local v11  # "s":Ljava/lang/String;
    .end local v12  # "obj2":Ljava/lang/Object;
    add-int/lit8 v10, v10, 0x1

    goto :goto_46

    .line 93
    :cond_64
    new-array v1, v4, [Ljava/lang/Object;

    invoke-virtual {v7, v6, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    .line 94
    .local v1, "b":Z
    sget-object v3, Ljava/lang/System;->out:Ljava/io/PrintStream;

    invoke-virtual {v3, v1}, Ljava/io/PrintStream;->println(Z)V
    :try_end_75
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_75} :catch_80
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_75} :catch_7e
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_75} :catch_7c
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_75} :catch_7a
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_75} :catch_78
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_75} :catch_76

    .line 97
    .end local v0  # "main":Ljava/lang/Class;
    .end local v1  # "b":Z
    .end local v2  # "contructor":Ljava/lang/reflect/Constructor;
    .end local v5  # "contructor2":Ljava/lang/reflect/Constructor;
    .end local v6  # "obj":Ljava/lang/Object;
    .end local v7  # "method":Ljava/lang/reflect/Method;
    .end local v8  # "entries":[Ljava/lang/String;
    goto :goto_84

    .line 95
    :catch_76
    move-exception v0

    goto :goto_81

    :catch_78
    move-exception v0

    goto :goto_81

    :catch_7a
    move-exception v0

    goto :goto_81

    :catch_7c
    move-exception v0

    goto :goto_81

    :catch_7e
    move-exception v0

    goto :goto_81

    :catch_80
    move-exception v0

    .line 96
    .local v0, "a":Ljava/lang/Exception;
    :goto_81
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 98
    .end local v0  # "a":Ljava/lang/Exception;
    :goto_84
    return-void
.end method

.method public static deleteFloor(Ljava/lang/String;)V
    .registers 7
    .param p0, "dir"  # Ljava/lang/String;

    .line 63
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    .line 64
    .local v0, "files":[Ljava/io/File;
    if-nez v0, :cond_c

    return-void

    .line 65
    :cond_c
    array-length v1, v0

    const/4 v2, 0x0

    :goto_e
    if-ge v2, v1, :cond_2f

    aget-object v3, v0, v2

    .line 66
    .local v3, "file":Ljava/io/File;
    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v4

    if-eqz v4, :cond_25

    .line 67
    new-instance v4, Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/FileUtils;->deleteFiles(Ljava/io/File;)V

    goto :goto_2c

    .line 69
    :cond_25
    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/FileUtils;->deleteFloor(Ljava/lang/String;)V

    .line 65
    .end local v3  # "file":Ljava/io/File;
    :goto_2c
    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    .line 72
    :cond_2f
    return-void
.end method

.method public static mkdir(Ljava/lang/String;)V
    .registers 3
    .param p0, "path"  # Ljava/lang/String;

    .line 53
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 54
    .local v0, "file":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_e

    .line 55
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_e} :catch_f

    .line 59
    .end local v0  # "file":Ljava/io/File;
    :cond_e
    goto :goto_13

    .line 57
    :catch_f
    move-exception v0

    .line 58
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 60
    .end local v0  # "e":Ljava/lang/Exception;
    :goto_13
    return-void
.end method
