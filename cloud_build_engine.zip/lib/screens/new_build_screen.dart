import 'dart:io';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:archive/archive.dart';
import '../models/build_job.dart';
import '../services/worker_service.dart';
import '../theme/app_theme.dart';
import '../utils/storage_helper.dart';
import '../utils/icon_cache.dart';

class NewBuildScreen extends StatefulWidget {
  const NewBuildScreen({super.key});

  @override
  State<NewBuildScreen> createState() => _NewBuildScreenState();
}

class _NewBuildScreenState extends State<NewBuildScreen> {
  String  _mode            = 'release';
  bool    _submitting      = false;
  bool    _isUploading     = false;
  double? _uploadProgress;
  String? _uploadedFileName;
  int?    _uploadedAssetId;
  String? _workerJobId;
  bool    _isFlutter       = false;
  bool    _armorEnabled    = false;

  final _buildModes = ['release', 'debug', 'profile'];
  String?    _detectedPackageName;
  Uint8List? _detectedIcon;

  // Density priority — highest res first
  static const _densities = [
    'mipmap-xxxhdpi',
    'mipmap-xxhdpi',
    'mipmap-xhdpi',
    'mipmap-hdpi',
    'mipmap-mdpi',
  ];

  // ── Deep ZIP scanner — all project types ─────────────────────────────────
  //
  //  Package name priority:
  //    1. build.gradle (Groovy) — applicationId
  //    2. build.gradle.kts (Kotlin DSL) — applicationId =
  //    3. build.gradle.kts — namespace = (last resort gradle)
  //    4. AndroidManifest.xml — package= attribute (old AGP style)
  //    5. app.json — expo.android.package / android.package (Expo / RN)
  //    6. app.config.js / app.config.ts — android.package (Expo dynamic config)
  //    7. pubspec.yaml + android manifest combo (Flutter)
  //    8. package.json — name field, slugified (React Native bare, last resort)
  //    9. ZIP filename — sanitised into a valid package name (guaranteed default)
  //
  //  Icon priority:
  //    1. mipmap-xxxhdpi → mdpi  ic_launcher.png
  //    2. mipmap-xxxhdpi → mdpi  ic_launcher.webp
  //    3. Adaptive-icon foreground PNG/WebP in any mipmap folder
  //    4. Drawable PNG/WebP matching android:icon ref in manifest
  //    5. Expo assets/images/icon.png  or  assets/icon.png
  //    6. foregroundImage from app.json adaptive icon
  //    7. Any .png inside a drawable* folder (last resort)
  //    — If nothing found: icon stays null, build proceeds normally
  //
  Future<void> _scanZip(File zip, {String zipFileName = ''}) async {
    try {
      final bytes   = await zip.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);

      // ── Package name candidates ───────────────────────────────────────────
      // Prefer app-level gradle (contains 'app/') over root gradle
      String? fromGradleApp;      // app/build.gradle (Groovy)
      String? fromGradleRoot;     // root build.gradle (Groovy)
      String? fromGradleKtsApp;   // app/build.gradle.kts (Kotlin DSL)
      String? fromGradleKtsRoot;  // root build.gradle.kts (Kotlin DSL)
      String? fromNamespace;      // namespace = "..." (Kotlin DSL fallback)
      String? fromManifest;       // AndroidManifest.xml package=
      String? fromAppJson;        // Expo app.json
      String? fromAppConfig;      // Expo app.config.js / .ts
      String? fromPubspec;        // Flutter pubspec.yaml (project name hint only)
      String? fromPackageJson;    // React Native package.json name

      // ── Icon candidates ───────────────────────────────────────────────────
      final Map<String, Uint8List> mipmapPng  = {};   // density → bytes
      final Map<String, Uint8List> mipmapWebp = {};
      final Map<String, Uint8List> drawables  = {};   // basename → bytes
      Uint8List? adaptiveFgIcon;   // adaptive foreground PNG/WebP
      Uint8List? expoIcon;         // assets/images/icon.png
      String?    manifestIconRef;  // e.g. "skull" from android:icon
      bool       isFlutter        = false;

      for (final entry in archive) {
        if (!entry.isFile) continue;
        final name   = entry.name;
        final lower  = name.toLowerCase();
        final seg    = name.split('/');
        final fname  = seg.last;
        final flower = fname.toLowerCase();

        // Lazy text decode — only for files we actually inspect as text
        String? _text;
        String text() {
          _text ??= () {
            try { return utf8.decode(entry.content as List<int>, allowMalformed: true); }
            catch (_) { return ''; }
          }();
          return _text!;
        }

        // ── Gradle (Groovy DSL) ──────────────────────────────────────────────
        if (flower == 'build.gradle') {
          final t = text();
          final m = RegExp(r'''applicationId\s+['"]([\w.]+)['"]''').firstMatch(t);
          if (m != null) {
            final pkg = m.group(1)!;
            if (lower.contains('/app/')) fromGradleApp  ??= pkg;
            else                        fromGradleRoot ??= pkg;
          }
        }

        // ── Gradle (Kotlin DSL) ──────────────────────────────────────────────
        if (flower == 'build.gradle.kts') {
          final t = text();
          // applicationId = "..."
          var m = RegExp(r'''applicationId\s*=\s*["']([\w.]+)["']''').firstMatch(t);
          if (m != null) {
            final pkg = m.group(1)!;
            if (lower.contains('/app/')) fromGradleKtsApp  ??= pkg;
            else                        fromGradleKtsRoot ??= pkg;
          } else {
            // namespace = "..." (Kotlin DSL, used as package in modern AGP)
            m = RegExp(r'''namespace\s*=\s*["']([\w.]+)["']''').firstMatch(t);
            if (m != null) fromNamespace ??= m.group(1);
          }
        }

        // ── AndroidManifest.xml ──────────────────────────────────────────────
        if (flower == 'androidmanifest.xml') {
          final t = text();
          // package= attribute (old-style, pre AGP 7)
          if (fromManifest == null) {
            final m = RegExp(r'''package\s*=\s*["']([\w.]+)["']''').firstMatch(t);
            if (m != null) fromManifest = m.group(1);
          }
          // android:icon reference — e.g. @drawable/skull  or  @mipmap/ic_launcher
          if (manifestIconRef == null) {
            final m = RegExp(r'''android:icon\s*=\s*["']@(?:drawable|mipmap)/([\w]+)["']''')
                        .firstMatch(t);
            if (m != null) manifestIconRef = m.group(1)!.toLowerCase();
          }
        }

        // ── Expo / React Native: app.json ────────────────────────────────────
        if (flower == 'app.json' && fromAppJson == null) {
          try {
            final j = jsonDecode(text());
            final pkg = (j['expo']?['android']?['package']
                      ?? j['android']?['package']) as String?;
            if (pkg != null && pkg.isNotEmpty) fromAppJson = pkg;

            // Expo adaptive icon foreground image path (for icon resolution later)
            // just note its existence; the actual file will be caught below
          } catch (_) {}
        }

        // ── Expo dynamic config: app.config.js / app.config.ts ───────────────
        if ((flower == 'app.config.js' || flower == 'app.config.ts') &&
            fromAppConfig == null) {
          final t = text();
          // android: { package: "com.example.app" }
          final m = RegExp(r'''package\s*:\s*["']([\w.]+)["']''').firstMatch(t);
          if (m != null) fromAppConfig = m.group(1);
        }

        // ── Flutter: pubspec.yaml ────────────────────────────────────────────
        // Flutter doesn't store the package name in pubspec — it's in the
        // android/build.gradle as usual. We capture the project name as a hint
        // to build a fallback package name only if everything else fails.
        if (flower == 'pubspec.yaml' && fromPubspec == null) {
          final t = text();
          final m = RegExp(r'''^name\s*:\s*([\w_-]+)''', multiLine: true).firstMatch(t);
          if (m != null) fromPubspec = m.group(1);
          if (t.contains('sdk: flutter') || t.contains("sdk: 'flutter'") ||
              t.contains('sdk: "flutter"')) {
            isFlutter = true;
          }
        }

        // ── React Native / Hermes: package.json ──────────────────────────────
        // Only use the npm package name as a last resort.
        if (flower == 'package.json' && fromPackageJson == null) {
          try {
            final j = jsonDecode(text());
            final n = j['name'] as String?;
            if (n != null && n.isNotEmpty && n != 'myapp' && n != 'app') {
              fromPackageJson = n;
            }
          } catch (_) {}
        }

        // ── Icons: mipmap PNG / WebP ─────────────────────────────────────────
        if (seg.length >= 2) {
          final folder = seg[seg.length - 2].toLowerCase();
          if (_densities.contains(folder)) {
            final raw = entry.content;
            if (raw is List<int> && raw.isNotEmpty) {
              if (flower == 'ic_launcher.png')  mipmapPng[folder]  ??= Uint8List.fromList(raw);
              if (flower == 'ic_launcher.webp') mipmapWebp[folder] ??= Uint8List.fromList(raw);
              // Adaptive foreground (ic_launcher_foreground.*) as extra fallback
              if ((flower == 'ic_launcher_foreground.png' ||
                   flower == 'ic_launcher_foreground.webp') &&
                  adaptiveFgIcon == null) {
                adaptiveFgIcon = Uint8List.fromList(raw);
              }
            }
          }
        }

        // ── Icons: drawable folder ───────────────────────────────────────────
        if (lower.contains('drawable') || lower.contains('mipmap')) {
          if (flower.endsWith('.png') || flower.endsWith('.webp')) {
            final raw = entry.content;
            if (raw is List<int> && raw.isNotEmpty) {
              final base = flower.replaceAll(RegExp(r'\.(png|webp)$'), '');
              drawables[base] ??= Uint8List.fromList(raw);
            }
          }
        }

        // ── Icons: Expo / RN assets ──────────────────────────────────────────
        if (expoIcon == null) {
          if (lower.endsWith('assets/images/icon.png') ||
              lower.endsWith('assets/icon.png')        ||
              lower.endsWith('assets/images/icon.webp') ||
              lower.endsWith('assets/icon.webp')) {
            final raw = entry.content;
            if (raw is List<int> && raw.isNotEmpty) {
              expoIcon = Uint8List.fromList(raw);
            }
          }
        }
      }

      // ── Resolve best package name ─────────────────────────────────────────
      // Build slugs for last-resort sources
      final pubspecSlug = fromPubspec != null
          ? fromPubspec!.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '')
          : null;
      final pubspecPkg = (pubspecSlug != null && pubspecSlug.isNotEmpty)
          ? 'com.app.$pubspecSlug'
          : null;

      final npmSlug = fromPackageJson != null
          ? fromPackageJson!.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '')
          : null;
      final npmPkg = (npmSlug != null && npmSlug.isNotEmpty)
          ? 'com.app.$npmSlug'
          : null;

      String? best =
          fromGradleApp     ??
          fromGradleKtsApp  ??
          fromGradleRoot    ??
          fromGradleKtsRoot ??
          fromManifest      ??
          fromAppJson       ??
          fromAppConfig     ??
          fromNamespace     ??
          pubspecPkg        ??
          npmPkg;

      // Absolute last resort — derive from ZIP filename
      if (best == null || best.isEmpty) {
        final base = zipFileName
            .replaceAll(RegExp(r'\.zip$', caseSensitive: false), '')
            .toLowerCase()
            .replaceAll(RegExp(r'[^a-z0-9]'), '');
        best = base.isNotEmpty ? 'com.app.$base' : 'com.app.project';
      }

      // ── Resolve best icon ─────────────────────────────────────────────────
      Uint8List? bestIcon;
      // 1. Mipmap PNG (highest density first)
      for (final d in _densities) {
        if (mipmapPng.containsKey(d)) { bestIcon = mipmapPng[d]; break; }
      }
      // 2. Mipmap WebP
      if (bestIcon == null) {
        for (final d in _densities) {
          if (mipmapWebp.containsKey(d)) { bestIcon = mipmapWebp[d]; break; }
        }
      }
      // 3. Drawable referenced by android:icon in manifest
      if (bestIcon == null && manifestIconRef != null) {
        bestIcon = drawables[manifestIconRef];
      }
      // 4. Adaptive icon foreground
      bestIcon ??= adaptiveFgIcon;
      // 5. Expo / RN asset icon
      bestIcon ??= expoIcon;
      // 6. Any PNG/WebP from drawable* folder (absolute last resort)
      if (bestIcon == null && drawables.isNotEmpty) {
        bestIcon = drawables.values.first;
      }
      // If still null — that's fine, we proceed without an icon

      if (mounted) {
        setState(() {
          _detectedPackageName = best;
          _detectedIcon        = bestIcon;
          _isFlutter           = isFlutter;
        });
      }
    } catch (_) {}
  }

  // ── pick ZIP and upload directly to GitHub Releases via worker token ──────
  Future<void> _pickAndUpload() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
      allowMultiple: false,
    );
    if (result == null || result.files.single.path == null) return;
    if (!mounted) return;

    final file     = File(result.files.single.path!);
    final fileName = result.files.single.name;

    // Scan package name + launcher icon from the ZIP before uploading
    setState(() {
      _detectedIcon        = null;
      _detectedPackageName = null;
      _isFlutter           = false;
      _armorEnabled        = false;
    });
    await _scanZip(file, zipFileName: fileName);

    setState(() {
      _isUploading      = true;
      _uploadProgress   = 0;
      _uploadedFileName = null;
      _uploadedAssetId  = null;
      _workerJobId      = null;
    });

    try {
      // 1. Ask worker for an upload slot (returns upload_url + auth + job_id)
      final slot = await WorkerService.prepareUpload(ext: 'zip');

      // 2. Upload the ZIP directly to GitHub Releases using the worker's token
      final assetId = await WorkerService.uploadAsset(
        uploadUrl: slot.uploadUrl,
        auth:      slot.auth,
        assetName: slot.assetName,
        file:      file,
        onProgress: (p) {
          if (mounted) setState(() => _uploadProgress = p);
        },
      );

      if (!mounted) return;
      setState(() {
        _uploadedAssetId  = assetId;
        _workerJobId      = slot.jobId;
        _uploadedFileName = fileName;
        _isUploading      = false;
        _uploadProgress   = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _isUploading = false; _uploadProgress = null; });
      _showSnack('Upload failed — ${e.toString()}',
          color: AppTheme.error, icon: Icons.error_rounded);
    }
  }

  // ── trigger the workflow build ─────────────────────────────────────────────
  Future<void> _startBuild() async {
    if (_uploadedAssetId == null || _workerJobId == null) return;

    final packageName = _detectedPackageName ?? '';
    if (packageName.isEmpty) {
      _showSnack('Could not detect package name from ZIP. Make sure it contains a valid Android project.',
          color: AppTheme.error, icon: Icons.error_rounded);
      return;
    }

    setState(() => _submitting = true);

    try {
      final appName = _uploadedFileName!
          .replaceAll(RegExp(r'\.zip$', caseSensitive: false), '')
          .replaceAll('_', ' ')
          .replaceAll('-', ' ');

      final before = DateTime.now().toUtc().subtract(const Duration(seconds: 5));

      // 1. Dispatch the workflow via worker
      await WorkerService.dispatchJob(
        jobId:          _workerJobId!,
        assetId:        _uploadedAssetId!,
        appName:        appName,
        packageName:    packageName,
        flutterVersion: '3.29.1',
        buildMode:      _mode,
        protect:        _armorEnabled,
      );

      // 2. Wait for the GitHub run ID to appear
      final runId = await WorkerService.findRun(after: before);

      if (runId == null) {
        _showSnack('Build triggered but run ID not found. Check your workflow repo.',
            color: AppTheme.warning, icon: Icons.warning_rounded);
        if (mounted) Navigator.pop(context);
        return;
      }

      final job = BuildJob(
        id:             DateTime.now().millisecondsSinceEpoch.toString(),
        appName:        appName,
        packageName:    packageName,
        sourceUrl:      '',
        flutterVersion: 'auto-detect',
        buildMode:      _mode,
        runId:          runId,
        status:         'queued',
        sourceAssetId:  _uploadedAssetId,
        workerJobId:    _workerJobId,
        armorEnabled:   _armorEnabled,
        createdAt:      DateTime.now(),
      );

      await StorageHelper.upsertJob(job);

      // Cache the icon in memory so the card + detail screen can show it
      if (_detectedIcon != null) {
        IconCache.set(job.id, _detectedIcon!);
      }

      if (mounted) Navigator.pop(context, job);
    } catch (e) {
      setState(() => _submitting = false);
      _showSnack('Error: $e', color: AppTheme.error, icon: Icons.error_rounded);
    }
  }

  void _showSnack(String msg, {required Color color, IconData icon = Icons.info_rounded}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 16),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.92),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  void _showArmorInfo() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      isScrollControlled: true,
      builder: (_) => const _ArmorInfoSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool ready = _uploadedAssetId != null && !_isUploading;

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('New Build'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppTheme.border),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [

          // ── hint card ────────────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.accent.withOpacity(0.07),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.accent.withOpacity(0.25)),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.auto_awesome_rounded, color: AppTheme.accent, size: 18),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'ZIP your app source code and upload it below. The build engine will auto-detect your app type (Flutter, React Native, or native Android) and compile a signed APK.',
                    style: TextStyle(color: AppTheme.textSec, fontSize: 12, height: 1.6),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),

          // ── upload card ──────────────────────────────────────────────────
          GestureDetector(
            onTap: (_isUploading || _submitting) ? null : _pickAndUpload,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: ready
                    ? AppTheme.success.withOpacity(0.08)
                    : AppTheme.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: ready
                      ? AppTheme.success.withOpacity(0.5)
                      : _isUploading
                          ? AppTheme.accent.withOpacity(0.5)
                          : AppTheme.border,
                  width: 1.5,
                ),
              ),
              child: _isUploading
                  ? _buildUploading()
                  : ready
                      ? _buildDone()
                      : _buildIdle(),
            ),
          ),
          const SizedBox(height: 28),

          // ── App Armor (Flutter only) ──────────────────────────────────────
          if (_isFlutter && ready) ...[
            _ArmorSection(
              enabled:  _armorEnabled,
              onToggle: (v) => setState(() => _armorEnabled = v),
              onInfo:   _showArmorInfo,
            ),
            const SizedBox(height: 28),
          ],

          // ── build mode ───────────────────────────────────────────────────
          const Row(children: [
            Icon(Icons.settings_rounded, color: AppTheme.accent, size: 18),
            SizedBox(width: 8),
            Text('Build Configuration',
                style: TextStyle(color: AppTheme.accent, fontSize: 13,
                    fontWeight: FontWeight.w700, letterSpacing: 0.5)),
          ]),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _mode,
                dropdownColor: AppTheme.card,
                isExpanded: true,
                style: const TextStyle(color: AppTheme.textPrim, fontSize: 14),
                icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppTheme.textSec),
                items: _buildModes.map((v) => DropdownMenuItem(
                  value: v,
                  child: Row(children: [
                    Icon(
                      v == 'release' ? Icons.verified_rounded
                          : v == 'debug' ? Icons.bug_report_rounded
                          : Icons.speed_rounded,
                      color: AppTheme.accent, size: 16,
                    ),
                    const SizedBox(width: 10),
                    Text(v[0].toUpperCase() + v.substring(1)),
                  ]),
                )).toList(),
                onChanged: (_submitting || _isUploading)
                    ? null
                    : (v) => setState(() => _mode = v!),
              ),
            ),
          ),
          const SizedBox(height: 36),

          // ── start build button ───────────────────────────────────────────
          SizedBox(
            height: 56,
            child: ElevatedButton(
              onPressed: (ready && !_submitting) ? _startBuild : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accent,
                disabledBackgroundColor: AppTheme.border,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _submitting
                  ? const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)),
                        SizedBox(width: 12),
                        Text('Starting… please wait',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          ready ? Icons.rocket_launch_rounded : Icons.upload_file_rounded,
                          size: 22, color: Colors.white,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          ready ? 'Start Build' : 'Upload a ZIP to continue',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildIdle() => const Row(
    children: [
      SizedBox(width: 56, height: 56,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Color(0x1A00b4d8),
            borderRadius: BorderRadius.all(Radius.circular(14)),
          ),
          child: Icon(Icons.upload_file_rounded, color: AppTheme.accent, size: 28),
        ),
      ),
      SizedBox(width: 16),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Upload ZIP file', style: TextStyle(color: AppTheme.textPrim,
              fontWeight: FontWeight.w700, fontSize: 15)),
          SizedBox(height: 4),
          Text('Tap to pick your app source code ZIP',
              style: TextStyle(color: AppTheme.textSec, fontSize: 12)),
        ]),
      ),
      Icon(Icons.chevron_right_rounded, color: AppTheme.textSec, size: 22),
    ],
  );

  Widget _buildUploading() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(children: [
        const SizedBox(width: 18, height: 18,
            child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.accent)),
        const SizedBox(width: 12),
        const Text('Uploading…', style: TextStyle(color: AppTheme.textPrim,
            fontWeight: FontWeight.w600, fontSize: 14)),
        const Spacer(),
        if (_uploadProgress != null)
          Text('${(_uploadProgress! * 100).toStringAsFixed(0)}%',
              style: const TextStyle(color: AppTheme.accent, fontSize: 14, fontWeight: FontWeight.w700)),
      ]),
      const SizedBox(height: 12),
      ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: LinearProgressIndicator(
          value: _uploadProgress,
          backgroundColor: AppTheme.border,
          color: AppTheme.accent,
          minHeight: 6,
        ),
      ),
    ],
  );

  Widget _buildDone() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              color: AppTheme.success.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            clipBehavior: Clip.antiAlias,
            child: _detectedIcon != null
                ? Image.memory(_detectedIcon!, fit: BoxFit.cover)
                : const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Ready to build!', style: TextStyle(color: AppTheme.success,
                  fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 4),
              Text(_uploadedFileName!, style: const TextStyle(color: AppTheme.textSec, fontSize: 12),
                  overflow: TextOverflow.ellipsis),
            ]),
          ),
          TextButton(
            onPressed: _submitting ? null : _pickAndUpload,
            child: const Text('Change', style: TextStyle(color: AppTheme.accent, fontSize: 12)),
          ),
        ],
      ),
      if (_detectedPackageName != null) ...[
        const SizedBox(height: 12),
        Row(
          children: [
            const Icon(Icons.fingerprint_rounded, color: AppTheme.accent, size: 14),
            const SizedBox(width: 6),
            const Text('Package: ', style: TextStyle(color: AppTheme.textSec, fontSize: 12)),
            Expanded(
              child: Text(
                _detectedPackageName!,
                style: const TextStyle(color: AppTheme.accent, fontSize: 12,
                    fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ] else ...[
        const SizedBox(height: 12),
        const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: AppTheme.warning, size: 14),
            SizedBox(width: 6),
            Expanded(
              child: Text(
                'Package name not found — ensure build.gradle / build.gradle.kts, AndroidManifest.xml, or app.json is inside the ZIP.',
                style: TextStyle(color: AppTheme.warning, fontSize: 11),
              ),
            ),
          ],
        ),
      ],
    ],
  );
}

// ─── App Armor section card ───────────────────────────────────────────────────

class _ArmorSection extends StatelessWidget {
  final bool enabled;
  final ValueChanged<bool> onToggle;
  final VoidCallback onInfo;
  const _ArmorSection({required this.enabled, required this.onToggle, required this.onInfo});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Icon(Icons.shield_rounded,
              color: enabled ? AppTheme.gold : AppTheme.accent, size: 18),
          const SizedBox(width: 8),
          Text('App Armor',
              style: TextStyle(
                color: enabled ? AppTheme.gold : AppTheme.accent,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              )),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: AppTheme.accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.accent.withOpacity(0.3)),
            ),
            child: const Text('Flutter',
                style: TextStyle(color: AppTheme.accent, fontSize: 10,
                    fontWeight: FontWeight.w700)),
          ),
        ]),
        const SizedBox(height: 12),
        AnimatedContainer(
          duration: const Duration(milliseconds: 280),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: enabled ? AppTheme.gold.withOpacity(0.06) : AppTheme.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: enabled ? AppTheme.gold.withOpacity(0.55) : AppTheme.border,
              width: enabled ? 1.5 : 1,
            ),
            boxShadow: enabled
                ? [BoxShadow(color: AppTheme.gold.withOpacity(0.14), blurRadius: 14)]
                : null,
          ),
          child: Row(children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 280),
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: (enabled ? AppTheme.gold : AppTheme.textSec).withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                enabled ? Icons.shield_rounded : Icons.shield_outlined,
                color: enabled ? AppTheme.gold : AppTheme.textSec,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  enabled ? '7-Layer Protection ON' : 'Protection Disabled',
                  style: TextStyle(
                    color: enabled ? AppTheme.gold : AppTheme.textPrim,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  enabled
                      ? 'Obfuscation · Anti-hook · Emulator block'
                      : 'Enable advanced reverse-engineering protection',
                  style: const TextStyle(color: AppTheme.textSec, fontSize: 11),
                ),
              ]),
            ),
            GestureDetector(
              onTap: onInfo,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: AppTheme.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.help_outline_rounded,
                    color: AppTheme.accent, size: 16),
              ),
            ),
            const SizedBox(width: 4),
            Switch.adaptive(
              value: enabled,
              onChanged: onToggle,
              activeColor: AppTheme.gold,
              activeTrackColor: AppTheme.gold.withOpacity(0.3),
            ),
          ]),
        ),
      ],
    );
  }
}

// ─── Armor info bottom sheet ──────────────────────────────────────────────────

class _ArmorInfoSheet extends StatelessWidget {
  const _ArmorInfoSheet();

  static const _layers = [
    (
      icon: Icons.code_rounded,
      color: Color(0xFF00b4d8),
      title: 'Dart Obfuscation',
      desc: 'Scrambles every Dart class, method and variable name in the compiled snapshot — reversing tools like blutter read garbage identifiers.',
    ),
    (
      icon: Icons.layers_clear_rounded,
      color: Color(0xFF00b4d8),
      title: 'Debug Symbol Strip',
      desc: 'Removes all debug info and symbol tables from the APK so stack traces and crash reports reveal nothing useful to an attacker.',
    ),
    (
      icon: Icons.memory_rounded,
      color: Color(0xFFf59e0b),
      title: 'Snapshot Hash Wipe',
      desc: 'Binary-patches libapp.so to erase the Dart VM snapshot hash. blutter and reFlutter require this hash to locate and parse your Dart code.',
    ),
    (
      icon: Icons.grass_rounded,
      color: Color(0xFFef4444),
      title: 'Root Detection',
      desc: 'Checks for su, Magisk, KernelSU and SuperSU at startup. Kills the process instantly if any root indicator is found on the device.',
    ),
    (
      icon: Icons.bug_report_rounded,
      color: Color(0xFFef4444),
      title: 'Anti-Debug',
      desc: 'Detects attached debuggers via JDWP and the ro.debuggable system property. Terminates the process the moment a debugger connects.',
    ),
    (
      icon: Icons.link_off_rounded,
      color: Color(0xFFef4444),
      title: 'Anti-Hooking',
      desc: 'Scans /proc/self/maps for Frida, Xposed, LSPosed and Substrate signatures at runtime. Process is killed on the first match.',
    ),
    (
      icon: Icons.phone_android_rounded,
      color: Color(0xFFef4444),
      title: 'Emulator Detection',
      desc: 'Identifies BlueStacks, Genymotion, AVD and any VM via build props and hardware fingerprints. Aborts immediately on detection.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.78,
      minChildSize: 0.5,
      maxChildSize: 0.93,
      builder: (_, ctrl) => Column(children: [
        Container(
          margin: const EdgeInsets.only(top: 12, bottom: 4),
          width: 40, height: 4,
          decoration: BoxDecoration(
            color: AppTheme.border, borderRadius: BorderRadius.circular(2)),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
          child: Row(children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: AppTheme.gold.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.shield_rounded, color: AppTheme.gold, size: 24),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('App Armor',
                  style: TextStyle(color: AppTheme.textPrim, fontSize: 17,
                      fontWeight: FontWeight.w800)),
              const Text('7 independent protection layers',
                  style: TextStyle(color: AppTheme.textSec, fontSize: 12)),
            ]),
          ]),
        ),
        Container(height: 1, color: AppTheme.border),
        Expanded(
          child: ListView.separated(
            controller: ctrl,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            itemCount: _layers.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final l = _layers[i];
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(
                    width: 22, height: 22,
                    decoration: BoxDecoration(
                      color: l.color.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Center(
                      child: Text('${i + 1}',
                          style: TextStyle(color: l.color, fontSize: 11,
                              fontWeight: FontWeight.w800)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Icon(l.icon, color: l.color, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(l.title,
                          style: TextStyle(color: l.color, fontSize: 13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text(l.desc,
                          style: const TextStyle(color: AppTheme.textSec,
                              fontSize: 11, height: 1.5)),
                    ]),
                  ),
                ]),
              );
            },
          ),
        ),
        Container(
          margin: const EdgeInsets.fromLTRB(16, 4, 16, 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppTheme.gold.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.gold.withOpacity(0.25)),
          ),
          child: const Row(children: [
            Icon(Icons.info_outline_rounded, color: AppTheme.gold, size: 15),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                'Layers 4–7 are injected as a native Android provider that runs before any app code. Default is OFF.',
                style: TextStyle(color: AppTheme.textSec, fontSize: 11, height: 1.5),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}
