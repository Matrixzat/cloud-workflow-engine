import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_file/open_file.dart';
import '../models/build_job.dart';
import '../services/worker_service.dart';
import '../theme/app_theme.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/icon_cache.dart';
import 'package:timeago/timeago.dart' as timeago;

class BuildDetailScreen extends StatefulWidget {
  final BuildJob job;
  const BuildDetailScreen({super.key, required this.job});

  @override
  State<BuildDetailScreen> createState() => _BuildDetailScreenState();
}

class _BuildDetailScreenState extends State<BuildDetailScreen> {
  late BuildJob _job;
  Timer?  _pollTimer;
  Timer?  _elapsedTimer;
  int     _elapsedSeconds  = 0;
  bool    _downloading     = false;
  double  _dlProgress      = 0;
  String? _apkPath;
  bool    _autoDownloaded  = false;
  bool    _cancelling      = false;

  // ── Live step state (from /job-live) ─────────────────────────────────────
  List<Map<String, dynamic>> _steps        = [];
  String?                    _currentStep;
  int                        _completedCount = 0;
  int                        _totalSteps     = 0;

  // ── Post-completion log ───────────────────────────────────────────────────
  String?          _buildLog;
  bool             _logLoaded = false;
  final ScrollController _logScroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _job = widget.job;
    _apkPath        = _job.apkPath;
    _autoDownloaded = _job.apkPath != null;
    _elapsedSeconds = DateTime.now().difference(_job.createdAt).inSeconds.clamp(0, 99999);
    _poll();
    if (_job.isRunning) {
      _pollTimer   = Timer.periodic(const Duration(seconds: 10), (_) => _poll());
      _elapsedTimer = Timer.periodic(const Duration(seconds: 1),  (_) {
        if (mounted && _job.isRunning) setState(() => _elapsedSeconds++);
      });
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _elapsedTimer?.cancel();
    _logScroll.dispose();
    super.dispose();
  }

  String get _elapsedLabel {
    final m = _elapsedSeconds ~/ 60;
    final s = _elapsedSeconds % 60;
    if (m == 0) return '${s}s';
    return '${m}m ${s.toString().padLeft(2, '0')}s';
  }

  Future<void> _poll() async {
    try {
      final run = await WorkerService.getStatus(_job.runId);
      if (run == null) return;

      _job.status     = run['status']     as String? ?? _job.status;
      _job.conclusion = run['conclusion'] as String?;
      _job.updatedAt  = DateTime.now();

      if (!_job.isRunning) {
        _pollTimer?.cancel();
        _elapsedTimer?.cancel();
        if (!_logLoaded) _fetchLog();
      }
      await StorageHelper.upsertJob(_job);

      // Fetch live step info from the worker
      final liveData = await WorkerService.getJobLive(_job.runId);
      if (liveData != null) {
        final steps = (liveData['steps'] as List?)
            ?.map((e) => Map<String, dynamic>.from(e as Map))
            .toList() ?? [];
        if (mounted) setState(() {
          _steps          = steps;
          _currentStep    = liveData['current_step']   as String?;
          _completedCount = (liveData['completed_count'] as num?)?.toInt() ?? 0;
          _totalSteps     = (liveData['total_steps']     as num?)?.toInt() ?? 0;
        });
      }

      if (mounted) setState(() {});

      if (_job.isSuccess && !_autoDownloaded && !_downloading && _job.workerJobId != null) {
        _autoDownloaded = true;
        await _download();
      }
    } catch (_) {}
  }

  Future<void> _cancelBuild() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0d1b2e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Cancel Build?',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        content: Text(
          'Are you sure you want to cancel the build for "${_job.appName}"? This cannot be undone.',
          style: const TextStyle(color: Color(0xFF8899aa), fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Keep Building', style: TextStyle(color: Color(0xFF00b4d8))),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Cancel Build'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _cancelling = true);
    try {
      await WorkerService.cancelRun(_job.runId);

      // Delete the source asset — no matter what stage the workflow was at
      final assetId = _job.sourceAssetId;
      if (assetId != null) {
        try { await WorkerService.deleteAsset(assetId); } catch (_) {}
      }

      _showSnack('Build cancelled', color: AppTheme.warning, icon: Icons.cancel_rounded);
      await Future.delayed(const Duration(seconds: 3));
      await _poll();
    } catch (e) {
      _showSnack('Cancel failed: $e', color: AppTheme.error, icon: Icons.error_rounded);
    } finally {
      if (mounted) setState(() => _cancelling = false);
    }
  }


  // ── Download ZIP artifact via Cloudflare Worker ───────────────────────────
  Future<void> _download() async {
    if (_job.workerJobId == null) return;

    final hasPermission = await PermissionHelper.ensureStorage(
      context,
      accent: AppTheme.accent,
    );
    if (!hasPermission) {
      _showSnack(
        'Storage permission is required to save the APK.',
        color: AppTheme.warning,
        icon: Icons.lock_rounded,
      );
      return;
    }

    setState(() { _downloading = true; _dlProgress = 0; });

    try {
      final root = await StorageHelper.getRootDir();
      final destPath = '$root/Cloud_Build_Engine';
      await StorageHelper.ensureOutputDir(destPath);

      final safeName = _job.appName
          .replaceAll(RegExp(r'[^a-zA-Z0-9_\-]'), '_')
          .replaceAll(RegExp(r'_+'), '_');
      final zipPath = '$destPath/${safeName}_${_job.runId}.zip';

      await WorkerService.downloadArtifact(
        runId:    _job.runId,
        jobId:    _job.workerJobId!,
        destPath: zipPath,
        onProgress: (rcv, total) {
          if (total > 0 && mounted) setState(() => _dlProgress = rcv / total);
        },
      );

      _job.apkPath = zipPath;
      await StorageHelper.upsertJob(_job);

      // Delete source asset — fire and forget
      final assetId = _job.sourceAssetId;
      if (assetId != null) {
        unawaited(() async {
          try { await WorkerService.deleteAsset(assetId); } catch (_) {}
        }());
      }

      setState(() {
        _downloading = false;
        _dlProgress  = 0;
        _apkPath     = zipPath;
      });

      if (mounted) _showSuccessDialog(zipPath);
    } catch (e) {
      setState(() { _downloading = false; _dlProgress = 0; });
      _showSnack('Download failed: $e', color: AppTheme.error, icon: Icons.error_rounded);
    }
  }

  // ── Fetch post-build log (error logs on failure; step summary on success) ──
  Future<void> _fetchLog() async {
    _logLoaded = true;
    try {
      if (_job.isSuccess) {
        // Build a step summary from the already-fetched steps
        if (_steps.isNotEmpty) {
          final buf = StringBuffer();
          buf.writeln('Build completed successfully\n');
          for (final s in _steps) {
            final name       = s['name']       as String? ?? '';
            final status     = s['status']     as String? ?? '';
            final conclusion = s['conclusion'] as String?;
            final icon = conclusion == 'success' ? '✓'
                       : conclusion == 'failure' ? '✗'
                       : conclusion == 'skipped' ? '–'
                       : status == 'in_progress' ? '⋯'
                       : '○';
            final label = conclusion != null ? '$icon  $name ($conclusion)' : '$icon  $name';
            buf.writeln(label);
          }
          if (mounted) setState(() => _buildLog = buf.toString().trimRight());
        }
      } else {
        // Failure: fetch error logs from the worker
        final log = await WorkerService.getJobError(_job.runId);
        if (log != null && log.isNotEmpty && mounted) {
          setState(() => _buildLog = log);
        }
      }
    } catch (_) {}
  }

  // ── Success dialog ────────────────────────────────────────────────────────
  void _showSuccessDialog(String zipPath) {
    final zipFile = File(zipPath);
    final sizeMb  = zipFile.existsSync()
        ? (zipFile.lengthSync() / 1024 / 1024).toStringAsFixed(1)
        : '?';
    final fileName = zipPath.split('/').last;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF0d1b2e),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppTheme.success.withOpacity(0.4), width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Success icon
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  color: AppTheme.success.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: AppTheme.success.withOpacity(0.4), width: 2),
                ),
                child: const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 40),
              ),
              const SizedBox(height: 16),
              const Text('Build Complete!',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(_job.appName,
                style: const TextStyle(color: AppTheme.accent, fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),

              // File info
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: AppTheme.bg,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Row(children: [
                  const Icon(Icons.folder_zip_rounded, color: AppTheme.accent, size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(fileName,
                        style: const TextStyle(color: AppTheme.textPrim, fontSize: 12, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),
                      Text('$sizeMb MB  •  /Cloud_Build_Engine/',
                        style: const TextStyle(color: AppTheme.textSec, fontSize: 11)),
                    ]),
                  ),
                ]),
              ),
              const SizedBox(height: 8),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  'Open with your file manager, extract the ZIP and install the APK inside.',
                  style: TextStyle(color: AppTheme.textSec, fontSize: 11, height: 1.5),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),

              // Open in file manager
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    OpenFile.open(zipPath);
                  },
                  icon: const Icon(Icons.folder_open_rounded, size: 20),
                  label: const Text('Open in File Manager',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.success,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 10),

              SizedBox(
                width: double.infinity,
                height: 42,
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.textSec,
                    side: BorderSide(color: AppTheme.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Close', style: TextStyle(fontSize: 14)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnack(String msg, {required Color color, required IconData icon}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 12))),
      ]),
      backgroundColor: color.withOpacity(0.92),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 4),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Text(_job.appName),
        actions: [
          if (_job.isRunning)
            _cancelling
                ? const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 14),
                    child: SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.red)))
                : IconButton(
                    icon: const Icon(Icons.cancel_outlined, color: Colors.red),
                    tooltip: 'Cancel Build',
                    onPressed: _cancelBuild,
                  ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _poll,
            tooltip: 'Refresh',
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppTheme.border),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ── Success banner — always visible at top when done ───────────────
          if (_job.isSuccess) ...[
            _buildSuccessBanner(),
            const SizedBox(height: 16),
          ],
          _buildStatusCard(),
          const SizedBox(height: 16),
          _buildInfoCard(),
          const SizedBox(height: 16),
          if (_steps.isNotEmpty) ...[
            _buildStepsCard(),
            const SizedBox(height: 16),
          ],
          if (_buildLog != null) ...[
            _buildLogCard(),
            const SizedBox(height: 16),
          ],
          _buildActionsCard(),
        ],
      ),
    );
  }

  Widget _buildJobIcon({required Color color, required IconData fallbackIcon}) {
    final iconBytes = IconCache.get(_job.id);
    if (iconBytes != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Image.memory(iconBytes, width: 52, height: 52, fit: BoxFit.cover),
      );
    }
    return Container(
      width: 52, height: 52,
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(fallbackIcon, color: color, size: 28),
    );
  }

  Widget _buildStatusCard() {
    Color color;
    IconData icon;
    if (_job.isRunning)      { color = AppTheme.running; icon = Icons.autorenew_rounded; }
    else if (_job.isSuccess) { color = AppTheme.success;  icon = Icons.check_circle_rounded; }
    else                     { color = AppTheme.error;    icon = Icons.error_rounded; }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(children: [
        _buildJobIcon(color: color, fallbackIcon: icon),
        const SizedBox(width: 16),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_job.statusLabel,
              style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            // Live elapsed timer while building
            if (_job.isRunning)
              Text('Building for $_elapsedLabel',
                style: const TextStyle(color: AppTheme.textSec, fontSize: 12))
            else if (_job.updatedAt != null)
              Text('Completed ${timeago.format(_job.updatedAt!)}',
                style: const TextStyle(color: AppTheme.textSec, fontSize: 12)),
            Text('Run #${_job.runId}',
              style: const TextStyle(color: AppTheme.textSec, fontSize: 12)),
          ]),
        ),
        if (_job.isRunning)
          SizedBox(width: 24, height: 24,
            child: CircularProgressIndicator(strokeWidth: 2.5, color: color)),
      ]),
    );
  }

  Widget _buildInfoCard() {
    final modeLabel = _job.buildMode.isEmpty
        ? 'Release'
        : '${_job.buildMode[0].toUpperCase()}${_job.buildMode.substring(1)}';

    return _Card(title: 'Build Info', children: [
      _InfoRow(label: 'App Name', value: _job.appName),
      _InfoRow(label: 'Mode',     value: modeLabel),
      _InfoRow(label: 'Started',  value: timeago.format(_job.createdAt)),
      _InfoRow(label: 'Run #',    value: '${_job.runId}', copyable: true, copyValue: '${_job.runId}'),
    ]);
  }

  // ── Step duration helper ──────────────────────────────────────────────────

  String _stepDuration(Map<String, dynamic> step) {
    final startedAt   = step['started_at']   as String?;
    final completedAt = step['completed_at'] as String?;
    if (startedAt == null || completedAt == null) return '';
    try {
      final s = DateTime.parse(startedAt);
      final e = DateTime.parse(completedAt);
      final d = e.difference(s).inSeconds;
      if (d <= 0) return '';
      return d < 60 ? '${d}s' : '${(d / 60).floor()}m ${d % 60}s';
    } catch (_) { return ''; }
  }

  Widget _buildStepsCard() {
    final done = _steps.where((s) => s['status'] == 'completed').length;
    final total = _steps.length;
    final pct   = total > 0 ? done / total : 0.0;

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(children: [
              const Icon(Icons.format_list_bulleted_rounded, color: AppTheme.accent, size: 16),
              const SizedBox(width: 8),
              const Text('Build Steps',
                style: TextStyle(color: AppTheme.accent, fontSize: 13,
                    fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              const Spacer(),
              Text('$done / $total',
                style: const TextStyle(color: AppTheme.textSec, fontSize: 11)),
            ]),
          ),
          if (_job.isRunning && total > 0) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: pct,
                  backgroundColor: AppTheme.border,
                  color: AppTheme.accent,
                  minHeight: 3,
                ),
              ),
            ),
          ],
          const Divider(height: 1, color: AppTheme.border),
          ..._steps.map((step) => _buildStepRow(step)),
        ],
      ),
    );
  }

  Widget _buildStepRow(Map<String, dynamic> step) {
    final name        = step['name']       as String? ?? '';
    final status      = step['status']     as String? ?? 'queued';
    final conclusion  = step['conclusion'] as String?;
    final duration    = _stepDuration(step);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 9, 16, 9),
      child: Row(children: [
        _StepIcon(status: status, conclusion: conclusion, size: 14),
        const SizedBox(width: 10),
        Expanded(
          child: Text(name,
            style: TextStyle(
              color: status == 'in_progress' ? AppTheme.accent
                  : conclusion == 'skipped' ? const Color(0xFF3a5070)
                  : AppTheme.textSec,
              fontSize: 12,
              fontWeight: status == 'in_progress' ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ),
        if (duration.isNotEmpty)
          Text(duration, style: const TextStyle(color: AppTheme.textSec, fontSize: 10)),
        if (status == 'in_progress')
          const Padding(
            padding: EdgeInsets.only(left: 6),
            child: SizedBox(width: 10, height: 10,
              child: CircularProgressIndicator(strokeWidth: 1.5, color: AppTheme.accent)),
          ),
      ]),
    );
  }

  Widget _buildDownloadCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.success.withOpacity(0.30)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.android_rounded, color: AppTheme.success, size: 20),
          const SizedBox(width: 8),
          const Text('APK Output',
            style: TextStyle(color: AppTheme.success, fontWeight: FontWeight.w700, fontSize: 15)),
        ]),
        const SizedBox(height: 12),
        if (_job.artifactName != null)
          Text(_job.artifactName!, style: const TextStyle(color: AppTheme.textSec, fontSize: 12)),
        const SizedBox(height: 14),

        if (_downloading) ...[
          Row(children: [
            const Icon(Icons.download_rounded, color: AppTheme.accent, size: 16),
            const SizedBox(width: 6),
            Text('Downloading… ${(_dlProgress * 100).toStringAsFixed(0)}%',
              style: const TextStyle(color: AppTheme.textSec, fontSize: 12)),
          ]),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _dlProgress > 0 ? _dlProgress : null,
              backgroundColor: AppTheme.border,
              color: AppTheme.accent,
              minHeight: 6,
            ),
          ),
        ] else if (_apkPath != null) ...[
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => OpenFile.open(_apkPath!),
              icon: const Icon(Icons.folder_open_rounded, size: 18),
              label: const Text('Open in File Manager'),
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.success),
            ),
          ),
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 14),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                'Saved to: ${_apkPath!.substring(0, _apkPath!.lastIndexOf('/'))}',
                style: const TextStyle(color: AppTheme.textSec, fontSize: 11),
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
          ]),
        ] else ...[
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _download,
              icon: const Icon(Icons.download_rounded, size: 18),
              label: const Text('Download APK Package'),
            ),
          ),
        ],
      ]),
    );
  }

  Widget _buildActionsCard() {
    return _Card(title: 'Actions', children: [
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.delete_outline_rounded, color: AppTheme.error, size: 22),
        title: const Text('Delete Build Record', style: TextStyle(color: AppTheme.error, fontSize: 14)),
        onTap: () async {
          await StorageHelper.deleteJob(_job.id);
          if (mounted) Navigator.pop(context);
        },
      ),
    ]);
  }

  // ── Post-build log card ───────────────────────────────────────────────────
  Widget _buildLogCard() {
    final isFail    = !_job.isSuccess;
    final cardColor = isFail ? AppTheme.error : AppTheme.success;
    final title     = isFail ? 'Error Logs' : 'Build Summary';
    final icon      = isFail ? Icons.error_outline_rounded : Icons.checklist_rounded;

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF020912),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardColor.withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──────────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
            child: Row(children: [
              Icon(icon, color: cardColor, size: 14),
              const SizedBox(width: 8),
              Expanded(
                child: Text(title,
                  style: TextStyle(color: cardColor, fontSize: 12,
                      fontWeight: FontWeight.w700, letterSpacing: 0.3)),
              ),
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: _buildLog ?? ''));
                  _showSnack('Copied to clipboard',
                      color: AppTheme.success, icon: Icons.copy_rounded);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: cardColor.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: cardColor.withOpacity(0.30)),
                  ),
                  child: Row(children: [
                    Icon(Icons.copy_rounded, color: cardColor, size: 12),
                    const SizedBox(width: 4),
                    Text('Copy', style: TextStyle(color: cardColor,
                        fontSize: 11, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
            ]),
          ),

          const Divider(height: 1, color: Color(0xFF1e3050)),

          // ── Log body ─────────────────────────────────────────────────────
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 280),
            child: Scrollbar(
              controller: _logScroll,
              thumbVisibility: true,
              child: SingleChildScrollView(
                controller: _logScroll,
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                child: SelectableText(
                  _buildLog ?? '',
                  style: const TextStyle(
                    color: Color(0xFFc8d8e8),
                    fontSize: 11,
                    fontFamily: 'monospace',
                    height: 1.6,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Success banner ────────────────────────────────────────────────────────

  Widget _buildSuccessBanner() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.success.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.success.withOpacity(0.45), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: AppTheme.success.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Build Complete!',
                  style: TextStyle(color: AppTheme.success, fontSize: 17,
                      fontWeight: FontWeight.w800)),
                Text(_job.appName,
                  style: const TextStyle(color: AppTheme.textSec, fontSize: 12),
                  overflow: TextOverflow.ellipsis),
              ]),
            ),
          ]),

          const SizedBox(height: 16),
          const Divider(height: 1, color: Color(0xFF1e3a2a)),
          const SizedBox(height: 14),

          if (_downloading) ...[
            Row(children: [
              const Icon(Icons.download_rounded, color: AppTheme.accent, size: 16),
              const SizedBox(width: 8),
              Text('Downloading…  ${(_dlProgress * 100).toStringAsFixed(0)}%',
                style: const TextStyle(color: AppTheme.textSec, fontSize: 13)),
            ]),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: _dlProgress > 0 ? _dlProgress : null,
                backgroundColor: AppTheme.border,
                color: AppTheme.success,
                minHeight: 6,
              ),
            ),
          ] else if (_apkPath != null) ...[
            SizedBox(
              width: double.infinity,
              height: 46,
              child: ElevatedButton.icon(
                onPressed: () => OpenFile.open(_apkPath!),
                icon: const Icon(Icons.folder_open_rounded, size: 20),
                label: const Text('Open APK in File Manager',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.success,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.check_circle_outline_rounded, color: AppTheme.success, size: 13),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Saved to: ${_apkPath!.substring(0, _apkPath!.lastIndexOf('/'))}',
                  style: const TextStyle(color: AppTheme.textSec, fontSize: 11),
                  overflow: TextOverflow.ellipsis),
              ),
            ]),
          ] else ...[
            SizedBox(
              width: double.infinity,
              height: 46,
              child: ElevatedButton.icon(
                onPressed: _download,
                icon: const Icon(Icons.download_rounded, size: 20),
                label: const Text('Download APK Package',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.success,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 6),
            const Center(
              child: Text(
                'APK will be saved to /Cloud_Build_Engine/ on your device',
                style: TextStyle(color: AppTheme.textSec, fontSize: 11),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ── Reusable widgets ──────────────────────────────────────────────────────────

class _StepIcon extends StatelessWidget {
  final String  status;
  final String? conclusion;
  final double  size;
  const _StepIcon({required this.status, required this.conclusion, required this.size});

  @override
  Widget build(BuildContext context) {
    if (status == 'in_progress') {
      return SizedBox(width: size, height: size,
        child: const CircularProgressIndicator(strokeWidth: 2, color: AppTheme.accent));
    }
    if (status == 'queued' || status == 'waiting') {
      return Icon(Icons.radio_button_unchecked_rounded, color: AppTheme.textSec, size: size);
    }
    if (status == 'completed') {
      switch (conclusion) {
        case 'success':   return Icon(Icons.check_circle_rounded,         color: AppTheme.success, size: size);
        case 'failure':   return Icon(Icons.cancel_rounded,               color: AppTheme.error,   size: size);
        case 'skipped':   return Icon(Icons.remove_circle_outline_rounded, color: AppTheme.textSec, size: size);
        case 'cancelled': return Icon(Icons.do_not_disturb_rounded,        color: AppTheme.textSec, size: size);
        default:          return Icon(Icons.help_outline_rounded,          color: AppTheme.textSec, size: size);
      }
    }
    return Icon(Icons.circle_outlined, color: AppTheme.textSec, size: size);
  }
}

class _Card extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _Card({required this.title, required this.children});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: AppTheme.card,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppTheme.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
          child: Text(title,
            style: const TextStyle(color: AppTheme.accent, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
        ),
        const Divider(height: 1, color: AppTheme.border),
        Padding(padding: const EdgeInsets.all(12), child: Column(children: children)),
      ],
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String  label;
  final String  value;
  final bool    copyable;
  final String? copyValue;
  const _InfoRow({required this.label, required this.value, this.copyable = false, this.copyValue});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      SizedBox(width: 72,
        child: Text(label, style: const TextStyle(color: AppTheme.textSec, fontSize: 12))),
      Expanded(
        child: Text(value,
          style: const TextStyle(color: AppTheme.textPrim, fontSize: 12, fontWeight: FontWeight.w500),
          overflow: TextOverflow.ellipsis,
          maxLines: 2),
      ),
      if (copyable)
        GestureDetector(
          onTap: () => Clipboard.setData(ClipboardData(text: copyValue ?? value)),
          child: const Padding(
            padding: EdgeInsets.only(left: 8),
            child: Icon(Icons.copy_rounded, color: AppTheme.textSec, size: 14)),
        ),
    ]),
  );
}



