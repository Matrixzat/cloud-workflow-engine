.class public Lcom/ultra/dex2cvmp/ProxyApplication;
.super Landroid/app/Application;
.source "ProxyApplication.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 18
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method

.method private realApplication()Landroid/app/Application;
    .registers 16

    .line 40
    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "android.app.ActivityThread"

    const/4 v3, 0x0

    const-string v4, "currentActivityThread"

    invoke-static {v2, v3, v4, v1, v3}, Lcom/ultra/dex2cvmp/utils/Reflect;->invokeMethod(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;[Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    .line 41
    .local v1, "currentActivityThread":Ljava/lang/Object;
    const-string v4, "mBoundApplication"

    invoke-static {v2, v1, v4}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    .line 44
    .local v4, "mBoundApplication":Ljava/lang/Object;
    const-string v5, "info"

    const-string v6, "android.app.ActivityThread$AppBindData"

    invoke-static {v6, v4, v5}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    .line 48
    .local v5, "loadedApkInfo":Ljava/lang/Object;
    const-string v7, "mApplication"

    const-string v8, "android.app.LoadedApk"

    invoke-static {v8, v5, v7, v3}, Lcom/ultra/dex2cvmp/utils/Reflect;->setFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Z

    .line 49
    const-string v7, "mInitialApplication"

    invoke-static {v2, v1, v7}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    .line 53
    .local v9, "oldApplication":Ljava/lang/Object;
    nop

    .line 54
    const-string v10, "mAllApplications"

    invoke-static {v2, v1, v10}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/ArrayList;

    .line 56
    .local v10, "mAllApplications":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Landroid/app/Application;>;"
    if-eqz v10, :cond_35

    .line 57
    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 60
    :cond_35
    nop

    .line 61
    const-string v11, "mApplicationInfo"

    invoke-static {v8, v5, v11}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/content/pm/ApplicationInfo;

    .line 63
    .local v11, "loadedApk":Landroid/content/pm/ApplicationInfo;
    nop

    .line 64
    const-string v12, "appInfo"

    invoke-static {v6, v4, v12}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/pm/ApplicationInfo;

    .line 67
    .local v6, "appBindData":Landroid/content/pm/ApplicationInfo;
    if-eqz v11, :cond_4d

    .line 68
    sget-object v12, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    iput-object v12, v11, Landroid/content/pm/ApplicationInfo;->className:Ljava/lang/String;

    .line 70
    :cond_4d
    if-eqz v6, :cond_53

    .line 71
    sget-object v12, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    iput-object v12, v6, Landroid/content/pm/ApplicationInfo;->className:Ljava/lang/String;

    .line 74
    :cond_53
    nop

    .line 76
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v12

    const/4 v13, 0x2

    new-array v14, v13, [Ljava/lang/Object;

    aput-object v12, v14, v0

    const/4 v12, 0x1

    aput-object v3, v14, v12

    new-array v3, v13, [Ljava/lang/Class;

    sget-object v13, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v13, v3, v0

    const-class v0, Landroid/app/Instrumentation;

    aput-object v0, v3, v12

    .line 74
    const-string v0, "makeApplication"

    invoke-static {v8, v5, v0, v14, v3}, Lcom/ultra/dex2cvmp/utils/Reflect;->invokeMethod(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;[Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Application;

    .line 79
    .local v0, "app":Landroid/app/Application;
    invoke-static {v2, v1, v7, v0}, Lcom/ultra/dex2cvmp/utils/Reflect;->setFieldValue(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Z

    .line 82
    const-string v3, "mProviderMap"

    invoke-static {v2, v1, v3}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldOjbect(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/util/ArrayMap;

    .line 85
    .local v2, "mProviderMap":Landroid/util/ArrayMap;, "Landroid/util/ArrayMap<Ljava/lang/String;Ljava/lang/String;>;"
    const/4 v3, 0x0

    .line 86
    .local v3, "it":Ljava/util/Iterator;, "Ljava/util/Iterator<Ljava/lang/String;>;"
    if-eqz v2, :cond_88

    .line 87
    invoke-virtual {v2}, Landroid/util/ArrayMap;->values()Ljava/util/Collection;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .line 89
    :cond_88
    if-eqz v3, :cond_a6

    .line 90
    :goto_8a
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_a6

    .line 91
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 92
    .local v7, "providerClientRecord":Ljava/lang/Object;
    const-string v8, "android.app.ActivityThread$ProviderClientRecord"

    const-string v12, "mLocalProvider"

    invoke-static {v8, v7, v12}, Lcom/ultra/dex2cvmp/utils/Reflect;->getFieldOjbect(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    .line 95
    .local v8, "localProvider":Ljava/lang/Object;
    if-eqz v8, :cond_a5

    .line 96
    const-string v12, "android.content.ContentProvider"

    const-string v13, "mContext"

    invoke-static {v12, v13, v8, v0}, Lcom/ultra/dex2cvmp/utils/Reflect;->setFieldOjbect(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 99
    .end local v7  # "providerClientRecord":Ljava/lang/Object;
    .end local v8  # "localProvider":Ljava/lang/Object;
    :cond_a5
    goto :goto_8a

    .line 101
    :cond_a6
    return-object v0
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .registers 4
    .param p1, "base"  # Landroid/content/Context;

    .line 21
    invoke-super {p0, p1}, Landroid/app/Application;->attachBaseContext(Landroid/content/Context;)V

    .line 23
    :try_start_3
    new-instance v0, Lcom/ultra/dex2cvmp/utils/DexProtector;

    invoke-direct {v0, p1}, Lcom/ultra/dex2cvmp/utils/DexProtector;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->install(Landroid/content/Context;)V
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_d

    .line 26
    nop

    .line 27
    return-void

    .line 24
    :catchall_d
    move-exception v0

    .line 25
    .local v0, "e":Ljava/lang/Throwable;
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method public onCreate()V
    .registers 2

    .line 31
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 32
    invoke-direct {p0}, Lcom/ultra/dex2cvmp/ProxyApplication;->realApplication()Landroid/app/Application;

    move-result-object v0

    .line 33
    .local v0, "app":Landroid/app/Application;
    if-eqz v0, :cond_c

    .line 34
    invoke-virtual {v0}, Landroid/app/Application;->onCreate()V

    .line 36
    :cond_c
    return-void
.end method
