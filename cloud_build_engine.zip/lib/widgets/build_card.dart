import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/build_job.dart';
import '../theme/app_theme.dart';
import '../utils/icon_cache.dart';

class BuildCard extends StatelessWidget {
  final BuildJob      job;
  final VoidCallback  onTap;
  final VoidCallback? onDelete;

  const BuildCard({
    super.key,
    required this.job,
    required this.onTap,
    this.onDelete,
  });

  Color get _statusColor {
    if (job.isRunning) return AppTheme.running;
    if (job.isSuccess) return AppTheme.success;
    if (job.isFailed)  return AppTheme.error;
    return AppTheme.textSec;
  }

  IconData get _statusIcon {
    if (job.status == 'queued')        return Icons.schedule_rounded;
    if (job.status == 'in_progress')   return Icons.autorenew_rounded;
    if (job.isSuccess)                 return Icons.check_circle_rounded;
    if (job.conclusion == 'cancelled') return Icons.cancel_rounded;
    if (job.isFailed)                  return Icons.error_rounded;
    return Icons.help_outline_rounded;
  }

  @override
  Widget build(BuildContext context) {
    final canDelete = !job.isRunning && onDelete != null;

    final cardContent = GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.fromLTRB(16, 12, 12, 16),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: job.isRunning
                ? AppTheme.running.withOpacity(0.40)
                : AppTheme.border,
          ),
          boxShadow: job.isRunning
              ? [BoxShadow(color: AppTheme.running.withOpacity(0.08), blurRadius: 12)]
              : null,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            _AppIconOrDot(
              jobId:       job.id,
              statusColor: _statusColor,
              statusIcon:  _statusIcon,
              pulsing:     job.isRunning,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          job.appName,
                          style: const TextStyle(
                            color:      AppTheme.textPrim,
                            fontWeight: FontWeight.w700,
                            fontSize:   15,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      // ── delete icon (non-running jobs only) ─────────────────
                      if (canDelete)
                        GestureDetector(
                          onTap:    onDelete,
                          behavior: HitTestBehavior.opaque,
                          child: const Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: Icon(Icons.delete_outline_rounded,
                                color: AppTheme.error, size: 17),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    job.packageName,
                    style: const TextStyle(color: AppTheme.textSec, fontSize: 11),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      _Chip(label: job.statusLabel, color: _statusColor),
                      const SizedBox(width: 6),
                      _Chip(
                        label: job.flutterVersion == 'auto-detect'
                            ? 'Auto-detect'
                            : 'Flutter ${job.flutterVersion}',
                        color: AppTheme.accentGlow,
                      ),
                      const Spacer(),
                      Text(
                        timeago.format(job.createdAt),
                        style: const TextStyle(color: AppTheme.textSec, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            if (job.isSuccess)
              job.apkPath != null
                ? const Icon(Icons.folder_rounded, color: AppTheme.success, size: 22)
                : const Icon(Icons.download_rounded, color: AppTheme.accent, size: 22)
            else if (job.isRunning)
              const Icon(Icons.chevron_right_rounded, color: AppTheme.running, size: 22)
            else
              const Icon(Icons.chevron_right_rounded, color: AppTheme.textSec, size: 22),
          ],
        ),
      ),
    );

    if (!canDelete) return cardContent;

    // Swipe left to delete for non-running jobs
    return Dismissible(
      key:       ValueKey(job.id),
      direction: DismissDirection.endToStart,
      background: Container(
        margin:    const EdgeInsets.only(bottom: 12),
        alignment: Alignment.centerRight,
        padding:   const EdgeInsets.only(right: 22),
        decoration: BoxDecoration(
          color:        AppTheme.error.withOpacity(0.12),
          borderRadius: BorderRadius.circular(16),
          border:       Border.all(color: AppTheme.error.withOpacity(0.35)),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delete_rounded, color: AppTheme.error, size: 24),
            SizedBox(height: 4),
            Text('Delete', style: TextStyle(color: AppTheme.error, fontSize: 10,
                fontWeight: FontWeight.w600)),
          ],
        ),
      ),
      confirmDismiss: (_) async {
        return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: AppTheme.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: const Text('Delete build?',
                style: TextStyle(color: AppTheme.textPrim, fontWeight: FontWeight.w700)),
            content: Text('Remove "${job.appName}" from history?',
                style: const TextStyle(color: AppTheme.textSec)),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel', style: TextStyle(color: AppTheme.textSec)),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Delete', style: TextStyle(color: AppTheme.error,
                    fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ) ?? false;
      },
      onDismissed: (_) => onDelete?.call(),
      child: cardContent,
    );
  }
}

// ── App icon with status badge (falls back to dot when no icon cached) ────────

class _AppIconOrDot extends StatelessWidget {
  final String   jobId;
  final Color    statusColor;
  final IconData statusIcon;
  final bool     pulsing;
  const _AppIconOrDot({
    required this.jobId,
    required this.statusColor,
    required this.statusIcon,
    required this.pulsing,
  });

  @override
  Widget build(BuildContext context) {
    final iconBytes = IconCache.get(jobId);
    if (iconBytes == null) {
      return _StatusDot(color: statusColor, pulsing: pulsing, icon: statusIcon);
    }

    return SizedBox(
      width: 40, height: 40,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // ── Real app icon ───────────────────────────────────────────────
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.memory(iconBytes, width: 40, height: 40, fit: BoxFit.cover),
          ),
          // ── Status badge — bottom-right corner ──────────────────────────
          Positioned(
            right: -3, bottom: -3,
            child: Container(
              width: 16, height: 16,
              decoration: BoxDecoration(
                color:  statusColor,
                shape:  BoxShape.circle,
                border: Border.all(color: const Color(0xFF0d1b2e), width: 2),
              ),
              child: Icon(statusIcon, color: Colors.white, size: 8),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Status dot ────────────────────────────────────────────────────────────────

class _StatusDot extends StatefulWidget {
  final Color    color;
  final bool     pulsing;
  final IconData icon;
  const _StatusDot({required this.color, required this.pulsing, required this.icon});

  @override
  State<_StatusDot> createState() => _StatusDotState();
}

class _StatusDotState extends State<_StatusDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>   _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.4, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (!widget.pulsing) {
      return Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color:        widget.color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(widget.icon, color: widget.color, size: 20),
      );
    }
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color:        widget.color.withOpacity(0.08 + _anim.value * 0.10),
          borderRadius: BorderRadius.circular(12),
          border:       Border.all(color: widget.color.withOpacity(_anim.value * 0.5)),
        ),
        child: Icon(widget.icon, color: widget.color, size: 20),
      ),
    );
  }
}

// ── Status chip ───────────────────────────────────────────────────────────────

class _Chip extends StatelessWidget {
  final String label;
  final Color  color;
  const _Chip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color:        color.withOpacity(0.12),
      borderRadius: BorderRadius.circular(6),
      border:       Border.all(color: color.withOpacity(0.30)),
    ),
    child: Text(label,
        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600)),
  );
}
