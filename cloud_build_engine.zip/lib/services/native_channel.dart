import 'package:flutter/services.dart';

class NativeChannel {
  static const _channel = MethodChannel('com.cloud.build.engine/native');
  static String? _cachedUrl;

  static Future<String> workerUrl() async {
    _cachedUrl ??= await _channel.invokeMethod<String>('workerUrl') ?? '';
    return _cachedUrl!;
  }

  static String? _cachedTgUrl;

  static Future<String> telegramUrl() async {
    _cachedTgUrl ??= await _channel.invokeMethod<String>('telegramUrl') ?? '';
    return _cachedTgUrl!;
  }
}
