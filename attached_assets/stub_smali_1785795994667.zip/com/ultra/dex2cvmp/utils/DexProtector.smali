.class public Lcom/ultra/dex2cvmp/utils/DexProtector;
.super Ljava/lang/Object;
.source "DexProtector.java"


# static fields
.field private static final dexFiles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field

.field public static mContext:Landroid/content/Context;


# instance fields
.field dexDir:Ljava/io/File;

.field optDir:Ljava/io/File;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 48
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexFiles:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    sput-object p1, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    .line 66
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexFiles:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 67
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strAppDex()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    iput-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    .line 68
    new-instance v0, Ljava/io/File;

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strOpt()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->optDir:Ljava/io/File;

    .line 69
    iget-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->deleteFloor(Ljava/lang/String;)V

    .line 70
    iget-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->mkdir(Ljava/lang/String;)V

    .line 71
    iget-object v0, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->optDir:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/FileUtils;->mkdir(Ljava/lang/String;)V

    .line 72
    return-void
.end method

.method public static getRealAppClass()Ljava/lang/String;
    .registers 1

    .line 254
    sget-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    return-object v0
.end method

.method private injectDexElements(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V
    .registers 15
    .param p1, "src"  # Ljava/lang/ClassLoader;
    .param p2, "dst"  # Ljava/lang/ClassLoader;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 177
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    .line 178
    .local v0, "pathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    .line 179
    .local v1, "srcPathList":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDexElements()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    .line 180
    .local v2, "dexElementsField":Ljava/lang/reflect/Field;
    invoke-virtual {v2, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/Object;

    .line 182
    .local v3, "added":[Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v4

    invoke-static {p2, v4}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    .line 183
    .local v4, "dstPathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v4, p2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .line 184
    .local v5, "dstPathList":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDexElements()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v6

    .line 185
    .local v6, "dstDexElemField":Ljava/lang/reflect/Field;
    invoke-virtual {v6, v5}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/Object;

    .line 187
    .local v7, "existing":[Ljava/lang/Object;
    nop

    .line 188
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v8

    array-length v9, v7

    array-length v10, v3

    add-int/2addr v9, v10

    .line 187
    invoke-static {v8, v9}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, [Ljava/lang/Object;

    .line 190
    .local v8, "merged":[Ljava/lang/Object;
    array-length v9, v7

    const/4 v10, 0x0

    invoke-static {v7, v10, v8, v10, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 191
    array-length v9, v7

    array-length v11, v3

    invoke-static {v3, v10, v8, v9, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 192
    invoke-virtual {v6, v5, v8}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 193
    return-void
.end method

.method private invokeMakeElements(Ljava/lang/Object;Ljava/util/List;Ljava/io/File;Ljava/lang/ClassLoader;)[Ljava/lang/Object;
    .registers 22
    .param p1, "pathList"  # Ljava/lang/Object;
    .param p3, "optDir"  # Ljava/io/File;
    .param p4, "loader"  # Ljava/lang/ClassLoader;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;",
            "Ljava/io/File;",
            "Ljava/lang/ClassLoader;",
            ")[",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 214
    .local p2, "files":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 215
    .local v2, "suppressed":Ljava/util/List;, "Ljava/util/List<Ljava/io/IOException;>;"
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMakeDexElements()Ljava/lang/String;

    move-result-object v3

    .line 216
    .local v3, "mde":Ljava/lang/String;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strMakePathElements()Ljava/lang/String;

    move-result-object v4

    .line 217
    .local v4, "mpe":Ljava/lang/String;
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    .line 218
    .local v5, "clazz":Ljava/lang/Class;, "Ljava/lang/Class<*>;"
    :goto_15
    if-eqz v5, :cond_a9

    const-class v6, Ljava/lang/Object;

    if-eq v5, v6, :cond_a9

    .line 219
    invoke-virtual {v5}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v6

    array-length v7, v6

    const/4 v9, 0x0

    :goto_21
    if-ge v9, v7, :cond_a3

    aget-object v10, v6, v9

    .line 220
    .local v10, "m":Ljava/lang/reflect/Method;
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v11

    .line 221
    .local v11, "nm":Ljava/lang/String;
    invoke-virtual {v11, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_38

    invoke-virtual {v11, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_38

    const/16 v16, 0x0

    goto :goto_9f

    .line 222
    :cond_38
    invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v12

    .line 223
    .local v12, "pt":[Ljava/lang/Class;, "[Ljava/lang/Class<*>;"
    const/4 v13, 0x1

    invoke-virtual {v10, v13}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 224
    array-length v14, v12

    const/4 v15, 0x3

    const/16 v16, 0x0

    const/4 v8, 0x2

    packed-switch v14, :pswitch_data_ba

    goto :goto_9f

    .line 225
    :pswitch_49  #0x4
    const/4 v6, 0x4

    new-array v6, v6, [Ljava/lang/Object;

    aput-object v1, v6, v16

    aput-object p3, v6, v13

    aput-object v2, v6, v8

    aput-object p4, v6, v15

    invoke-virtual {v10, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 227
    :pswitch_5b  #0x3
    const-class v6, Ljava/util/ArrayList;

    aget-object v7, v12, v16

    invoke-virtual {v6, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7e

    .line 228
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-array v9, v15, [Ljava/lang/Object;

    aput-object v6, v9, v16

    aput-object p3, v9, v13

    aput-object v7, v9, v8

    invoke-virtual {v10, v0, v9}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 230
    :cond_7e
    new-array v6, v15, [Ljava/lang/Object;

    aput-object v1, v6, v16

    aput-object p3, v6, v13

    aput-object v2, v6, v8

    invoke-virtual {v10, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 231
    :pswitch_8d  #0x2
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-array v7, v8, [Ljava/lang/Object;

    aput-object v6, v7, v16

    aput-object p3, v7, v13

    invoke-virtual {v10, v0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    return-object v6

    .line 219
    .end local v10  # "m":Ljava/lang/reflect/Method;
    .end local v11  # "nm":Ljava/lang/String;
    .end local v12  # "pt":[Ljava/lang/Class;, "[Ljava/lang/Class<*>;"
    :goto_9f
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_21

    .line 234
    :cond_a3
    invoke-virtual {v5}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v5

    goto/16 :goto_15

    .line 236
    :cond_a9
    new-instance v6, Ljava/lang/RuntimeException;

    const/16 v7, 0x11

    new-array v7, v7, [C

    fill-array-data v7, :array_c4

    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v6

    :pswitch_data_ba
    .packed-switch 0x2
        :pswitch_8d  #00000002
        :pswitch_5b  #00000003
        :pswitch_49  #00000004
    .end packed-switch

    :array_c4
    .array-data 2
        0x6es
        0x6fs
        0x20s
        0x6ds
        0x61s
        0x6bs
        0x65s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x20s
        0x66s
        0x6fs
        0x75s
        0x6es
        0x64s
    .end array-data
.end method

.method private static varargs k([C)Ljava/lang/String;
    .registers 2
    .param p0, "c"  # [C

    .line 53
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method private loadDex(Landroid/content/Context;Ljava/util/List;Ljava/io/File;)V
    .registers 14
    .param p1, "context"  # Landroid/content/Context;
    .param p3, "optDir"  # Ljava/io/File;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 197
    .local p2, "files":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    .line 198
    :cond_7
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    .line 199
    .local v0, "classLoader":Ljava/lang/ClassLoader;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strPathList()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 200
    .local v1, "pathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 201
    .local v2, "pathList":Ljava/lang/Object;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDexElements()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    .line 202
    .local v3, "dexElementsField":Ljava/lang/reflect/Field;
    invoke-virtual {v3, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Ljava/lang/Object;

    .line 203
    .local v4, "existing":[Ljava/lang/Object;
    invoke-direct {p0, v2, p2, p3, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->invokeMakeElements(Ljava/lang/Object;Ljava/util/List;Ljava/io/File;Ljava/lang/ClassLoader;)[Ljava/lang/Object;

    move-result-object v5

    .line 204
    .local v5, "added":[Ljava/lang/Object;
    nop

    .line 205
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v6

    array-length v7, v4

    array-length v8, v5

    add-int/2addr v7, v8

    .line 204
    invoke-static {v6, v7}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/Object;

    .line 207
    .local v6, "merged":[Ljava/lang/Object;
    array-length v7, v4

    const/4 v8, 0x0

    invoke-static {v4, v8, v6, v8, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 208
    array-length v7, v4

    array-length v9, v5

    invoke-static {v5, v8, v6, v7, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 209
    invoke-virtual {v3, v2, v6}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 210
    return-void
.end method

.method private loadInMemory(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V
    .registers 11
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "dis"  # Ljava/io/DataInputStream;
    .param p3, "shardCount"  # I
    .param p4, "sizes"  # [I
    .param p5, "key"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 133
    new-array v0, p3, [Ljava/nio/ByteBuffer;

    .line 134
    .local v0, "buffers":[Ljava/nio/ByteBuffer;
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_3
    if-ge v1, p3, :cond_19

    .line 135
    aget v2, p4, v1

    new-array v2, v2, [B

    .line 136
    .local v2, "encrypted":[B
    invoke-virtual {p2, v2}, Ljava/io/DataInputStream;->readFully([B)V

    .line 137
    invoke-static {p5, v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptToBytes([B[B)[B

    move-result-object v3

    .line 138
    .local v3, "dexBytes":[B
    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v4

    aput-object v4, v0, v1

    .line 134
    .end local v2  # "encrypted":[B
    .end local v3  # "dexBytes":[B
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    .line 143
    .end local v1  # "i":I
    :cond_19
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    .line 144
    .local v1, "parent":Ljava/lang/ClassLoader;
    new-instance v2, Ldalvik/system/InMemoryDexClassLoader;

    invoke-direct {v2, v0, v1}, Ldalvik/system/InMemoryDexClassLoader;-><init>([Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V

    .line 147
    .local v2, "inMemory":Ljava/lang/ClassLoader;
    invoke-direct {p0, v2, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->injectDexElements(Ljava/lang/ClassLoader;Ljava/lang/ClassLoader;)V

    .line 148
    return-void
.end method

.method private loadViaFiles(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V
    .registers 15
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "dis"  # Ljava/io/DataInputStream;
    .param p3, "shardCount"  # I
    .param p4, "sizes"  # [I
    .param p5, "key"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 154
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strAppDex()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    .line 155
    .local v0, "dir":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_12

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 156
    :cond_12
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 158
    .local v2, "files":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_18
    if-ge v3, p3, :cond_62

    .line 159
    aget v4, p4, v3

    new-array v4, v4, [B

    .line 160
    .local v4, "encrypted":[B
    invoke-virtual {p2, v4}, Ljava/io/DataInputStream;->readFully([B)V

    .line 161
    invoke-static {p5, v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptToBytes([B[B)[B

    move-result-object v5

    .line 163
    .local v5, "dexBytes":[B
    new-instance v6, Ljava/io/File;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strShard()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    add-int/lit8 v8, v3, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexProtector;->strDotDex()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v0, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 164
    .local v6, "outFile":Ljava/io/File;
    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v6}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 165
    .local v7, "fos":Ljava/io/FileOutputStream;
    :try_start_4e
    invoke-virtual {v7, v5}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_51
    .catchall {:try_start_4e .. :try_end_51} :catchall_5d

    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V

    .line 166
    invoke-virtual {v6, v1, v1}, Ljava/io/File;->setWritable(ZZ)Z

    .line 167
    invoke-interface {v2, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 158
    .end local v4  # "encrypted":[B
    .end local v5  # "dexBytes":[B
    .end local v6  # "outFile":Ljava/io/File;
    .end local v7  # "fos":Ljava/io/FileOutputStream;
    add-int/lit8 v3, v3, 0x1

    goto :goto_18

    .line 165
    .restart local v4  # "encrypted":[B
    .restart local v5  # "dexBytes":[B
    .restart local v6  # "outFile":Ljava/io/File;
    .restart local v7  # "fos":Ljava/io/FileOutputStream;
    :catchall_5d
    move-exception v1

    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V

    throw v1

    .line 170
    .end local v3  # "i":I
    .end local v4  # "encrypted":[B
    .end local v5  # "dexBytes":[B
    .end local v6  # "outFile":Ljava/io/File;
    .end local v7  # "fos":Ljava/io/FileOutputStream;
    :cond_62
    iget-object v1, p0, Lcom/ultra/dex2cvmp/utils/DexProtector;->dexDir:Ljava/io/File;

    invoke-direct {p0, p1, v2, v1}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadDex(Landroid/content/Context;Ljava/util/List;Ljava/io/File;)V

    .line 171
    return-void
.end method

.method private static readAsset(Landroid/content/Context;Ljava/lang/String;)[B
    .registers 4
    .param p0, "ctx"  # Landroid/content/Context;
    .param p1, "path"  # Ljava/lang/String;

    .line 243
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 244
    .local v0, "is":Ljava/io/InputStream;
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v1

    .line 245
    .local v1, "data":[B
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_f} :catch_10

    .line 246
    return-object v1

    .line 247
    .end local v0  # "is":Ljava/io/InputStream;
    .end local v1  # "data":[B
    :catch_10
    move-exception v0

    .line 248
    .local v0, "e":Ljava/lang/Exception;
    const/4 v1, 0x0

    return-object v1
.end method

.method private static strAppDex()Ljava/lang/String;
    .registers 1

    .line 54
    const/4 v0, 0x7

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x61s
        0x70s
        0x70s
        0x5fs
        0x64s
        0x65s
        0x78s
    .end array-data
.end method

.method private static strDexElements()Ljava/lang/String;
    .registers 1

    .line 59
    const/16 v0, 0xb

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x64s
        0x65s
        0x78s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x65s
        0x6es
        0x74s
        0x73s
    .end array-data
.end method

.method private static strDotDex()Ljava/lang/String;
    .registers 1

    .line 57
    const/4 v0, 0x4

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x2es
        0x64s
        0x65s
        0x78s
    .end array-data
.end method

.method private static strMakeDexElements()Ljava/lang/String;
    .registers 1

    .line 60
    const/16 v0, 0xf

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x6ds
        0x61s
        0x6bs
        0x65s
        0x44s
        0x65s
        0x78s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x65s
        0x6es
        0x74s
        0x73s
    .end array-data
.end method

.method private static strMakePathElements()Ljava/lang/String;
    .registers 1

    .line 61
    const/16 v0, 0x10

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x6ds
        0x61s
        0x6bs
        0x65s
        0x50s
        0x61s
        0x74s
        0x68s
        0x45s
        0x6cs
        0x65s
        0x6ds
        0x65s
        0x6es
        0x74s
        0x73s
    .end array-data
.end method

.method private static strOpt()Ljava/lang/String;
    .registers 1

    .line 55
    const/4 v0, 0x3

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x6fs
        0x70s
        0x74s
    .end array-data
.end method

.method private static strPathList()Ljava/lang/String;
    .registers 1

    .line 58
    const/16 v0, 0x8

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :array_c
    .array-data 2
        0x70s
        0x61s
        0x74s
        0x68s
        0x4cs
        0x69s
        0x73s
        0x74s
    .end array-data
.end method

.method private static strShard()Ljava/lang/String;
    .registers 1

    .line 56
    const/4 v0, 0x6

    new-array v0, v0, [C

    fill-array-data v0, :array_c

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_c
    .array-data 2
        0x73s
        0x68s
        0x61s
        0x72s
        0x64s
        0x2ds
    .end array-data
.end method


# virtual methods
.method public install(Landroid/content/Context;)V
    .registers 13
    .param p1, "context"  # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 76
    invoke-static {p1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->loadPhantomLib(Landroid/content/Context;)V

    .line 80
    const/4 v1, 0x0

    :try_start_4
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v2, "phantom/app.cfg"

    invoke-virtual {v0, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 81
    .local v0, "ris":Ljava/io/InputStream;
    const/16 v2, 0x200

    new-array v2, v2, [B

    .line 82
    .local v2, "buf":[B
    invoke-virtual {v0, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    .line 83
    .local v3, "n":I
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 84
    if-lez v3, :cond_32

    .line 85
    new-instance v4, Ljava/lang/String;

    const-string v5, "UTF-8"

    invoke-direct {v4, v2, v1, v3, v5}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    .line 86
    .local v4, "realApp":Ljava/lang/String;
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_32

    sput-object v4, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_30} :catch_31

    goto :goto_32

    .line 88
    .end local v0  # "ris":Ljava/io/InputStream;
    .end local v2  # "buf":[B
    .end local v3  # "n":I
    .end local v4  # "realApp":Ljava/lang/String;
    :catch_31
    move-exception v0

    :cond_32
    :goto_32
    nop

    .line 91
    const-string v0, "phantom/ph_salt"

    invoke-static {p1, v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->readAsset(Landroid/content/Context;Ljava/lang/String;)[B

    move-result-object v2

    .line 92
    .local v2, "salt":[B
    if-eqz v2, :cond_9f

    array-length v0, v2

    const/16 v3, 0x10

    if-ne v0, v3, :cond_9f

    .line 99
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 100
    invoke-virtual {v0, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3

    .line 101
    .local v3, "pkgNameUtf8":[B
    invoke-static {v2, v3}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nativeGetKey([B[B)[B

    move-result-object v9

    .line 105
    .local v9, "key":[B
    :try_start_4e
    sget-object v0, Lcom/ultra/dex2cvmp/utils/DexProtector;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const-string v4, "phantom/phantom.vmp"

    invoke-virtual {v0, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 106
    .local v0, "bundleStream":Ljava/io/InputStream;
    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v4

    move-object v10, v4

    .line 107
    .local v10, "bundleBytes":[B
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    .line 109
    new-instance v6, Ljava/io/DataInputStream;

    new-instance v4, Ljava/io/ByteArrayInputStream;

    invoke-direct {v4, v10}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v6, v4}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 110
    .local v6, "dis":Ljava/io/DataInputStream;
    invoke-virtual {v6}, Ljava/io/DataInputStream;->readInt()I

    move-result v7

    .line 111
    .local v7, "shardCount":I
    new-array v8, v7, [I
    :try_end_72
    .catchall {:try_start_4e .. :try_end_72} :catchall_99

    .line 112
    .local v8, "sizes":[I
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_73
    if-ge v4, v7, :cond_81

    :try_start_75
    invoke-virtual {v6}, Ljava/io/DataInputStream;->readInt()I

    move-result v5

    aput v5, v8, v4
    :try_end_7b
    .catchall {:try_start_75 .. :try_end_7b} :catchall_7e

    add-int/lit8 v4, v4, 0x1

    goto :goto_73

    .line 123
    .end local v0  # "bundleStream":Ljava/io/InputStream;
    .end local v4  # "i":I
    .end local v6  # "dis":Ljava/io/DataInputStream;
    .end local v7  # "shardCount":I
    .end local v8  # "sizes":[I
    .end local v10  # "bundleBytes":[B
    :catchall_7e
    move-exception v0

    move-object v5, p1

    goto :goto_9b

    .line 114
    .restart local v0  # "bundleStream":Ljava/io/InputStream;
    .restart local v6  # "dis":Ljava/io/DataInputStream;
    .restart local v7  # "shardCount":I
    .restart local v8  # "sizes":[I
    .restart local v10  # "bundleBytes":[B
    :cond_81
    :try_start_81
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_83
    .catchall {:try_start_81 .. :try_end_83} :catchall_99

    const/16 v5, 0x1b

    if-lt v4, v5, :cond_8d

    .line 116
    move-object v4, p0

    move-object v5, p1

    .end local p1  # "context":Landroid/content/Context;
    .local v5, "context":Landroid/content/Context;
    :try_start_89
    invoke-direct/range {v4 .. v9}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadInMemory(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V

    goto :goto_92

    .line 119
    .end local v5  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    :cond_8d
    move-object v5, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v5  # "context":Landroid/content/Context;
    move-object v4, p0

    invoke-direct/range {v4 .. v9}, Lcom/ultra/dex2cvmp/utils/DexProtector;->loadViaFiles(Landroid/content/Context;Ljava/io/DataInputStream;I[I[B)V
    :try_end_92
    .catchall {:try_start_89 .. :try_end_92} :catchall_97

    .line 123
    .end local v0  # "bundleStream":Ljava/io/InputStream;
    .end local v6  # "dis":Ljava/io/DataInputStream;
    .end local v7  # "shardCount":I
    .end local v8  # "sizes":[I
    .end local v10  # "bundleBytes":[B
    :goto_92
    invoke-static {v9, v1}, Ljava/util/Arrays;->fill([BB)V

    .line 124
    nop

    .line 125
    return-void

    .line 123
    :catchall_97
    move-exception v0

    goto :goto_9b

    .end local v5  # "context":Landroid/content/Context;
    .restart local p1  # "context":Landroid/content/Context;
    :catchall_99
    move-exception v0

    move-object v5, p1

    .end local p1  # "context":Landroid/content/Context;
    .restart local v5  # "context":Landroid/content/Context;
    :goto_9b
    invoke-static {v9, v1}, Ljava/util/Arrays;->fill([BB)V

    .line 124
    throw v0

    .line 92
    .end local v3  # "pkgNameUtf8":[B
    .end local v5  # "context":Landroid/content/Context;
    .end local v9  # "key":[B
    .restart local p1  # "context":Landroid/content/Context;
    :cond_9f
    move-object v5, p1

    .line 93
    .end local p1  # "context":Landroid/content/Context;
    .restart local v5  # "context":Landroid/content/Context;
    new-instance p1, Ljava/lang/RuntimeException;

    const/16 v0, 0x8

    new-array v0, v0, [C

    fill-array-data v0, :array_b2

    invoke-static {v0}, Lcom/ultra/dex2cvmp/utils/DexProtector;->k([C)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :array_b2
    .array-data 2
        0x62s
        0x61s
        0x64s
        0x20s
        0x73s
        0x61s
        0x6cs
        0x74s
    .end array-data
.end method
