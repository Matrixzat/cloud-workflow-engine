import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'native_channel.dart';

class PrepareUploadResult {
  final String jobId;
  final String assetName;
  final String uploadUrl;
  final String auth;

  const PrepareUploadResult({
    required this.jobId,
    required this.assetName,
    required this.uploadUrl,
    required this.auth,
  });

  factory PrepareUploadResult.fromJson(Map<String, dynamic> j) =>
      PrepareUploadResult(
        jobId:     j['job_id']     as String,
        assetName: j['asset_name'] as String,
        uploadUrl: j['upload_url'] as String,
        auth:      j['auth']       as String,
      );
}

class WorkerService {
  static String? _url;

  static Future<String> _base() async {
    _url ??= await NativeChannel.workerUrl();
    return _url!;
  }

  // ── GET /prepare-upload ──────────────────────────────────────────────────

  static Future<PrepareUploadResult> prepareUpload({String ext = 'zip'}) async {
    final base = await _base();
    final res  = await http.get(Uri.parse('$base/prepare-upload?ext=$ext'));
    if (res.statusCode != 200) {
      throw Exception('prepare-upload failed: ${res.statusCode}');
    }
    return PrepareUploadResult.fromJson(
        jsonDecode(res.body) as Map<String, dynamic>);
  }

  // ── Upload file directly to GitHub Releases (worker-provided URL + auth) ─

  static Future<int> uploadAsset({
    required String uploadUrl,
    required String auth,
    required String assetName,
    required File   file,
    void Function(double progress)? onProgress,
  }) async {
    final fileSize = await file.length();
    final url      = '$uploadUrl?name=${Uri.encodeComponent(assetName)}';
    final dio      = Dio();

    final response = await dio.post(
      url,
      data: file.openRead(),
      options: Options(
        headers: {
          'Authorization': auth,
          'Content-Type':  'application/octet-stream',
          'Content-Length': fileSize.toString(),
          'Accept':        'application/vnd.github.v3+json',
        },
        sendTimeout:    const Duration(minutes: 30),
        receiveTimeout: const Duration(minutes: 5),
      ),
      onSendProgress: (sent, total) {
        if (total > 0 && onProgress != null) onProgress(sent / total);
      },
    );

    if (response.statusCode != 201) {
      throw Exception('Asset upload failed: ${response.statusCode}');
    }
    return (response.data as Map<String, dynamic>)['id'] as int;
  }

  // ── GET /dispatch-job ───────────────────────────────────────────────────

  static Future<void> dispatchJob({
    required String jobId,
    required int    assetId,
    required String appName,
    required String packageName,
    required String flutterVersion,
    String buildMode = 'release',
    bool   protect   = false,
  }) async {
    final base = await _base();
    final uri  = Uri.parse('$base/dispatch-job').replace(queryParameters: {
      'job_id':          jobId,
      'asset_id':        assetId.toString(),
      'app_name':        appName,
      'package_name':    packageName,
      'flutter_version': flutterVersion,
      'build_mode':      buildMode,
      'protect':         protect.toString(),
    });

    final res = await http.get(uri);
    if (res.statusCode != 200) {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      throw Exception('dispatch-job failed: ${body['error'] ?? res.statusCode}');
    }
  }

  // ── GET /find-run (poll until the run appears) ──────────────────────────

  static Future<int?> findRun({required DateTime after}) async {
    final base    = await _base();
    final afterMs = after.millisecondsSinceEpoch;

    for (int attempt = 0; attempt < 60; attempt++) {
      await Future.delayed(const Duration(seconds: 4));
      try {
        final res = await http.get(
            Uri.parse('$base/find-run?after=$afterMs'));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body) as Map<String, dynamic>;
          if (data['found'] == true) return data['run_id'] as int;
        }
      } catch (_) {}
    }
    return null;
  }

  // ── GET /status ─────────────────────────────────────────────────────────

  static Future<Map<String, dynamic>?> getStatus(int runId) async {
    final base = await _base();
    final res  = await http.get(Uri.parse('$base/status?run_id=$runId'));
    if (res.statusCode != 200) return null;
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  // ── GET /job-live ───────────────────────────────────────────────────────

  static Future<Map<String, dynamic>?> getJobLive(int runId) async {
    final base = await _base();
    final res  = await http.get(Uri.parse('$base/job-live?run_id=$runId'));
    if (res.statusCode != 200) return null;
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  // ── GET /job-error ──────────────────────────────────────────────────────

  static Future<String?> getJobError(int runId) async {
    final base = await _base();
    final res  = await http.get(Uri.parse('$base/job-error?run_id=$runId'));
    if (res.statusCode != 200) return null;
    return res.body.isNotEmpty ? res.body : null;
  }

  // ── POST /cancel-run ─────────────────────────────────────────────────────

  static Future<void> cancelRun(int runId) async {
    final base = await _base();
    final res  = await http.post(Uri.parse('$base/cancel-run?run_id=$runId'));
    if (res.statusCode != 200) {
      throw Exception('Cancel failed: ${res.statusCode}');
    }
  }

  // ── DELETE /asset ────────────────────────────────────────────────────────

  static Future<void> deleteAsset(int assetId) async {
    final base = await _base();
    await http.delete(Uri.parse('$base/asset?asset_id=$assetId'));
  }

  // ── GET /artifact (streams the ZIP back) ─────────────────────────────────

  static Future<String> downloadArtifact({
    required int    runId,
    required String jobId,
    required String destPath,
    void Function(int received, int total)? onProgress,
  }) async {
    final base = await _base();
    final url  = '$base/artifact?run_id=$runId&job_id=$jobId&prefix=apk';
    final dio  = Dio();

    await dio.download(
      url,
      destPath,
      onReceiveProgress: onProgress,
      options: Options(
        receiveTimeout: const Duration(minutes: 15),
        followRedirects: true,
      ),
    );
    return destPath;
  }

  // ── Poll until build completes ────────────────────────────────────────────

  static Future<String?> pollUntilComplete(
    int runId, {
    required void Function(String status) onStatus,
    int maxMinutes = 30,
  }) async {
    final deadline = DateTime.now().add(Duration(minutes: maxMinutes));
    while (DateTime.now().isBefore(deadline)) {
      await Future.delayed(const Duration(seconds: 10));
      final run = await getStatus(runId);
      if (run == null) continue;
      final status     = run['status']     as String? ?? 'unknown';
      final conclusion = run['conclusion'] as String?;
      onStatus(status);
      if (status == 'completed') return conclusion;
    }
    return null;
  }

}
