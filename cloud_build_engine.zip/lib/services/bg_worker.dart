import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

const String kBgTaskUnique = 'cbe_bg_poll_unique';
const String kBgTaskName   = 'cbe_bg_poll';

const _chId   = 'cbe_builds';
const _chName = 'Build Updates';

/// Top-level callback required by WorkManager — must stay at file/global scope.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      await _bgPoll();
    } catch (_) {}
    return true;
  });
}

// ── Notification helper ────────────────────────────────────────────────────

Future<FlutterLocalNotificationsPlugin> _initNotif() async {
  final notif = FlutterLocalNotificationsPlugin();
  await notif.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
  );
  return notif;
}

void _showNotif(
  FlutterLocalNotificationsPlugin notif,
  int id,
  String title,
  String body, {
  bool high = true,
}) {
  notif.show(
    id,
    title,
    body,
    NotificationDetails(
      android: AndroidNotificationDetails(
        _chId, _chName,
        importance: high ? Importance.max : Importance.defaultImportance,
        priority:   high ? Priority.high  : Priority.defaultPriority,
        playSound:  high,
      ),
    ),
  );
}

// ── Resolve best writable download directory ───────────────────────────────

Future<String> _resolveDownloadDir() async {
  final primary = Directory('/storage/emulated/0/Cloud_Build_Engine');
  try {
    await primary.create(recursive: true);
    final testFile = File('${primary.path}/.cbe_write_test');
    await testFile.writeAsString('ok');
    await testFile.delete();
    return primary.path;
  } catch (_) {}

  try {
    final extDir = await getExternalStorageDirectory();
    if (extDir != null) {
      final d = Directory('${extDir.path}/Cloud_Build_Engine');
      await d.create(recursive: true);
      return d.path;
    }
  } catch (_) {}

  final docDir = await getApplicationDocumentsDirectory();
  final fallback = Directory('${docDir.path}/Cloud_Build_Engine');
  await fallback.create(recursive: true);
  return fallback.path;
}

// ── Auto-download APK via Cloudflare Worker ─────────────────────────────────

Future<String?> _autoDownload({
  required String workerUrl,
  required dynamic runId,
  required String workerJobId,
  required String appName,
  required SharedPreferences prefs,
}) async {
  try {
    final destDir  = await _resolveDownloadDir();
    final safeName = appName
        .replaceAll(RegExp(r'[^a-zA-Z0-9_\-]'), '_')
        .replaceAll(RegExp(r'_+'), '_');
    final zipPath = '$destDir/${safeName}_${runId.toString()}.zip';

    await Dio().download(
      '$workerUrl/artifact?run_id=$runId&job_id=${Uri.encodeComponent(workerJobId)}&prefix=apk',
      zipPath,
      options: Options(
        followRedirects: true,
        receiveTimeout: const Duration(minutes: 15),
      ),
    );

    final saved = File(zipPath);
    if (!await saved.exists() || await saved.length() < 1024) {
      _logBg(prefs, 'autoDownload: file missing or too small');
      return null;
    }

    _logBg(prefs, 'autoDownload: SUCCESS → $zipPath (${(await saved.length() / 1024 / 1024).toStringAsFixed(1)} MB)');
    return zipPath;
  } catch (e, st) {
    _logBg(prefs, 'autoDownload ERROR: $e\n$st');
    return null;
  }
}

// ── Simple background log → SharedPreferences ──────────────────────────────
void _logBg(SharedPreferences prefs, String msg) {
  final ts   = DateTime.now().toIso8601String().substring(11, 19);
  final prev = prefs.getString('bg_log') ?? '';
  final lines = prev.split('\n');
  final kept  = lines.length > 30 ? lines.sublist(lines.length - 30) : lines;
  kept.add('[$ts] $msg');
  prefs.setString('bg_log', kept.join('\n'));
}

// ── Background polling task ────────────────────────────────────────────────

Future<void> _bgPoll() async {
  final prefs     = await SharedPreferences.getInstance();
  final workerUrl = prefs.getString('worker_url') ?? '';
  if (workerUrl.isEmpty) return;   // worker URL not yet cached — app not launched yet

  final raw = prefs.getString('build_jobs');
  if (raw == null) return;

  final List<dynamic> list = jsonDecode(raw);
  final notif   = await _initNotif();
  bool  changed = false;

  for (int i = 0; i < list.length; i++) {
    final job    = Map<String, dynamic>.from(list[i] as Map);
    final status = job['status'] as String? ?? '';

    if (status != 'queued' && status != 'in_progress' && status != 'waiting') continue;

    final runId        = job['runId'];
    final workerJobId  = job['workerJobId'] as String?;

    try {
      final res = await http.get(Uri.parse('$workerUrl/status?run_id=$runId'))
          .timeout(const Duration(seconds: 30));

      if (res.statusCode != 200) continue;

      final run           = jsonDecode(res.body) as Map<String, dynamic>;
      final newStatus     = run['status']     as String? ?? status;
      final newConclusion = run['conclusion'] as String?;

      if (newStatus != status || newConclusion != job['conclusion']) {
        job['status']     = newStatus;
        job['conclusion'] = newConclusion;
        changed = true;

        if (newStatus == 'completed') {
          final appName = job['appName'] as String? ?? 'Build';
          final notifId = (runId is int ? runId : int.tryParse(runId.toString()) ?? i) % 100000;

          if (newConclusion == 'success' && workerJobId != null) {
            _logBg(prefs, 'Build done for $appName (run $runId) — starting auto-download');

            final savedPath = await _autoDownload(
              workerUrl:    workerUrl,
              runId:        runId,
              workerJobId:  workerJobId,
              appName:      appName,
              prefs:        prefs,
            );

            if (savedPath != null) {
              job['apkPath'] = savedPath;
              final dirUsed  = savedPath.substring(0, savedPath.lastIndexOf('/'));
              _showNotif(
                notif, notifId,
                'Build Complete — $appName',
                'APK saved to ${dirUsed.split('/').last == 'Cloud_Build_Engine' ? '/Cloud_Build_Engine/' : dirUsed}',
              );
            } else {
              _showNotif(
                notif, notifId,
                'Build Complete — $appName',
                'APK is ready. Open the app to download it.',
              );
            }
          } else if (newConclusion == 'cancelled') {
            _showNotif(
              notif, notifId,
              'Build Cancelled',
              '$appName build was cancelled.',
              high: false,
            );
          } else {
            _showNotif(
              notif, notifId,
              'Build Failed — $appName',
              'Open the app to see what went wrong.',
            );
          }
        }

        list[i] = job;
      }
    } catch (e) {
      _logBg(prefs, 'poll error for run $runId: $e');
    }
  }

  if (changed) {
    await prefs.setString('build_jobs', jsonEncode(list));
  }
}

/// Call once at app start to register the background periodic task.
Future<void> registerBgTask() async {
  await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  await Workmanager().registerPeriodicTask(
    kBgTaskUnique,
    kBgTaskName,
    frequency: const Duration(minutes: 15),
    constraints: Constraints(networkType: NetworkType.connected),
    existingWorkPolicy: ExistingWorkPolicy.keep,
    backoffPolicy: BackoffPolicy.linear,
    backoffPolicyDelay: const Duration(minutes: 5),
  );
}
