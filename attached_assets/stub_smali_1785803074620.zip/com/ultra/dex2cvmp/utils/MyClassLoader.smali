.class public Lcom/ultra/dex2cvmp/utils/MyClassLoader;
.super Ljava/lang/Object;
.source "MyClassLoader.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ultra/dex2cvmp/utils/MyClassLoader$v19;,
        Lcom/ultra/dex2cvmp/utils/MyClassLoader$v14_18;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "MyClassLoader"

.field public static mContext:Landroid/content/Context;

.field private static mDexFiles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field mDexDir:Ljava/io/File;

.field mOptDir:Ljava/io/File;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 21
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mDexFiles:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/List;Ljava/io/File;Ljava/io/File;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;
    .param p3, "dexDir"  # Ljava/io/File;
    .param p4, "optDir"  # Ljava/io/File;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/io/File;",
            ">;",
            "Ljava/io/File;",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    .line 25
    .local p2, "dexFiles":Ljava/util/List;, "Ljava/util/List<Ljava/io/File;>;"
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 26
    sput-object p1, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mContext:Landroid/content/Context;

    .line 27
    sput-object p2, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mDexFiles:Ljava/util/List;

    .line 28
    iput-object p3, p0, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mDexDir:Ljava/io/File;

    .line 29
    iput-object p4, p0, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mOptDir:Ljava/io/File;

    .line 30
    return-void
.end method

.method private static expandFieldArray(Ljava/lang/Object;[Ljava/lang/Object;)V
    .registers 8
    .param p0, "instance"  # Ljava/lang/Object;
    .param p1, "extraElements"  # [Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/NoSuchFieldException;,
            Ljava/lang/IllegalArgumentException;,
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    .line 33
    const-string v0, "dexElements"

    invoke-static {p0, v0}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    .line 34
    .local v0, "jlrField":Ljava/lang/reflect/Field;
    invoke-virtual {v0, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/Object;

    .line 35
    .local v1, "original":[Ljava/lang/Object;
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v2

    array-length v3, v1

    array-length v4, p1

    add-int/2addr v3, v4

    invoke-static {v2, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/Object;

    .line 36
    .local v2, "combined":[Ljava/lang/Object;
    array-length v3, v1

    const/4 v4, 0x0

    invoke-static {v1, v4, v2, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 37
    array-length v3, v1

    array-length v5, p1

    invoke-static {p1, v4, v2, v3, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 38
    invoke-virtual {v0, p0, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 39
    return-void
.end method


# virtual methods
.method public loadDexByVersion()V
    .registers 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 42
    sget-object v0, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    .line 45
    .local v0, "classLoader":Ljava/lang/ClassLoader;
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v2, "pathList"

    const/4 v3, 0x0

    const/16 v4, 0x17

    if-lt v1, v4, :cond_89

    .line 47
    invoke-static {v0, v2}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 48
    .local v1, "pathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 50
    .local v2, "pathList":Ljava/lang/Object;
    const-string v4, "dexElements"

    invoke-static {v2, v4}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    .line 51
    .local v4, "dexElementsField":Ljava/lang/reflect/Field;
    invoke-virtual {v4, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [Ljava/lang/Object;

    .line 54
    .local v5, "dexElements":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 56
    .local v6, "factoryMethod":Ljava/lang/reflect/Method;
    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    :try_start_27
    const-string v10, "makePathElements"

    new-array v11, v9, [Ljava/lang/Class;

    const-class v12, Ljava/util/List;

    aput-object v12, v11, v3

    const-class v12, Ljava/io/File;

    aput-object v12, v11, v8

    const-class v12, Ljava/util/List;

    aput-object v12, v11, v7

    invoke-static {v2, v10, v11}, Lcom/ultra/dex2cvmp/utils/Reflect;->findMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v10
    :try_end_3b
    .catch Ljava/lang/NoSuchMethodException; {:try_start_27 .. :try_end_3b} :catch_3d

    move-object v6, v10

    .line 59
    goto :goto_3e

    .line 57
    :catch_3d
    move-exception v10

    .line 60
    :goto_3e
    if-nez v6, :cond_54

    .line 61
    new-array v10, v9, [Ljava/lang/Class;

    const-class v11, Ljava/util/List;

    aput-object v11, v10, v3

    const-class v11, Ljava/io/File;

    aput-object v11, v10, v8

    const-class v11, Ljava/util/List;

    aput-object v11, v10, v7

    const-string v11, "makeDexElements"

    invoke-static {v2, v11, v10}, Lcom/ultra/dex2cvmp/utils/Reflect;->findMethod(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    .line 64
    :cond_54
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 65
    .local v10, "suppressedExceptions":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/io/IOException;>;"
    iget-object v11, p0, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mOptDir:Ljava/io/File;

    new-array v9, v9, [Ljava/lang/Object;

    sget-object v12, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mDexFiles:Ljava/util/List;

    aput-object v12, v9, v3

    aput-object v11, v9, v8

    aput-object v10, v9, v7

    invoke-virtual {v6, v2, v9}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/Object;

    .line 68
    .local v7, "addElements":[Ljava/lang/Object;
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v8

    array-length v9, v5

    array-length v11, v7

    add-int/2addr v9, v11

    invoke-static {v8, v9}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, [Ljava/lang/Object;

    .line 69
    .local v8, "newElements":[Ljava/lang/Object;
    array-length v9, v5

    invoke-static {v5, v3, v8, v3, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 70
    array-length v9, v5

    array-length v11, v7

    invoke-static {v7, v3, v8, v9, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 73
    invoke-virtual {v4, v2, v8}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 74
    return-void

    .line 78
    .end local v1  # "pathListField":Ljava/lang/reflect/Field;
    .end local v2  # "pathList":Ljava/lang/Object;
    .end local v4  # "dexElementsField":Ljava/lang/reflect/Field;
    .end local v5  # "dexElements":[Ljava/lang/Object;
    .end local v6  # "factoryMethod":Ljava/lang/reflect/Method;
    .end local v7  # "addElements":[Ljava/lang/Object;
    .end local v8  # "newElements":[Ljava/lang/Object;
    .end local v10  # "suppressedExceptions":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/io/IOException;>;"
    :cond_89
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-ge v1, v4, :cond_fb

    .line 80
    invoke-static {v0, v2}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 81
    .restart local v1  # "pathListField":Ljava/lang/reflect/Field;
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 83
    .local v2, "dexPathList":Ljava/lang/Object;
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 84
    .local v4, "suppressedExceptions":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/io/IOException;>;"
    new-instance v5, Ljava/util/ArrayList;

    sget-object v6, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mDexFiles:Ljava/util/List;

    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v6, p0, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->mOptDir:Ljava/io/File;

    invoke-static {v2, v5, v6, v4}, Lcom/ultra/dex2cvmp/utils/MyClassLoader$v19;->-$$Nest$smmakeDexElements(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/io/File;Ljava/util/ArrayList;)[Ljava/lang/Object;

    move-result-object v5

    invoke-static {v2, v5}, Lcom/ultra/dex2cvmp/utils/MyClassLoader;->expandFieldArray(Ljava/lang/Object;[Ljava/lang/Object;)V

    .line 85
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_fa

    .line 86
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_b4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_c8

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/IOException;

    .line 87
    .local v6, "e":Ljava/io/IOException;
    const-string v7, "MyClassLoader"

    const-string v8, "Exception in makeDexElement"

    invoke-static {v7, v8, v6}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 88
    .end local v6  # "e":Ljava/io/IOException;
    goto :goto_b4

    .line 89
    :cond_c8
    nop

    .line 90
    const-string v5, "dexElementsSuppressedExceptions"

    invoke-static {v0, v5}, Lcom/ultra/dex2cvmp/utils/Reflect;->findField(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    .line 91
    .local v5, "suppressedExceptionsField":Ljava/lang/reflect/Field;
    nop

    .line 92
    invoke-virtual {v5, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/io/IOException;

    .line 94
    .local v6, "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    if-nez v6, :cond_e1

    .line 95
    new-array v3, v3, [Ljava/io/IOException;

    .line 96
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/io/IOException;

    .end local v6  # "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    .local v3, "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    goto :goto_f7

    .line 99
    .end local v3  # "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    .restart local v6  # "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    :cond_e1
    nop

    .line 100
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v7

    array-length v8, v6

    add-int/2addr v7, v8

    new-array v7, v7, [Ljava/io/IOException;

    .line 102
    .local v7, "combined":[Ljava/io/IOException;
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 103
    nop

    .line 104
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v8

    array-length v9, v6

    .line 103
    invoke-static {v6, v3, v7, v8, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 105
    move-object v3, v7

    .line 108
    .end local v6  # "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    .end local v7  # "combined":[Ljava/io/IOException;
    .restart local v3  # "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    :goto_f7
    invoke-virtual {v5, v0, v3}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 110
    .end local v3  # "dexElementsSuppressedExceptions":[Ljava/io/IOException;
    .end local v5  # "suppressedExceptionsField":Ljava/lang/reflect/Field;
    :cond_fa
    return-void

    .line 114
    .end local v1  # "pathListField":Ljava/lang/reflect/Field;
    .end local v2  # "dexPathList":Ljava/lang/Object;
    .end local v4  # "suppressedExceptions":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/io/IOException;>;"
    :cond_fb
    nop

    .line 152
    nop

    .line 159
    return-void
.end method
