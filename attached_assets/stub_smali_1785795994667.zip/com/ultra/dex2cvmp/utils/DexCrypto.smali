.class public Lcom/ultra/dex2cvmp/utils/DexCrypto;
.super Ljava/lang/Object;
.source "DexCrypto.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static FxIjsF([I)[I
    .registers 8
    .param p0, "iArr"  # [I

    .line 200
    const/16 v0, 0x1b

    new-array v0, v0, [I

    .line 201
    .local v0, "r":[I
    const/4 v1, 0x0

    aget v2, p0, v1

    .line 202
    .local v2, "i":I
    aput v2, v0, v1

    .line 203
    const/4 v1, 0x1

    aget v1, p0, v1

    const/4 v3, 0x2

    aget v3, p0, v3

    const/4 v4, 0x3

    aget v4, p0, v4

    filled-new-array {v1, v3, v4}, [I

    move-result-object v1

    .line 204
    .local v1, "t":[I
    const/4 v3, 0x0

    .local v3, "i2":I
    :goto_17
    const/16 v4, 0x1a

    if-ge v3, v4, :cond_40

    .line 205
    rem-int/lit8 v4, v3, 0x3

    rem-int/lit8 v5, v3, 0x3

    aget v5, v1, v5

    ushr-int/lit8 v5, v5, 0x8

    rem-int/lit8 v6, v3, 0x3

    aget v6, v1, v6

    shl-int/lit8 v6, v6, 0x18

    or-int/2addr v5, v6

    add-int/2addr v5, v2

    xor-int/2addr v5, v3

    aput v5, v1, v4

    .line 206
    shl-int/lit8 v4, v2, 0x3

    ushr-int/lit8 v5, v2, 0x1d

    or-int/2addr v4, v5

    rem-int/lit8 v5, v3, 0x3

    aget v5, v1, v5

    xor-int v2, v4, v5

    .line 207
    add-int/lit8 v4, v3, 0x1

    aput v2, v0, v4

    .line 204
    add-int/lit8 v3, v3, 0x1

    goto :goto_17

    .line 209
    .end local v3  # "i2":I
    :cond_40
    return-object v0
.end method

.method private static blobKey()[B
    .registers 4

    .line 73
    const/16 v0, 0x10

    new-array v0, v0, [C

    fill-array-data v0, :array_18

    .line 76
    .local v0, "c":[C
    array-length v1, v0

    new-array v1, v1, [B

    .line 77
    .local v1, "k":[B
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_b
    array-length v3, v0

    if-ge v2, v3, :cond_16

    aget-char v3, v0, v2

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    .line 78
    .end local v2  # "i":I
    :cond_16
    return-object v1

    nop

    :array_18
    .array-data 2
        0x50s
        0x68s
        0x34s
        0x6es
        0x74s
        0x30s
        0x6ds
        0x42s
        0x6cs
        0x30s
        0x62s
        0x4bs
        0x33s
        0x79s
        0x21s
        0x21s
    .end array-data
.end method

.method private static closeQuiet(Ljava/io/Closeable;)V
    .registers 2
    .param p0, "c"  # Ljava/io/Closeable;

    .line 255
    if-nez p0, :cond_3

    return-void

    .line 256
    :cond_3
    :try_start_3
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_6} :catch_7

    goto :goto_8

    :catch_7
    move-exception v0

    .line 257
    :goto_8
    return-void
.end method

.method public static decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 5
    .param p0, "key"  # [B
    .param p1, "input"  # Ljava/io/InputStream;
    .param p2, "output"  # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 139
    new-instance v0, Ljava/util/zip/InflaterInputStream;

    invoke-direct {v0, p1}, Ljava/util/zip/InflaterInputStream;-><init>(Ljava/io/InputStream;)V

    .line 140
    .local v0, "is":Ljava/util/zip/InflaterInputStream;
    new-instance v1, Ljava/util/zip/InflaterOutputStream;

    invoke-direct {v1, p2}, Ljava/util/zip/InflaterOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 141
    .local v1, "os":Ljava/util/zip/InflaterOutputStream;
    invoke-static {p0, v0, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->exfr([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 142
    invoke-virtual {v1}, Ljava/util/zip/InflaterOutputStream;->close()V

    .line 143
    invoke-virtual {v0}, Ljava/util/zip/InflaterInputStream;->close()V

    .line 144
    return-void
.end method

.method private static decryptBlob([B)[B
    .registers 4
    .param p0, "blob"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 150
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    array-length v1, p0

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 151
    .local v0, "out":Ljava/io/ByteArrayOutputStream;
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->blobKey()[B

    move-result-object v1

    new-instance v2, Ljava/io/ByteArrayInputStream;

    invoke-direct {v2, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {v1, v2, v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 152
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    return-object v1
.end method

.method public static decryptToBytes([B[B)[B
    .registers 4
    .param p0, "key"  # [B
    .param p1, "encrypted"  # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 130
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    array-length v1, p1

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    .line 131
    .local v0, "baos":Ljava/io/ByteArrayOutputStream;
    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {p0, v1, v0}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decrypt([BLjava/io/InputStream;Ljava/io/OutputStream;)V

    .line 134
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    return-object v1
.end method

.method private static exfr([BLjava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 14
    .param p0, "key"  # [B
    .param p1, "in"  # Ljava/io/InputStream;
    .param p2, "out"  # Ljava/io/OutputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 168
    if-eqz p0, :cond_7a

    array-length v0, p0

    const/16 v1, 0x10

    if-lt v0, v1, :cond_7a

    .line 170
    const/4 v0, 0x4

    new-array v2, v0, [I

    .line 171
    .local v2, "iArr":[I
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_b
    if-ge v3, v0, :cond_32

    .line 172
    mul-int/lit8 v4, v3, 0x4

    .line 173
    .local v4, "b":I
    aget-byte v5, p0, v4

    and-int/lit16 v5, v5, 0xff

    add-int/lit8 v6, v4, 0x1

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    or-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x2

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/2addr v6, v1

    or-int/2addr v5, v6

    add-int/lit8 v6, v4, 0x3

    aget-byte v6, p0, v6

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x18

    or-int/2addr v5, v6

    aput v5, v2, v3

    .line 171
    .end local v4  # "b":I
    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    .line 178
    .end local v3  # "i":I
    :cond_32
    const/4 v0, 0x0

    aget v1, v2, v0

    const/4 v3, 0x2

    aget v3, v2, v3

    xor-int/2addr v1, v3

    const/4 v3, 0x1

    aget v3, v2, v3

    const/4 v4, 0x3

    aget v4, v2, v4

    xor-int/2addr v3, v4

    filled-new-array {v1, v3}, [I

    move-result-object v1

    .line 179
    .local v1, "iArr2":[I
    invoke-static {v2}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->FxIjsF([I)[I

    move-result-object v2

    .line 181
    const/16 v3, 0x2000

    new-array v3, v3, [B

    .line 182
    .local v3, "buf":[B
    const/4 v4, 0x0

    .line 184
    .local v4, "pos":I
    :goto_4d
    invoke-virtual {p1, v3}, Ljava/io/InputStream;->read([B)I

    move-result v5

    .line 185
    .local v5, "read":I
    if-gez v5, :cond_54

    return-void

    .line 186
    :cond_54
    add-int v6, v4, v5

    .line 187
    .local v6, "end":I
    const/4 v7, 0x0

    .line 188
    .local v7, "i5":I
    :goto_57
    if-ge v4, v6, :cond_76

    .line 189
    rem-int/lit8 v8, v4, 0x8

    .line 190
    .local v8, "i6":I
    if-nez v8, :cond_60

    invoke-static {v2, v1}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->nDnv([I[I)V

    .line 191
    :cond_60
    div-int/lit8 v9, v8, 0x4

    aget v9, v1, v9

    rem-int/lit8 v10, v4, 0x4

    mul-int/lit8 v10, v10, 0x8

    shr-int/2addr v9, v10

    int-to-byte v9, v9

    aget-byte v10, v3, v7

    xor-int/2addr v9, v10

    int-to-byte v9, v9

    aput-byte v9, v3, v7

    .line 192
    add-int/lit8 v4, v4, 0x1

    .line 193
    nop

    .end local v8  # "i6":I
    add-int/lit8 v7, v7, 0x1

    .line 194
    goto :goto_57

    .line 195
    :cond_76
    invoke-virtual {p2, v3, v0, v5}, Ljava/io/OutputStream;->write([BII)V

    .line 196
    .end local v5  # "read":I
    .end local v6  # "end":I
    .end local v7  # "i5":I
    goto :goto_4d

    .line 168
    .end local v1  # "iArr2":[I
    .end local v2  # "iArr":[I
    .end local v3  # "buf":[B
    .end local v4  # "pos":I
    :cond_7a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "key must be 16 bytes"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static loadPhantomLib(Landroid/content/Context;)V
    .registers 10
    .param p0, "ctx"  # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 91
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "libphantom.so"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 93
    .local v0, "soFile":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-nez v1, :cond_60

    .line 94
    invoke-static {}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->pickBlobName()Ljava/lang/String;

    move-result-object v1

    .line 95
    .local v1, "blobName":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "phantom/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 97
    .local v2, "assetPath":Ljava/lang/String;
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v3

    .line 98
    .local v3, "bis":Ljava/io/InputStream;
    invoke-static {v3}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->readFully(Ljava/io/InputStream;)[B

    move-result-object v4

    .line 99
    .local v4, "blob":[B
    invoke-static {v3}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 101
    invoke-static {v4}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->decryptBlob([B)[B

    move-result-object v5

    .line 103
    .local v5, "soBytes":[B
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v6

    .line 104
    .local v6, "parent":Ljava/io/File;
    if-eqz v6, :cond_4a

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v7

    if-nez v7, :cond_4a

    invoke-virtual {v6}, Ljava/io/File;->mkdirs()Z

    .line 106
    :cond_4a
    new-instance v7, Ljava/io/FileOutputStream;

    invoke-direct {v7, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 108
    .local v7, "fos":Ljava/io/FileOutputStream;
    :try_start_4f
    invoke-virtual {v7, v5}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_52
    .catchall {:try_start_4f .. :try_end_52} :catchall_5b

    .line 110
    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 111
    nop

    .line 114
    const/4 v8, 0x0

    invoke-virtual {v0, v8, v8}, Ljava/io/File;->setWritable(ZZ)Z

    goto :goto_60

    .line 110
    :catchall_5b
    move-exception v8

    invoke-static {v7}, Lcom/ultra/dex2cvmp/utils/DexCrypto;->closeQuiet(Ljava/io/Closeable;)V

    .line 111
    throw v8

    .line 117
    .end local v1  # "blobName":Ljava/lang/String;
    .end local v2  # "assetPath":Ljava/lang/String;
    .end local v3  # "bis":Ljava/io/InputStream;
    .end local v4  # "blob":[B
    .end local v5  # "soBytes":[B
    .end local v6  # "parent":Ljava/io/File;
    .end local v7  # "fos":Ljava/io/FileOutputStream;
    :cond_60
    :goto_60
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/System;->load(Ljava/lang/String;)V

    .line 118
    return-void
.end method

.method private static nDnv([I[I)V
    .registers 8
    .param p0, "iArr"  # [I
    .param p1, "iArr2"  # [I

    .line 213
    const/4 v0, 0x0

    aget v1, p1, v0

    .local v1, "i":I
    const/4 v2, 0x1

    aget v3, p1, v2

    .line 214
    .local v3, "i2":I
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    aget v5, p0, v0

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 215
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    aget v5, p0, v2

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 216
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x2

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 217
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x3

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 218
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x4

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 219
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x5

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 220
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x6

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 221
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/4 v5, 0x7

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 222
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x8

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 223
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x9

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 224
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xa

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 225
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xb

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 226
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xc

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 227
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xd

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 228
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xe

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 229
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0xf

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 230
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x10

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 231
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x11

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 232
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x12

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 233
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x13

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 234
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x14

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 235
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x15

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 236
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x16

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 237
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x17

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 238
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x18

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 239
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x19

    aget v5, p0, v5

    xor-int v3, v4, v5

    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int v1, v4, v3

    .line 240
    ushr-int/lit8 v4, v3, 0x8

    shl-int/lit8 v5, v3, 0x18

    or-int/2addr v4, v5

    add-int/2addr v4, v1

    const/16 v5, 0x1a

    aget v5, p0, v5

    xor-int v3, v4, v5

    .line 241
    shl-int/lit8 v4, v1, 0x3

    ushr-int/lit8 v5, v1, 0x1d

    or-int/2addr v4, v5

    xor-int/2addr v4, v3

    aput v4, p1, v0

    .line 242
    aput v3, p1, v2

    .line 243
    return-void
.end method

.method public static native nativeGetKey([B[B)[B
.end method

.method private static pickBlobName()Ljava/lang/String;
    .registers 5

    .line 157
    nop

    .line 158
    sget-object v0, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    .line 159
    nop

    .line 160
    .local v0, "abis":[Ljava/lang/String;
    array-length v1, v0

    const/4 v2, 0x0

    :goto_6
    if-ge v2, v1, :cond_1a

    aget-object v3, v0, v2

    .line 161
    .local v3, "abi":Ljava/lang/String;
    if-eqz v3, :cond_17

    const-string v4, "arm64"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_17

    const-string v1, "libphantom_arm64.blob"

    return-object v1

    .line 160
    .end local v3  # "abi":Ljava/lang/String;
    :cond_17
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    .line 163
    :cond_1a
    const-string v1, "libphantom_arm.blob"

    return-object v1
.end method

.method static readFully(Ljava/io/InputStream;)[B
    .registers 5
    .param p0, "is"  # Ljava/io/InputStream;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 248
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 249
    .local v0, "out":Ljava/io/ByteArrayOutputStream;
    const/16 v1, 0x2000

    new-array v1, v1, [B

    .line 250
    .local v1, "buf":[B
    :goto_9
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    move v3, v2

    .local v3, "n":I
    if-lez v2, :cond_15

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_9

    .line 251
    :cond_15
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    return-object v2
.end method
