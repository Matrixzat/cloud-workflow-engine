import 'package:flutter/material.dart';

class AppTheme {
  static const Color bg         = Color(0xFF050d1a);
  static const Color surface    = Color(0xFF0a1628);
  static const Color card       = Color(0xFF0d1f38);
  static const Color border     = Color(0xFF1a3050);
  static const Color accent     = Color(0xFF00b4d8);
  static const Color accentGlow = Color(0xFF0077b6);
  static const Color gold       = Color(0xFFffd60a);
  static const Color success    = Color(0xFF22c55e);
  static const Color error      = Color(0xFFef4444);
  static const Color warning    = Color(0xFFf59e0b);
  static const Color textPrim   = Color(0xFFe2e8f0);
  static const Color textSec    = Color(0xFF64748b);
  static const Color running    = Color(0xFF38bdf8);

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: const ColorScheme.dark(
      primary:   accent,
      secondary: gold,
      surface:   surface,
      error:     error,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: textPrim,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.5,
      ),
      iconTheme: IconThemeData(color: textPrim),
    ),
    cardTheme: CardTheme(
      color: card,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: border, width: 1),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: accent, width: 1.5),
      ),
      labelStyle: const TextStyle(color: textSec),
      hintStyle: const TextStyle(color: textSec),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: accent,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
      ),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: accent,
      foregroundColor: Colors.white,
      elevation: 4,
    ),
    dividerTheme: const DividerThemeData(color: border, thickness: 1),
    textTheme: const TextTheme(
      bodyLarge:  TextStyle(color: textPrim, fontSize: 15),
      bodyMedium: TextStyle(color: textPrim, fontSize: 13),
      bodySmall:  TextStyle(color: textSec,  fontSize: 11),
      titleLarge: TextStyle(color: textPrim, fontSize: 20, fontWeight: FontWeight.w800),
      titleMedium:TextStyle(color: textPrim, fontSize: 16, fontWeight: FontWeight.w700),
      labelSmall: TextStyle(color: textSec,  fontSize: 10),
    ),
  );
}
