import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/bg_worker.dart';
import 'services/native_channel.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await NotificationService.init();
  await registerBgTask();

  // Cache the worker URL in SharedPreferences so the background worker
  // (which cannot call platform channels) can read it without the app open.
  _cacheWorkerUrl();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:                    Colors.transparent,
    statusBarIconBrightness:           Brightness.light,
    systemNavigationBarColor:          AppTheme.bg,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  runApp(const CloudBuildEngine());
}

Future<void> _cacheWorkerUrl() async {
  try {
    final url   = await NativeChannel.workerUrl();
    if (url.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('worker_url', url);
  } catch (_) {}
}

class CloudBuildEngine extends StatelessWidget {
  const CloudBuildEngine({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:                    'Cloud Build Engine',
      debugShowCheckedModeBanner: false,
      theme:                    AppTheme.dark,
      home:                     const HomeScreen(),
    );
  }
}
