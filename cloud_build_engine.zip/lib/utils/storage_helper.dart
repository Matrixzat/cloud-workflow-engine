import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/build_job.dart';

class StorageHelper {
  static const _jobsKey  = 'build_jobs';
  static const _ownerKey = 'gh_owner';
  static const _repoKey  = 'gh_repo';
  static const _tokenKey = 'gh_token';

  static const _channel = MethodChannel('com.cloud.build.engine/storage');

  // ── File system helpers ───────────────────────────────────────────────────

  static Future<String> getRootDir() async {
    final path = await _channel.invokeMethod<String>('getRootDir');
    return path ?? '/storage/emulated/0';
  }

  static Future<void> ensureOutputDir(String path) async {
    try {
      await _channel.invokeMethod('ensureOutputDir', {'path': path});
    } catch (_) {
      await Directory(path).create(recursive: true);
    }
  }

  // ── Build job persistence ─────────────────────────────────────────────────

  static Future<List<BuildJob>> loadJobs() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getString(_jobsKey);
    if (raw == null) return [];
    final list  = jsonDecode(raw) as List;
    return list.map((e) => BuildJob.fromJson(e as Map<String, dynamic>)).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  static Future<void> saveJobs(List<BuildJob> jobs) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_jobsKey, jsonEncode(jobs.map((j) => j.toJson()).toList()));
  }

  static Future<void> upsertJob(BuildJob job) async {
    final jobs = await loadJobs();
    final idx  = jobs.indexWhere((j) => j.id == job.id);
    if (idx >= 0) {
      jobs[idx] = job;
    } else {
      jobs.insert(0, job);
    }
    await saveJobs(jobs);
  }

  static Future<void> deleteJob(String id) async {
    final jobs = await loadJobs();
    jobs.removeWhere((j) => j.id == id);
    await saveJobs(jobs);
  }

  static Future<Map<String, String>> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'owner': prefs.getString(_ownerKey) ?? '',
      'repo':  prefs.getString(_repoKey)  ?? '',
      'token': prefs.getString(_tokenKey) ?? '',
    };
  }

  static Future<void> saveSettings({
    required String owner,
    required String repo,
    required String token,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_ownerKey, owner);
    await prefs.setString(_repoKey,  repo);
    await prefs.setString(_tokenKey, token);
  }
}
