import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../services/native_channel.dart';

const String _kDocText = '''
CLOUD BUILD ENGINE — SOURCE CODE GUIDE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOW IT WORKS
─────────────
1. ZIP your project source folder
2. Upload the ZIP in "New Build"
3. The engine auto-detects the project type
4. Gradle properties are auto-patched for CI
5. APK is signed and saved automatically

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FLUTTER APPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Required in ZIP:
  • pubspec.yaml (at root)
  • lib/ folder
  • android/ folder

Auto-patched by engine:
  • android/local.properties
    - sdk.dir cleared (engine sets correct path)
    - flutter.sdk cleared (engine sets correct path)
  • android/gradle.properties
    - org.gradle.parallel=true → false
    - org.gradle.caching=false → true
    - org.gradle.configuration-cache=true → false
    - AIDE/Termux paths removed

Tips:
  • Set the correct Flutter version in New Build
  • No need to touch local.properties — engine handles it
  • Exclude build/ and .dart_tool/ to reduce ZIP size

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REACT NATIVE / HERMES APPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Required in ZIP:
  • package.json (at root)
  • android/ folder
  • src/ or App.js / App.tsx

Auto-patched by engine:
  • android/local.properties (sdk.dir cleared)
  • android/gradle.properties (parallel, caching, AIDE paths)
  • npm install runs automatically

Tips:
  • EXCLUDE node_modules/ — engine installs packages fresh
  • Hermes engine is enabled automatically by React Native
  • Leave build_mode as "release"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NATIVE ANDROID (Java / Kotlin)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Required in ZIP:
  • build.gradle OR build.gradle.kts (at root)
  • settings.gradle OR settings.gradle.kts
  • app/build.gradle OR app/build.gradle.kts
  • gradlew (Gradle wrapper script)
  • gradle/ folder

Auto-patched by engine:
  • gradle.properties:
    - org.gradle.parallel=true → false
    - org.gradle.caching=false → true
    - org.gradle.configuration-cache=true → false
    - org.gradle.java.home removed (AIDE path)
    - android.aapt2FromMavenOverride removed (AIDE path)
    - android.injected.logSender.enable removed

Tips:
  • compileSdk and ndkVersion are read from build.gradle
    and installed automatically via sdkmanager
  • No signing config needed — engine signs the APK

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
UNITY ANDROID EXPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Steps to export from Unity:
  1. File → Build Settings → Select Android
  2. Enable "Export Project" checkbox
  3. Click "Export" (NOT "Build and Run")
  4. Choose an empty output folder
  5. ZIP the exported folder

Required structure in ZIP:
  • launcher/ (Unity main module)
  • unityLibrary/ (Unity runtime)
  • settings.gradle (includes both modules)
  • gradlew

Engine detects Unity automatically via the
unityLibrary/ folder and builds it as native Android.

Auto-patched by engine:
  • Same gradle.properties patches as native Android
  • NDK version read from build.gradle and installed

Tips:
  • Make sure IL2CPP / Mono is set before exporting
  • ARM64 architecture is recommended

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CUSTOM SIGNING KEY (OPTIONAL)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Works for all project types:
  Flutter • React Native / Hermes • Expo
  Native Android (Gradle) • Unity

By default every APK is signed with the CBE
built-in keystore. To sign with YOUR OWN key,
include your keystore inside the ZIP you upload.
The engine detects it automatically — no extra
settings required.

─────────────────────────────────────────────
HOW TO INCLUDE YOUR OWN SIGNING KEY
─────────────────────────────────────────────
Step 1 — Generate a keystore (Termux / PC / Mac):
  keytool -genkey -v \\
    -keystore release.keystore \\
    -alias my_key \\
    -keyalg RSA -keysize 2048 \\
    -validity 10000

Step 2 — Create key.properties in your project:

  For Flutter / React Native / Hermes / Expo:
    Place at:  android/key.properties

  For Native Android / Unity (Gradle export):
    Place at:  key.properties
               (same folder as gradlew)

  File contents:
    storePassword=your_store_password
    keyPassword=your_key_password
    keyAlias=my_key
    storeFile=release.keystore

  (storeFile path is relative to the folder
  that contains key.properties)

Step 3 — Place your keystore file next to
  key.properties (or at the path you set
  in storeFile above).

Step 4 — ZIP your project as normal and upload.
  The engine scans the ZIP, finds your
  key.properties + keystore, and signs the
  APK with YOUR key. Nothing else to do.

Note: Do NOT add key.properties to .gitignore
  if you want it inside the ZIP.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CPU ARCHITECTURE (ABI) — 64-bit vs 32-bit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CBE DEFAULT: arm64-v8a (64-bit only)

WHAT EACH ABI MEANS
  arm64-v8a   = 64-bit  | All phones after 2015.
                          Best performance. Smaller APK.
  armeabi-v7a = 32-bit  | Very old / budget phones.
                          Needed for Android 4.x – 5.x.
  Both        = Universal | Widest compat. Larger APK.

─────────────────────────────────────
NATIVE ANDROID & UNITY (app/build.gradle)
─────────────────────────────────────
Inside android { defaultConfig { ... } }:

  // 64-bit ONLY (default — recommended)
  ndk { abiFilters "arm64-v8a" }

  // 32-bit ONLY (old/budget devices)
  ndk { abiFilters "armeabi-v7a" }

  // BOTH 64-bit + 32-bit
  ndk { abiFilters "arm64-v8a", "armeabi-v7a" }

To generate SEPARATE APKs per arch, add inside
android { ... }:

  splits {
      abi {
          enable true
          reset()
          include "arm64-v8a", "armeabi-v7a"
          universalApk false
      }
  }

─────────────────────────────────────
FLUTTER (android/app/build.gradle or workflow)
─────────────────────────────────────
In android/app/build.gradle defaultConfig:

  ndk { abiFilters "arm64-v8a" }           // 64-bit only
  ndk { abiFilters "armeabi-v7a" }         // 32-bit only
  ndk { abiFilters "arm64-v8a",            // Both
        "armeabi-v7a" }

Or via flutter build command in build.yml:

  # 64-bit only (engine default)
  flutter build apk --target-platform android-arm64

  # 32-bit only
  flutter build apk --target-platform android-arm

  # BOTH (split APKs — one per arch)
  flutter build apk \\
    --target-platform android-arm,android-arm64 \\
    --split-per-abi

  # Universal fat APK (all archs in one file)
  flutter build apk

─────────────────────────────────────
REACT NATIVE / HERMES (gradle.properties)
─────────────────────────────────────
In android/gradle.properties:

  # 64-bit ONLY (engine default)
  reactNativeArchitectures=arm64-v8a

  # 32-bit ONLY
  reactNativeArchitectures=armeabi-v7a

  # BOTH
  reactNativeArchitectures=arm64-v8a,armeabi-v7a

Or pass directly in build.yml gradlew step:

  ./gradlew assembleRelease \\
    -PreactNativeArchitectures=arm64-v8a

  ./gradlew assembleRelease \\
    -PreactNativeArchitectures=arm64-v8a,armeabi-v7a

─────────────────────────────────────
UNITY — Before Exporting
─────────────────────────────────────
Edit → Project Settings → Player → Android →
Other Settings → Target Architectures:

  [x] ARM64    64-bit (required for Google Play 2021+)
  [x] ARMv7    32-bit (older/budget devices)

Check both for widest device support.
Then export the Gradle project as described above.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PACKAGE NAME & ICON DETECTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
The engine scans your ZIP and picks the package name
automatically using this priority order:

  1.  app/build.gradle (Groovy)
        applicationId "com.example.app"

  2.  app/build.gradle.kts (Kotlin DSL)
        applicationId = "com.example.app"

  3.  app/build.gradle.kts (namespace fallback)
        namespace = "com.example.app"

  4.  Root build.gradle / build.gradle.kts
        (same fields, lower priority than app/ subfolder)

  5.  AndroidManifest.xml (pre-AGP 7 style)
        package="com.example.app"

  6.  app.json (Expo)
        expo.android.package  or  android.package

  7.  app.config.js / app.config.ts
        android: { package: "com.example.app" }

  8.  pubspec.yaml (Flutter — name field only)
        name: my_app  →  com.app.myapp

  9.  package.json (React Native — name field only)
        "name": "my-app"  →  com.app.myapp

  10. ZIP filename (last resort)
        MyApp.zip  →  com.app.myapp

  11. Absolute fallback (nothing found anywhere)
        com.app.project

WHERE TO SET THE PACKAGE NAME IN YOUR SOURCE:

  Flutter:
    android/app/build.gradle
    defaultConfig { applicationId "com.yourcompany.yourapp" }

  React Native:
    android/app/build.gradle  (same as above)
    OR app.json → { "expo": { "android": { "package": "..." } } }

  Native Android (Groovy):
    android/app/build.gradle
    defaultConfig { applicationId "com.yourcompany.yourapp" }

  Native Android (Kotlin DSL):
    android/app/build.gradle.kts
    defaultConfig { applicationId = "com.yourcompany.yourapp" }
    OR: android { namespace = "com.yourcompany.yourapp" }

  Unity:
    launcher/app/build.gradle (same format as Native Android)
    defaultConfig { applicationId "com.yourcompany.yourapp" }

ICON DETECTION — PRIORITY ORDER:

  1. mipmap-xxxhdpi/ic_launcher.png   (PNG, high → low density)
  2. mipmap-xxxhdpi/ic_launcher.webp  (WebP, same order)
  3. Drawable named in android:icon attribute of AndroidManifest.xml
  4. ic_launcher_foreground.png / .webp  (adaptive icon foreground)
  5. assets/images/icon.png or assets/icon.png  (Expo / React Native)
  6. Any PNG/WebP inside any mipmap/ or drawable/ folder
  7. Default dot  →  a missing icon NEVER blocks a build

WHERE TO SET THE ICON IN YOUR SOURCE:

  Flutter / Native Android / Unity:
    android/app/src/main/res/mipmap-hdpi/ic_launcher.png
    android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
    android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
    android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png

  Expo / React Native:
    assets/images/icon.png  or  assets/icon.png
    (Expo also reads the "icon" field in app.json)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ZIP CHECKLIST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INCLUDE:
  [+] pubspec.yaml / package.json / build.gradle
  [+] lib/ or src/ or app/src/
  [+] android/ folder (Flutter / RN)
  [+] assets/ and res/ folders
  [+] gradlew + gradle/ wrapper
  [+] settings.gradle / pubspec.lock

EXCLUDE (saves upload time):
  [-] node_modules/
  [-] build/ folder
  [-] .dart_tool/
  [-] .gradle/
  [-] __pycache__/
  [-] .git/
''';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final Set<String> _expanded = {};

  void _showSnack(String msg, {required Color color, required IconData icon}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.92),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  void _copyDoc() {
    Clipboard.setData(const ClipboardData(text: _kDocText));
    _showSnack('Documentation copied to clipboard', color: AppTheme.success, icon: Icons.copy_rounded);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Settings'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppTheme.border),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildKeystoreInfo(),
          const SizedBox(height: 24),
          _buildDocumentationSection(),
          const SizedBox(height: 24),
          _buildContactSection(),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ── Keystore info ──────────────────────────────────────────────────────────

  Widget _buildKeystoreInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(title: 'APK Signing', icon: Icons.lock_rounded),
        const SizedBox(height: 12),
        _buildHintCard(
          'Default: every APK is signed with the CBE embedded keystore — no setup needed.\n\n'
          '• Alias:   cbe_release_key\n'
          '• Valid:   2026 → 2053 (27 years)\n'
          '• Owner:  Cloud Build Engine / Matrix\n\n'
          'To sign with YOUR OWN key, include your keystore + key.properties inside the ZIP you upload. The engine detects and uses it automatically.',
          icon: Icons.verified_rounded,
          color: AppTheme.gold,
        ),
      ],
    );
  }

  // ── Documentation section ──────────────────────────────────────────────────

  Widget _buildDocumentationSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Icon(Icons.menu_book_rounded, color: AppTheme.accent, size: 18),
          const SizedBox(width: 8),
          const Expanded(
            child: Text('Build Documentation',
              style: TextStyle(color: AppTheme.accent, fontSize: 13,
                  fontWeight: FontWeight.w700, letterSpacing: 0.5)),
          ),
          GestureDetector(
            onTap: _copyDoc,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.accent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.accent.withOpacity(0.35)),
              ),
              child: const Row(children: [
                Icon(Icons.copy_rounded, color: AppTheme.accent, size: 14),
                SizedBox(width: 5),
                Text('Copy All', style: TextStyle(color: AppTheme.accent, fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            ),
          ),
        ]),
        const SizedBox(height: 12),

        _buildHintCard(
          'ZIP your project and upload it — the engine auto-detects Flutter, React Native / Hermes, '
          'Native Android (Java/Kotlin), and Unity exports. Gradle settings are patched automatically.',
          icon: Icons.info_outline_rounded,
        ),
        const SizedBox(height: 10),

        _docCard(
          id: 'flutter',
          icon: Icons.flutter_dash_rounded,
          title: 'Flutter',
          color: const Color(0xFF54C5F8),
          required: 'pubspec.yaml • lib/ • android/',
          content: _buildDocContent([
            _DocSection('Required in ZIP', [
              'pubspec.yaml at root',
              'lib/ folder',
              'android/ folder',
              'assets/ (if you use assets)',
            ]),
            _DocSection('Auto-patched by engine', [
              'android/local.properties — sdk.dir & flutter.sdk cleared',
              'android/gradle.properties — parallel, caching, AIDE paths fixed',
            ]),
            _DocSection('Tips', [
              'Set Flutter version in the New Build screen',
              'Exclude build/ and .dart_tool/ to reduce ZIP size',
              'Leave local.properties — engine rewrites it correctly',
            ]),
          ]),
        ),

        _docCard(
          id: 'rn',
          icon: Icons.javascript_rounded,
          title: 'React Native / Hermes',
          color: const Color(0xFF61DAFB),
          required: 'package.json • android/ • src/',
          content: _buildDocContent([
            _DocSection('Required in ZIP', [
              'package.json at root',
              'android/ folder',
              'src/ or App.js / App.tsx',
              'index.js',
            ]),
            _DocSection('Auto-patched by engine', [
              'android/local.properties — sdk.dir cleared',
              'android/gradle.properties — parallel, caching, AIDE paths fixed',
              'npm install runs automatically on the runner',
            ]),
            _DocSection('Tips', [
              'EXCLUDE node_modules/ — engine installs packages fresh',
              'Hermes JS engine is enabled by React Native automatically',
              'Expo projects: include app.json, engine runs expo prebuild',
            ]),
          ]),
        ),

        _docCard(
          id: 'android',
          icon: Icons.android_rounded,
          title: 'Native Android (Java / Kotlin)',
          color: const Color(0xFF3DDC84),
          required: 'build.gradle • gradlew • app/src/',
          content: _buildDocContent([
            _DocSection('Required in ZIP', [
              'build.gradle OR build.gradle.kts at root',
              'settings.gradle OR settings.gradle.kts',
              'app/build.gradle OR app/build.gradle.kts',
              'gradlew script + gradle/ wrapper folder',
              'app/src/main/ (Java/Kotlin source)',
            ]),
            _DocSection('Auto-patched by engine', [
              'gradle.properties — parallel=false, caching=true',
              'gradle.properties — configuration-cache=false',
              'gradle.properties — AIDE java.home & aapt2 paths removed',
              'local.properties — sdk.dir cleared and reset',
              'compileSdk & ndkVersion read and installed automatically',
            ]),
            _DocSection('Tips', [
              'No signing config needed — engine signs the APK',
              'compileSdk 33 / 34 / 35 all supported',
              'Kotlin DSL (.kts) build files are fully supported',
            ]),
          ]),
        ),

        _docCard(
          id: 'unity',
          icon: Icons.gamepad_rounded,
          title: 'Unity Android Export',
          color: const Color(0xFFFFFFFF),
          required: 'launcher/ • unityLibrary/ • settings.gradle',
          content: _buildDocContent([
            _DocSection('Export steps in Unity', [
              'File → Build Settings → Select Android',
              'Enable "Export Project" checkbox',
              'Click "Export" (NOT "Build and Run")',
              'Choose an empty output folder',
              'ZIP the exported folder',
            ]),
            _DocSection('Required in ZIP', [
              'launcher/ (Unity main module)',
              'unityLibrary/ (Unity runtime)',
              'settings.gradle (includes both modules)',
              'gradlew + gradle/ wrapper',
            ]),
            _DocSection('Auto-patched by engine', [
              'Same gradle.properties patches as native Android',
              'NDK version read from build.gradle and installed',
            ]),
            _DocSection('Tips', [
              'Make sure IL2CPP / Mono is set before exporting',
              'ARM64 architecture is recommended',
            ]),
          ]),
        ),

        _docCard(
          id: 'abi',
          icon: Icons.memory_rounded,
          title: 'CPU Architecture (ABI)',
          color: const Color(0xFFFFB300),
          required: '64-bit vs 32-bit • arm64-v8a vs armeabi-v7a',
          content: _buildDocContent([
            _DocSection('ABI reference', [
              'arm64-v8a   = 64-bit — all phones after 2015, best performance',
              'armeabi-v7a = 32-bit — very old / budget phones',
              'Both        = universal APK, widest compatibility',
            ]),
            _DocSection('Flutter (build command in build.yml)', [
              'flutter build apk --target-platform android-arm64   // 64-bit only',
              'flutter build apk --target-platform android-arm     // 32-bit only',
              'flutter build apk --target-platform android-arm,android-arm64 --split-per-abi',
            ], isCode: true),
            _DocSection('Native Android / Unity (app/build.gradle)', [
              'ndk { abiFilters "arm64-v8a" }          // 64-bit only',
              'ndk { abiFilters "armeabi-v7a" }        // 32-bit only',
              'ndk { abiFilters "arm64-v8a", "armeabi-v7a" }   // both',
            ], isCode: true),
            _DocSection('React Native (gradle.properties)', [
              'reactNativeArchitectures=arm64-v8a',
              'reactNativeArchitectures=armeabi-v7a',
              'reactNativeArchitectures=arm64-v8a,armeabi-v7a',
            ], isCode: true),
          ]),
        ),

        _docCard(
          id: 'detection',
          icon: Icons.manage_search_rounded,
          title: 'Package Name & Icon Detection',
          color: const Color(0xFFCE93D8),
          required: 'How the engine reads your app identity from the ZIP',
          content: _buildDocContent([
            _DocSection('Package name — detection order', [
              '1. app/build.gradle (Groovy)  →  applicationId "com.example.app"',
              '2. app/build.gradle.kts (Kotlin DSL)  →  applicationId = "com.example.app"',
              '3. app/build.gradle.kts namespace  →  namespace = "com.example.app"',
              '4. Root build.gradle / build.gradle.kts (same fields, lower priority)',
              '5. AndroidManifest.xml  →  package="com.example.app"  (pre-AGP 7)',
              '6. app.json (Expo)  →  expo.android.package  or  android.package',
              '7. app.config.js / app.config.ts  →  android: { package: "..." }',
              '8. pubspec.yaml (Flutter)  →  name: my_app  →  com.app.myapp',
              '9. package.json (React Native)  →  "name"  →  com.app.myapp',
              '10. ZIP filename  →  MyApp.zip  →  com.app.myapp',
              '11. Final fallback (nothing found anywhere)  →  com.app.project',
            ], isCode: true),
            _DocSection('Where to set it — Flutter', [
              'File: android/app/build.gradle',
              'defaultConfig { applicationId "com.yourcompany.yourapp" }',
              'This is the canonical source — engine always checks this first.',
            ], isCode: true),
            _DocSection('Where to set it — React Native', [
              'File: android/app/build.gradle',
              'defaultConfig { applicationId "com.yourcompany.yourapp" }',
              'OR app.json: { "expo": { "android": { "package": "com.yourcompany.yourapp" } } }',
            ], isCode: true),
            _DocSection('Where to set it — Native Android (Java / Kotlin)', [
              'Groovy: android/app/build.gradle',
              'defaultConfig { applicationId "com.yourcompany.yourapp" }',
              '',
              'Kotlin DSL: android/app/build.gradle.kts',
              'defaultConfig { applicationId = "com.yourcompany.yourapp" }',
              'OR: android { namespace = "com.yourcompany.yourapp" }',
            ], isCode: true),
            _DocSection('Where to set it — Unity', [
              'Same as Native Android: app/build.gradle inside the launcher/ module.',
              'defaultConfig { applicationId "com.yourcompany.yourapp" }',
            ], isCode: true),
            _DocSection('Icon detection — priority order', [
              '1. mipmap-xxxhdpi/ic_launcher.png  (xxxhdpi → xxhdpi → xhdpi → hdpi)',
              '2. mipmap-xxxhdpi/ic_launcher.webp  (same density order)',
              '3. Drawable named in android:icon of AndroidManifest.xml',
              '4. ic_launcher_foreground.png / .webp  (adaptive icon foreground)',
              '5. assets/images/icon.png or assets/icon.png  (Expo / React Native)',
              '6. Any PNG/WebP in a mipmap/ or drawable/ folder',
              '7. Default dot — icon never blocks a build',
            ]),
            _DocSection('Where to set icon — Flutter / Native Android / Unity', [
              'Place ic_launcher.png in each mipmap-* folder:',
              '  android/app/src/main/res/mipmap-hdpi/ic_launcher.png',
              '  android/app/src/main/res/mipmap-xhdpi/ic_launcher.png',
              '  android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png',
              '  android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png',
            ], isCode: true),
            _DocSection('Where to set icon — Expo / React Native', [
              'Place icon at: assets/images/icon.png  or  assets/icon.png',
              'Expo also reads the "icon" field in app.json automatically.',
            ], isCode: true),
          ]),
        ),

        _docCard(
          id: 'zip',
          icon: Icons.folder_zip_rounded,
          title: 'ZIP Checklist',
          color: const Color(0xFFFF7043),
          required: 'What to include / exclude in your ZIP',
          content: _buildDocContent([
            _DocSection('INCLUDE', [
              'pubspec.yaml / package.json / build.gradle',
              'lib/ or src/ or app/src/',
              'android/ folder (Flutter / RN)',
              'assets/ and res/ folders',
              'gradlew + gradle/ wrapper',
              'settings.gradle / pubspec.lock',
            ]),
            _DocSection('EXCLUDE (saves upload time)', [
              'node_modules/',
              'build/ folder',
              '.dart_tool/',
              '.gradle/',
              '__pycache__/',
              '.git/',
            ]),
          ]),
        ),

        _docCard(
          id: 'signing',
          icon: Icons.security_rounded,
          title: 'Custom Signing Key',
          color: const Color(0xFFFFD700),
          required: 'Sign APKs with your own key — include it in your ZIP',
          content: _buildDocContent([
            _DocSection('How it works', [
              'Works for: Flutter • React Native / Hermes • Expo •',
              'Native Android (Gradle) • Unity',
              '',
              'Include your keystore + key.properties in your project ZIP.',
              'The engine finds them automatically and signs with your key.',
              'Nothing found? Falls back to CBE default — nothing breaks.',
            ]),
            _DocSection('Step 1 — Generate keystore (Termux / PC / Mac)', [
              'keytool -genkey -v \\',
              '  -keystore release.keystore \\',
              '  -alias my_key \\',
              '  -keyalg RSA -keysize 2048 \\',
              '  -validity 10000',
            ], isCode: true),
            _DocSection('Step 2 — Create key.properties', [
              'Flutter / React Native / Hermes / Expo:',
              '  Place at: android/key.properties',
              '',
              'Native Android / Unity:',
              '  Place at: key.properties  (next to gradlew)',
              '',
              'storePassword=your_store_password',
              'keyPassword=your_key_password',
              'keyAlias=my_key',
              'storeFile=release.keystore',
            ], isCode: true),
            _DocSection('Step 3 — Place keystore file', [
              'Put release.keystore in the same folder as',
              'key.properties (or at the storeFile path above).',
            ]),
            _DocSection('Step 4 — ZIP and upload', [
              'ZIP your project as normal and upload.',
              'The engine scans, finds your key, and signs the APK.',
              'Build summary shows: project-zip (your_alias)',
            ]),
          ]),
        ),
      ],
    );
  }

  // ── Doc card helper ────────────────────────────────────────────────────────

  Widget _docCard({
    required String id,
    required IconData icon,
    required String title,
    required Color color,
    required String required,
    required Widget content,
  }) {
    final open = _expanded.contains(id);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(children: [
        InkWell(
          onTap: () => setState(() => open ? _expanded.remove(id) : _expanded.add(id)),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 10),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: AppTheme.textPrim, fontWeight: FontWeight.w700, fontSize: 13)),
                  const SizedBox(height: 2),
                  Text(required, style: const TextStyle(color: AppTheme.textSec, fontSize: 11)),
                ],
              )),
              Icon(open ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                  color: AppTheme.textSec, size: 20),
            ]),
          ),
        ),
        if (open) ...[
          Container(height: 1, color: AppTheme.border),
          Padding(padding: const EdgeInsets.all(14), child: content),
        ],
      ]),
    );
  }

  Widget _buildDocContent(List<_DocSection> sections) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: sections.map((sec) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(sec.title, style: const TextStyle(
                color: AppTheme.accent, fontSize: 11,
                fontWeight: FontWeight.w700, letterSpacing: 0.4)),
            const SizedBox(height: 6),
            ...sec.items.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(sec.isCode ? '  ' : '• ',
                    style: TextStyle(color: AppTheme.accent, fontSize: 12,
                        fontFamily: sec.isCode ? 'monospace' : null)),
                Expanded(child: Text(item,
                    style: TextStyle(
                        color: AppTheme.textSec, fontSize: 12, height: 1.5,
                        fontFamily: sec.isCode ? 'monospace' : null))),
              ]),
            )),
          ],
        ),
      )).toList(),
    );
  }

  // ── Developer section ──────────────────────────────────────────────────────

  Widget _buildContactSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(title: 'Developer', icon: Icons.terminal_rounded),
        const SizedBox(height: 14),
        _MatrixXButton(
          onTap: () async {
            try {
              final raw = await NativeChannel.telegramUrl();
              final uri = Uri.parse(raw);
              await launchUrl(uri, mode: LaunchMode.externalApplication);
            } catch (_) {
              _showSnack('Could not open Telegram',
                  color: AppTheme.error, icon: Icons.error_rounded);
            }
          },
        ),
      ],
    );
  }

  // ── Shared helpers ─────────────────────────────────────────────────────────

  Widget _buildHintCard(String text, {required IconData icon, Color? color}) {
    final c = color ?? AppTheme.accent;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: c.withOpacity(0.07),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.withOpacity(0.25)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: c, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(text,
            style: TextStyle(color: AppTheme.textSec, fontSize: 12, height: 1.6))),
      ]),
    );
  }
}

// ── Data models ────────────────────────────────────────────────────────────

class _DocSection {
  final String       title;
  final List<String> items;
  final bool         isCode;
  const _DocSection(this.title, this.items, {this.isCode = false});
}

// ── Section header ─────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionHeader({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Icon(icon, color: AppTheme.accent, size: 18),
      const SizedBox(width: 8),
      Text(title, style: const TextStyle(
          color: AppTheme.accent, fontSize: 13,
          fontWeight: FontWeight.w700, letterSpacing: 0.5)),
    ],
  );
}

// ── MATRIX-X-SCRAPER developer button ─────────────────────────────────────

class _MatrixXButton extends StatefulWidget {
  final VoidCallback onTap;
  const _MatrixXButton({required this.onTap});

  @override
  State<_MatrixXButton> createState() => _MatrixXButtonState();
}

class _MatrixXButtonState extends State<_MatrixXButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>    _glow;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glow,
      builder: (context, _) {
        final gv = _glow.value;
        return GestureDetector(
          onTapDown:  (_) => setState(() => _pressed = true),
          onTapUp:    (_) { setState(() => _pressed = false); widget.onTap(); },
          onTapCancel: ()  => setState(() => _pressed = false),
          child: AnimatedScale(
            scale: _pressed ? 0.96 : 1.0,
            duration: const Duration(milliseconds: 120),
            curve: Curves.easeOut,
            child: Container(
              height: 64,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: LinearGradient(
                  colors: [
                    Color.lerp(const Color(0xFF006aaa), const Color(0xFF0099dd), gv)!,
                    Color.lerp(const Color(0xFF0077bb), const Color(0xFF00bbff), gv)!,
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color.lerp(
                      const Color(0xFF0088cc).withOpacity(0.30),
                      const Color(0xFF0088cc).withOpacity(0.55),
                      gv)!,
                    blurRadius: 20 + gv * 10,
                    offset: const Offset(0, 5),
                    spreadRadius: 0,
                  ),
                ],
                border: Border.all(
                  color: Color.lerp(
                    Colors.white.withOpacity(0.08),
                    Colors.white.withOpacity(0.22),
                    gv)!,
                  width: 1,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    // ── Left Telegram icon ───────────────────────────────
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.15),
                      ),
                      child: const Center(child: _TelegramIcon()),
                    ),
                    // ── Label ────────────────────────────────────────────
                    const Expanded(
                      child: Text(
                        'MATRIX-X-SCRAPER',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.2,
                          shadows: [
                            Shadow(
                              color: Color(0x66ffffff),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    ),
                    // ── Right Telegram icon (mirror) ─────────────────────
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.15),
                      ),
                      child: const Center(child: _TelegramIcon()),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ── Telegram icon ──────────────────────────────────────────────────────────

class _TelegramIcon extends StatelessWidget {
  const _TelegramIcon();

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: const Size(24, 24), painter: _TelegramPainter());
}

class _TelegramPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final paint = Paint()..color = Colors.white..style = PaintingStyle.fill;

    final body = Path()
      ..moveTo(w * 0.05, h * 0.45)
      ..lineTo(w * 0.95, h * 0.22)
      ..lineTo(w * 0.60, h * 0.78)
      ..lineTo(w * 0.42, h * 0.62)
      ..close();
    canvas.drawPath(body, paint);

    final wing = Path()
      ..moveTo(w * 0.42, h * 0.62)
      ..lineTo(w * 0.60, h * 0.78)
      ..lineTo(w * 0.55, h * 0.92)
      ..lineTo(w * 0.38, h * 0.74)
      ..close();
    canvas.drawPath(wing, paint..color = Colors.white70);

    final line = Paint()
      ..color = const Color(0xFF0088cc)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(w * 0.42, h * 0.62), Offset(w * 0.95, h * 0.22), line);
  }

  @override
  bool shouldRepaint(_) => false;
}
