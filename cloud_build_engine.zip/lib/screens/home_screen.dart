import 'dart:async';
import 'package:flutter/material.dart';
import '../models/build_job.dart';
import '../services/notification_service.dart';
import '../services/worker_service.dart';
import '../theme/app_theme.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/icon_cache.dart';
import '../widgets/build_card.dart';
import 'build_detail_screen.dart';
import 'new_build_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  List<BuildJob> _jobs    = [];
  Timer?         _pollTimer;
  bool           _loading = true;

  late AnimationController _headerCtrl;
  late Animation<double>   _headerAnim;

  late AnimationController _fabCtrl;
  late Animation<double>   _fabEnter;
  late Animation<double>   _fabPulse;

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat(reverse: true);
    _headerAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _headerCtrl, curve: Curves.easeInOut));

    _fabCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _fabEnter = CurvedAnimation(parent: _fabCtrl, curve: Curves.elasticOut);
    _fabPulse = Tween<double>(begin: 1.0, end: 1.04).animate(
        CurvedAnimation(parent: _headerCtrl, curve: Curves.easeInOut));
    _fabCtrl.forward();

    _load();
    _pollTimer = Timer.periodic(const Duration(seconds: 15), (_) => _pollRunning());
    // Ask for MANAGE_EXTERNAL_STORAGE on first launch if not yet granted
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) PermissionHelper.checkStartup(context);
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _headerCtrl.dispose();
    _fabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    _jobs = await StorageHelper.loadJobs();
    if (mounted) setState(() => _loading = false);
    _pollRunning();

    // ── Persistence: reopen active build after app restart ─────────────────
    final running = _jobs.where((j) => j.isRunning).toList();
    if (running.isNotEmpty && mounted) {
      await Future.delayed(const Duration(milliseconds: 400));
      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BuildDetailScreen(job: running.first),
        ),
      );
      _jobs = await StorageHelper.loadJobs();
      if (mounted) setState(() {});
    }
  }

  Future<void> _pollRunning() async {
    final running = _jobs.where((j) => j.isRunning).toList();
    if (running.isEmpty) return;

    for (final job in running) {
      try {
        final run = await WorkerService.getStatus(job.runId);
        if (run == null) continue;

        final prevRunning = job.isRunning;
        job.status     = run['status']     as String? ?? job.status;
        job.conclusion = run['conclusion'] as String?;
        job.updatedAt  = DateTime.now();

        await StorageHelper.upsertJob(job);

        if (prevRunning && !job.isRunning) {
          final notifId = job.runId % 100000;
          if (job.isSuccess) {
            await NotificationService.showSuccess(job.appName, notifId);
          } else if (job.conclusion == 'cancelled') {
            await NotificationService.showCancelled(job.appName, notifId);
          } else {
            await NotificationService.showFailed(
                job.appName, job.conclusion ?? 'unknown', notifId);
          }
        }
      } catch (_) {}
    }
    if (mounted) setState(() {});
  }

  Future<void> _openNewBuild() async {
    final result = await Navigator.push<BuildJob>(
      context, MaterialPageRoute(builder: (_) => const NewBuildScreen()));
    if (result != null) {
      _jobs.insert(0, result);
      await StorageHelper.upsertJob(result);
      if (mounted) setState(() {});
    }
  }

  // ── Bulk delete ───────────────────────────────────────────────────────────

  Future<void> _deleteFailed() async {
    final failed = _jobs.where((j) => j.isFailed).toList();
    if (failed.isEmpty) {
      _showSnack('No failed builds to delete', icon: Icons.info_outline, color: AppTheme.textSec);
      return;
    }
    final confirm = await _confirmBulkDelete(
        'Delete ${failed.length} failed build${failed.length == 1 ? '' : 's'}?');
    if (!confirm) return;
    for (final j in failed) { await StorageHelper.deleteJob(j.id); IconCache.remove(j.id); }
    _jobs.removeWhere((j) => j.isFailed);
    if (mounted) setState(() {});
    _showSnack('${failed.length} failed build${failed.length == 1 ? '' : 's'} deleted',
        icon: Icons.delete_rounded, color: AppTheme.error);
  }

  Future<void> _deleteCompleted() async {
    final done = _jobs.where((j) => !j.isRunning).toList();
    if (done.isEmpty) {
      _showSnack('No finished builds to delete', icon: Icons.info_outline, color: AppTheme.textSec);
      return;
    }
    final confirm = await _confirmBulkDelete(
        'Delete all ${done.length} finished build${done.length == 1 ? '' : 's'}?');
    if (!confirm) return;
    for (final j in done) { await StorageHelper.deleteJob(j.id); IconCache.remove(j.id); }
    _jobs.removeWhere((j) => !j.isRunning);
    if (mounted) setState(() {});
    _showSnack('${done.length} build${done.length == 1 ? '' : 's'} deleted',
        icon: Icons.delete_rounded, color: AppTheme.textSec);
  }

  Future<void> _deleteAll() async {
    if (_jobs.isEmpty) return;
    final running = _jobs.where((j) => j.isRunning).length;
    final msg = running > 0
        ? 'Delete all builds? ($running running build${running == 1 ? '' : 's'} will remain)'
        : 'Delete all ${_jobs.length} builds?';
    final confirm = await _confirmBulkDelete(msg);
    if (!confirm) return;
    final toDelete = _jobs.where((j) => !j.isRunning).toList();
    for (final j in toDelete) { await StorageHelper.deleteJob(j.id); IconCache.remove(j.id); }
    _jobs.removeWhere((j) => !j.isRunning);
    if (mounted) setState(() {});
    _showSnack('All finished builds deleted',
        icon: Icons.delete_sweep_rounded, color: AppTheme.textSec);
  }

  Future<bool> _confirmBulkDelete(String message) async {
    return await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Confirm Delete',
            style: TextStyle(color: AppTheme.textPrim, fontWeight: FontWeight.w700)),
        content: Text(message, style: const TextStyle(color: AppTheme.textSec)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: AppTheme.textSec)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete',
                style: TextStyle(color: AppTheme.error, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    ) ?? false;
  }

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.92),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          _buildAppBar(),
          SliverToBoxAdapter(child: _buildStats()),
          if (_loading)
            const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator(color: AppTheme.accent)))
          else if (_jobs.isEmpty)
            SliverFillRemaining(child: _buildEmpty())
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) => BuildCard(
                    job: _jobs[i],
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(
                        builder: (_) => BuildDetailScreen(job: _jobs[i]),
                      ));
                      _jobs = await StorageHelper.loadJobs();
                      if (mounted) setState(() {});
                    },
                    onDelete: () async {
                      IconCache.remove(_jobs[i].id);
                      await StorageHelper.deleteJob(_jobs[i].id);
                      if (mounted) setState(() => _jobs.removeAt(i));
                    },
                  ),
                  childCount: _jobs.length,
                ),
              ),
            ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: _buildNewBuildFab(),
    );
  }

  // ── Centered animated New Build FAB ────────────────────────────────────────

  Widget _buildNewBuildFab() {
    return AnimatedBuilder(
      animation: Listenable.merge([_fabEnter, _fabPulse]),
      builder: (context, _) {
        return Transform.scale(
          scale: _fabEnter.value * _fabPulse.value,
          child: Container(
              height: 56,
              constraints: const BoxConstraints(minWidth: 220, maxWidth: 280),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: LinearGradient(
                  colors: [
                    AppTheme.accent.withOpacity(0.92),
                    AppTheme.accentGlow.withOpacity(0.80),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.accent.withOpacity(
                        0.32 + (_fabPulse.value - 1.0) * 2.0),
                    blurRadius: 22,
                    offset: const Offset(0, 6),
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: _openNewBuild,
                  borderRadius: BorderRadius.circular(28),
                  splashColor: Colors.white.withOpacity(0.15),
                  highlightColor: Colors.white.withOpacity(0.08),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // ── Left + ────────────────────────────────────────
                        Container(
                          width: 30, height: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.18),
                          ),
                          child: const Icon(Icons.add_rounded,
                              color: Colors.white, size: 18),
                        ),
                        // ── Label ─────────────────────────────────────────
                        const Expanded(
                          child: Text(
                            'NEW BUILD',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.4,
                            ),
                          ),
                        ),
                        // ── Right + (mirror) ──────────────────────────────
                        Container(
                          width: 30, height: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.18),
                          ),
                          child: const Icon(Icons.add_rounded,
                              color: Colors.white, size: 18),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        );
      },
    );
  }

  Widget _buildHeaderIcon() {
    return Container(
      width: 48, height: 48,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.accentGlow,
            Color.lerp(AppTheme.accentGlow, AppTheme.gold, _headerAnim.value)!,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(color: AppTheme.accent.withOpacity(0.35), blurRadius: 16),
        ],
      ),
      child: const Icon(Icons.cloud_upload_rounded, color: Colors.white, size: 26),
    );
  }

  Widget _buildAppBar() {
    final hasFailed   = _jobs.any((j) => j.isFailed);
    final hasFinished = _jobs.any((j) => !j.isRunning);

    return SliverAppBar(
      expandedHeight: 140,
      pinned: true,
      backgroundColor: AppTheme.bg,
      surfaceTintColor: Colors.transparent,
      actions: [
        // ── Bulk delete menu ───────────────────────────────────────────────
        if (hasFinished)
          PopupMenuButton<String>(
            icon: const Icon(Icons.delete_sweep_rounded, color: AppTheme.textSec),
            color: AppTheme.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (v) {
              if (v == 'failed')    _deleteFailed();
              if (v == 'finished')  _deleteCompleted();
              if (v == 'all')       _deleteAll();
            },
            itemBuilder: (_) => [
              if (hasFailed)
                const PopupMenuItem(
                  value: 'failed',
                  child: Row(children: [
                    Icon(Icons.error_outline_rounded, color: AppTheme.error, size: 18),
                    SizedBox(width: 10),
                    Text('Delete Failed', style: TextStyle(color: AppTheme.textPrim, fontSize: 13)),
                  ]),
                ),
              const PopupMenuItem(
                value: 'finished',
                child: Row(children: [
                  Icon(Icons.delete_outline_rounded, color: AppTheme.textSec, size: 18),
                  SizedBox(width: 10),
                  Text('Delete Finished', style: TextStyle(color: AppTheme.textPrim, fontSize: 13)),
                ]),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(
                value: 'all',
                child: Row(children: [
                  Icon(Icons.delete_forever_rounded, color: AppTheme.error, size: 18),
                  SizedBox(width: 10),
                  Text('Delete All', style: TextStyle(color: AppTheme.error, fontSize: 13,
                      fontWeight: FontWeight.w700)),
                ]),
              ),
            ],
          ),
        // ── Settings ───────────────────────────────────────────────────────
        IconButton(
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SettingsScreen())),
          icon: const Icon(Icons.settings_rounded, color: AppTheme.textSec),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: AnimatedBuilder(
          animation: _headerAnim,
          builder: (_, __) => Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.bg,
                  Color.lerp(AppTheme.bg, AppTheme.accentGlow, 0.15 + _headerAnim.value * 0.08)!,
                  AppTheme.bg,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Left icon
                    _buildHeaderIcon(),
                    // Centered title + subtitle
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ShaderMask(
                            shaderCallback: (b) => LinearGradient(
                              colors: [
                                Colors.white,
                                Color.lerp(Colors.white, AppTheme.accent, _headerAnim.value * 0.6)!,
                              ],
                            ).createShader(b),
                            child: const Text('Cloud Build Engine',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white, fontSize: 20,
                                  fontWeight: FontWeight.w900, letterSpacing: 0.3),
                            ),
                          ),
                          Text('Build any app via our backend engine',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: AppTheme.textSec, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    // Right icon (mirror of left)
                    _buildHeaderIcon(),
                  ],
                ),
              ),
            ),
          ),
        ),
        titlePadding: EdgeInsets.zero,
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: AppTheme.border),
      ),
    );
  }

  Widget _buildStats() {
    final total     = _jobs.length;
    final running   = _jobs.where((j) => j.isRunning).length;
    final succeeded = _jobs.where((j) => j.isSuccess).length;
    final failed    = _jobs.where((j) => j.isFailed).length;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(children: [
        _StatCard(label: 'Total',   value: '$total',     color: AppTheme.textSec),
        const SizedBox(width: 10),
        _StatCard(label: 'Running', value: '$running',   color: AppTheme.running),
        const SizedBox(width: 10),
        _StatCard(label: 'Success', value: '$succeeded', color: AppTheme.success),
        const SizedBox(width: 10),
        _StatCard(label: 'Failed',  value: '$failed',    color: AppTheme.error),
      ]),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              color: AppTheme.accent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppTheme.border),
            ),
            child: const Icon(Icons.cloud_upload_outlined, color: AppTheme.accent, size: 40),
          ),
          const SizedBox(height: 20),
          const Text('No builds yet',
              style: TextStyle(color: AppTheme.textPrim, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Tap + New Build to start your first build',
              style: TextStyle(color: AppTheme.textSec, fontSize: 13)),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final Color  color;
  const _StatCard({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color:        AppTheme.card,
        borderRadius: BorderRadius.circular(12),
        border:       Border.all(color: AppTheme.border),
      ),
      child: Column(children: [
        Text(value, style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: AppTheme.textSec, fontSize: 10)),
      ]),
    ),
  );
}
