import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static const _channelId   = 'cbe_builds';
  static const _channelName = 'Build Updates';

  static Future<void> init() async {
    if (_ready) return;

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: androidSettings));

    const channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: 'Build completion, errors, and cancellation alerts',
      importance: Importance.max,
      enableVibration: true,
      playSound: true,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();

    _ready = true;
  }

  static NotificationDetails get _highDetails => const NotificationDetails(
    android: AndroidNotificationDetails(
      _channelId, _channelName,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
    ),
  );

  static NotificationDetails get _defaultDetails => const NotificationDetails(
    android: AndroidNotificationDetails(
      _channelId, _channelName,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
    ),
  );

  static Future<void> showSuccess(String appName, int notifId, {String? savedPath}) =>
      _plugin.show(
        notifId,
        'Build Successful',
        savedPath != null
            ? '$appName APK saved to Cloud_Build_Engine/'
            : '$appName APK is ready — open app to download.',
        _highDetails,
      );

  static Future<void> showFailed(String appName, String conclusion, int notifId) =>
      _plugin.show(
        notifId,
        'Build Failed — $appName',
        'Result: $conclusion. Open app to view logs.',
        _highDetails,
      );

  static Future<void> showCancelled(String appName, int notifId) => _plugin.show(
    notifId,
    'Build Cancelled',
    '$appName build was cancelled.',
    _defaultDetails,
  );

  static Future<void> cancel(int notifId) => _plugin.cancel(notifId);
}
