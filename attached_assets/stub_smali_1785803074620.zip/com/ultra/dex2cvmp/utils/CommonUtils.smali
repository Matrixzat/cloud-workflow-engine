.class public Lcom/ultra/dex2cvmp/utils/CommonUtils;
.super Ljava/lang/Object;
.source "CommonUtils.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a(I)[C
    .registers 4
    .param p0, "i"  # I

    .line 42
    const/4 v0, 0x0

    packed-switch p0, :pswitch_data_26

    .line 52
    new-array v0, v0, [C

    return-object v0

    .line 50
    :pswitch_7  #0x3
    const/16 v0, 0x4b

    new-array v0, v0, [C

    fill-array-data v0, :array_32

    return-object v0

    .line 48
    :pswitch_f  #0x2
    const/4 v1, 0x1

    new-array v1, v1, [C

    const/16 v2, 0x6033

    aput-char v2, v1, v0

    return-object v1

    .line 46
    :pswitch_17  #0x1
    const/4 v0, 0x2

    new-array v0, v0, [C

    fill-array-data v0, :array_82

    return-object v0

    .line 44
    :pswitch_1e  #0x0
    const/16 v0, 0xc

    new-array v0, v0, [C

    fill-array-data v0, :array_88

    return-object v0

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1e  #00000000
        :pswitch_17  #00000001
        :pswitch_f  #00000002
        :pswitch_7  #00000003
    .end packed-switch

    :array_32
    .array-data 2
        0x2cs
        0x77s
        -0x4s
        0xb4s
        -0x38s
        0xb2s
        0x4bs
        0x83s
        0x72s
        0x41s
        0x7ds
        0x8bs
        0x85s
        0xc1s
        0xcs
        0xa9s
        0x4fs
        0xacs
        0x8bs
        0x38s
        0x11s
        0x44s
        0x29s
        0x7as
        0x5ds
        0xc6s
        0xe4s
        0x57s
        0xb3s
        0x8es
        -0xcs
        0xa1s
        -0x15s
        0x30s
        0x86s
        0x8fs
        0x1fs
        -0xas
        0xacs
        0xcbs
        0x59s
        -0x11s
        0xcbs
        0x74s
        0x20s
        -0x8s
        0x38s
        0xb7s
        0xd5s
        0x55s
        0x6fs
        -0x24s
        0x73s
        0x1bs
        0x15s
        0x31s
        0x2es
        0x7as
        0x2as
        0x8ds
        0x2bs
        0x5cs
        0x6ds
        0xbs
        0x95s
        0x39s
        0x3cs
        0x72s
        0xdcs
        0x90s
        0xb5s
        0xc2s
        0xa9s
        0x6as
        -0x10s
    .end array-data

    nop

    :array_82
    .array-data 2
        0x3005s
        0x3006s
    .end array-data

    :array_88
    .array-data 2
        -0x6da3s
        0x325ds
        -0x1c67s
        -0x78bes
        -0xf65s
        0x1473s
        0x7904s
        -0x7216s
        -0x2957s
        -0x2ae7s
        -0x757es
        -0x3a5fs
    .end array-data
.end method

.method public static encryptStrings(Ljava/lang/String;I)Ljava/lang/String;
    .registers 7
    .param p0, "str"  # Ljava/lang/String;
    .param p1, "i"  # I

    .line 31
    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 32
    .local v0, "stringBuilder":Ljava/lang/StringBuilder;
    const/4 v1, 0x0

    .local v1, "j":I
    :goto_6
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_25

    .line 33
    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {p1}, Lcom/ultra/dex2cvmp/utils/CommonUtils;->a(I)[C

    move-result-object v3

    invoke-static {p1}, Lcom/ultra/dex2cvmp/utils/CommonUtils;->a(I)[C

    move-result-object v4

    array-length v4, v4

    rem-int v4, v1, v4

    aget-char v3, v3, v4

    xor-int/2addr v2, v3

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 32
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 35
    .end local v1  # "j":I
    :cond_25
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_29} :catch_2a

    return-object v1

    .line 36
    .end local v0  # "stringBuilder":Ljava/lang/StringBuilder;
    :catch_2a
    move-exception v0

    .line 37
    .local v0, "ex":Ljava/lang/Exception;
    const-string v1, ""

    return-object v1
.end method

.method public static exit()V
    .registers 6

    .line 13
    :try_start_0
    const-string v0, "java.lang.System"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 14
    .local v0, "main":Ljava/lang/Class;
    const-string v1, "exit"

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 15
    .local v1, "method":Ljava/lang/reflect/Method;
    invoke-virtual {v1, v2}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 16
    new-instance v3, Ljava/lang/Object;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4
    :try_end_20
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_20} :catch_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_20} :catch_2f
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_20} :catch_2f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_20} :catch_2f

    :try_start_20
    new-array v2, v2, [Ljava/lang/Object;

    aput-object v4, v2, v5
    :try_end_24
    .catch Ljava/lang/ClassNotFoundException; {:try_start_20 .. :try_end_24} :catch_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_20 .. :try_end_24} :catch_2d
    .catch Ljava/lang/IllegalAccessException; {:try_start_20 .. :try_end_24} :catch_2b
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_20 .. :try_end_24} :catch_29

    :try_start_24
    invoke-virtual {v1, v3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_27
    .catch Ljava/lang/ClassNotFoundException; {:try_start_24 .. :try_end_27} :catch_2f
    .catch Ljava/lang/NoSuchMethodException; {:try_start_24 .. :try_end_27} :catch_2f
    .catch Ljava/lang/IllegalAccessException; {:try_start_24 .. :try_end_27} :catch_2f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_24 .. :try_end_27} :catch_2f

    .line 19
    nop

    .end local v0  # "main":Ljava/lang/Class;
    .end local v1  # "method":Ljava/lang/reflect/Method;
    goto :goto_33

    .line 17
    :catch_29
    move-exception v0

    goto :goto_30

    :catch_2b
    move-exception v0

    goto :goto_30

    :catch_2d
    move-exception v0

    goto :goto_30

    :catch_2f
    move-exception v0

    .line 18
    .local v0, "e":Ljava/lang/ReflectiveOperationException;
    :goto_30
    invoke-virtual {v0}, Ljava/lang/ReflectiveOperationException;->printStackTrace()V

    .line 20
    .end local v0  # "e":Ljava/lang/ReflectiveOperationException;
    :goto_33
    return-void
.end method
