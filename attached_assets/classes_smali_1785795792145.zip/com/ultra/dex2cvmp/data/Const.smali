.class public Lcom/ultra/dex2cvmp/data/Const;
.super Ljava/lang/Object;
.source "Const.java"


# static fields
.field public static final APP_CFG:Ljava/lang/String; = "app.cfg"

.field public static final BUNDLE_FILE:Ljava/lang/String; = "phantom.vmp"

.field public static final CERT_ASSET:Ljava/lang/String; = "ph_cert"

.field public static final DP_LIB:Ljava/lang/String; = "phantom"

.field public static final PHANTOM_BLOB_ARM:Ljava/lang/String; = "libphantom_arm.blob"

.field public static final PHANTOM_BLOB_ARM64:Ljava/lang/String; = "libphantom_arm64.blob"

.field public static REAL_APP:Ljava/lang/String; = null

.field public static final SALT_ASSET:Ljava/lang/String; = "ph_salt"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 62
    const-string v0, "android.app.Application"

    sput-object v0, Lcom/ultra/dex2cvmp/data/Const;->REAL_APP:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
