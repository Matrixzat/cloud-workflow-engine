import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import '../models/build_job.dart';

class GitHubService {
  final String token;
  final String owner;
  final String repo;

  GitHubService({
    required this.token,
    required this.owner,
    required this.repo,
  });

  Map<String, String> get _headers => {
    'Authorization': 'Bearer $token',
    'Accept':        'application/vnd.github.v3+json',
    'Content-Type':  'application/json',
    'X-GitHub-Api-Version': '2022-11-28',
  };

  String get _base => 'https://api.github.com/repos/$owner/$repo';

  Future<int?> triggerBuild({
    required String appName,
    required String packageName,
    required String sourceUrl,
    required String flutterVersion,
    String  buildMode = 'release',
    int?    assetId,
  }) async {
    final before = DateTime.now().toUtc().subtract(const Duration(seconds: 5));

    final inputs = <String, String>{
      'app_name':        appName,
      'package_name':    packageName,
      'source_url':      sourceUrl,
      'flutter_version': flutterVersion,
      'build_mode':      buildMode,
      if (assetId != null) 'asset_id': assetId.toString(),
    };

    final res = await http.post(
      Uri.parse('$_base/actions/workflows/build.yml/dispatches'),
      headers: _headers,
      body: jsonEncode({'ref': 'main', 'inputs': inputs}),
    );

    if (res.statusCode == 404) {
      throw Exception(
        'Workflow not found (404).\n\n'
        'Check that:\n'
        '• Repository name in Settings is correct\n'
        '• build.yml is pushed to the workflows folder in that repo\n'
        '• The repository is not empty'
      );
    }
    if (res.statusCode == 401 || res.statusCode == 403) {
      throw Exception(
        'Access denied (${res.statusCode}).\n\n'
        'Check that your API token has Actions (read & write) and Workflows permissions.'
      );
    }
    if (res.statusCode == 422) {
      throw Exception(
        'Invalid input (422). Make sure the repo has a main branch and build.yml exists.'
      );
    }
    if (res.statusCode != 204) {
      throw Exception('Failed to trigger build: ${res.statusCode} ${res.body}');
    }

    // Retry up to 60 times (every 4 seconds = up to 4 minutes) — GitHub can be slow to register the run
    for (int attempt = 0; attempt < 60; attempt++) {
      await Future.delayed(const Duration(seconds: 4));
      final runId = await _findLatestRunId(after: before);
      if (runId != null) return runId;
    }
    return null;
  }

  Future<int?> _findLatestRunId({required DateTime after}) async {
    final res = await http.get(
      Uri.parse('$_base/actions/runs?event=workflow_dispatch&per_page=10'),
      headers: _headers,
    );
    if (res.statusCode != 200) return null;
    final runs = jsonDecode(res.body)['workflow_runs'] as List;
    for (final run in runs) {
      final created = DateTime.parse(run['created_at'] as String).toUtc();
      if (created.isAfter(after)) return run['id'] as int;
    }
    return null;
  }

  Future<Map<String, dynamic>?> getRunStatus(int runId) async {
    final res = await http.get(
      Uri.parse('$_base/actions/runs/$runId'),
      headers: _headers,
    );
    if (res.statusCode != 200) return null;
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<List<Map<String, dynamic>>> getRunArtifacts(int runId) async {
    final res = await http.get(
      Uri.parse('$_base/actions/runs/$runId/artifacts'),
      headers: _headers,
    );
    if (res.statusCode != 200) return [];
    final data = jsonDecode(res.body);
    return List<Map<String, dynamic>>.from(data['artifacts'] ?? []);
  }

  Future<String?> getArtifactDownloadUrl(int artifactId) async {
    final res = await http.get(
      Uri.parse('$_base/actions/artifacts/$artifactId/zip'),
      headers: _headers,
    );
    if (res.statusCode == 302) return res.headers['location'];
    if (res.statusCode == 200) return res.request?.url.toString();
    return null;
  }

  Future<List<Map<String, dynamic>>> listRecentRuns({int perPage = 20}) async {
    final res = await http.get(
      Uri.parse('$_base/actions/runs?per_page=$perPage'),
      headers: _headers,
    );
    if (res.statusCode != 200) return [];
    return List<Map<String, dynamic>>.from(
        jsonDecode(res.body)['workflow_runs'] ?? []);
  }

  Future<List<Map<String, dynamic>>> getRunJobs(int runId) async {
    final res = await http.get(
      Uri.parse('$_base/actions/runs/$runId/jobs'),
      headers: _headers,
    );
    if (res.statusCode != 200) return [];
    final data = jsonDecode(res.body);
    return List<Map<String, dynamic>>.from(data['jobs'] ?? []);
  }

  /// Fetches the raw log text for a GitHub Actions job.
  ///
  /// GitHub's API always returns a 302 redirect to a pre-signed Azure/CDN URL.
  /// We use dart:io's HttpClient directly (followRedirects = false) so we can
  /// reliably read the Location header, then fetch Azure WITHOUT the
  /// Authorization header (Azure SAS URLs reject extra auth headers).
  Future<String?> getJobLogs(int jobId) async {
    final ioClient = HttpClient();
    ioClient.connectionTimeout = const Duration(seconds: 20);

    try {
      // ── Step 1: Hit GitHub API — expect 302 to Azure ──────────────────────
      final req = await ioClient.getUrl(
          Uri.parse('$_base/actions/jobs/$jobId/logs'));
      req.followRedirects = false; // Must be set on the REQUEST, not the client
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      req.headers.set(HttpHeaders.acceptHeader,
          'application/vnd.github.v3+json');
      req.headers.set('X-GitHub-Api-Version', '2022-11-28');

      final res = await req.close();

      // Rare: direct 200 (no redirect)
      if (res.statusCode == 200) {
        final body = await res.transform(const Utf8Decoder(allowMalformed: true)).join();
        return body.isNotEmpty ? body : null;
      }

      // Expected: 302 / 301 / 307 / 308 — follow it manually, no auth
      if (res.statusCode == 301 || res.statusCode == 302 ||
          res.statusCode == 307 || res.statusCode == 308) {
        final location = res.headers.value(HttpHeaders.locationHeader);
        await res.drain<void>(); // discard empty redirect body

        if (location != null) {
          // ── Step 2: Fetch pre-signed URL — NO Authorization header ──────
          final logRes = await http.get(Uri.parse(location));
          if (logRes.statusCode == 200 && logRes.body.isNotEmpty) {
            return logRes.body;
          }
        }
      } else {
        await res.drain<void>();
      }
    } catch (_) {
      // Network / timeout — return null, UI shows retry message
    } finally {
      ioClient.close(force: false);
    }
    return null;
  }

  // ── GitHub Releases bridge ────────────────────────────────────────────────

  /// Gets or creates the "build-queue" pre-release, returns its ID.
  Future<int> ensureBuildQueueRelease() async {
    final getRes = await http.get(
      Uri.parse('$_base/releases/tags/build-queue'),
      headers: _headers,
    );
    if (getRes.statusCode == 200) {
      return jsonDecode(getRes.body)['id'] as int;
    }
    final createRes = await http.post(
      Uri.parse('$_base/releases'),
      headers: _headers,
      body: jsonEncode({
        'tag_name':   'build-queue',
        'name':       'Build Queue',
        'body':       'Temporary staging area. Files are deleted the moment the build starts.',
        'draft':      false,
        'prerelease': true,
      }),
    );
    if (createRes.statusCode != 201) {
      throw Exception('Could not create build-queue release: ${createRes.statusCode} ${createRes.body}');
    }
    return jsonDecode(createRes.body)['id'] as int;
  }

  /// Uploads [file] as a release asset. Returns (assetId, downloadUrl).
  Future<({int assetId, String downloadUrl})> uploadReleaseAsset({
    required int    releaseId,
    required File   file,
    required String fileName,
    void Function(double progress)? onProgress,
  }) async {
    final fileSize  = await file.length();
    final uploadUrl =
        'https://uploads.github.com/repos/$owner/$repo/releases/$releaseId/assets'
        '?name=${Uri.encodeComponent(fileName)}';

    final dio = Dio();
    final response = await dio.post(
      uploadUrl,
      data: file.openRead(),
      options: Options(
        headers: {
          'Authorization':       'Bearer $token',
          'Content-Type':        'application/octet-stream',
          'Content-Length':      fileSize.toString(),
          'Accept':              'application/vnd.github.v3+json',
          'X-GitHub-Api-Version': '2022-11-28',
        },
        sendTimeout:    const Duration(minutes: 30),
        receiveTimeout: const Duration(minutes: 5),
      ),
      onSendProgress: (sent, total) {
        if (total > 0 && onProgress != null) onProgress(sent / total);
      },
    );

    if (response.statusCode != 201) {
      throw Exception('Asset upload failed: ${response.statusCode}');
    }
    final data        = response.data as Map<String, dynamic>;
    final assetId     = data['id']                   as int;
    final downloadUrl = data['browser_download_url'] as String;
    return (assetId: assetId, downloadUrl: downloadUrl);
  }

  /// Deletes a release asset immediately.
  Future<void> deleteReleaseAsset(int assetId) async {
    await http.delete(
      Uri.parse('$_base/releases/assets/$assetId'),
      headers: _headers,
    );
  }

  /// Deletes an Actions artifact so it cannot be downloaded from GitHub.
  /// [artifactId] can be passed directly, or extracted from the archive_download_url.
  Future<void> deleteArtifact(int artifactId) async {
    final res = await http.delete(
      Uri.parse('$_base/actions/artifacts/$artifactId'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Artifact delete failed: HTTP ${res.statusCode}');
    }
  }

  /// Extracts the artifact ID from an archive_download_url.
  /// e.g. https://api.github.com/repos/owner/repo/actions/artifacts/123456/zip → 123456
  static int? artifactIdFromUrl(String url) {
    final m = RegExp(r'/actions/artifacts/(\d+)/zip').firstMatch(url);
    return m != null ? int.tryParse(m.group(1)!) : null;
  }

  Future<void> cancelRun(int runId) async {
    final res = await http.post(
      Uri.parse('$_base/actions/runs/$runId/cancel'),
      headers: _headers,
    );
    if (res.statusCode != 202) {
      throw Exception('Cancel failed: HTTP ${res.statusCode}');
    }
  }

  Future<bool> validateToken() async {
    final res = await http.get(
      Uri.parse('https://api.github.com/user'),
      headers: _headers,
    );
    return res.statusCode == 200;
  }

  Future<String?> pollUntilComplete(
    int runId, {
    required void Function(String status) onStatus,
    int maxMinutes = 30,
  }) async {
    final deadline = DateTime.now().add(Duration(minutes: maxMinutes));
    while (DateTime.now().isBefore(deadline)) {
      await Future.delayed(const Duration(seconds: 10));
      final run = await getRunStatus(runId);
      if (run == null) continue;
      final status     = run['status']     as String? ?? 'unknown';
      final conclusion = run['conclusion'] as String?;
      onStatus(status);
      if (status == 'completed') return conclusion;
    }
    return null;
  }

  static BuildJob updateJobFromRun(BuildJob job, Map<String, dynamic> run) {
    job.status     = run['status']     as String? ?? job.status;
    job.conclusion = run['conclusion'] as String?;
    job.updatedAt  = DateTime.now();
    return job;
  }
}
